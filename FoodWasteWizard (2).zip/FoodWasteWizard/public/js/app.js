/**
 * Food Waste Management
 * Main application script
 */

// App Controller
const App = {
  // State
  currentPage: 'home',
  user: null,
  isAuthenticated: false,
  
  // Initialize application
  init() {
    // Mount components
    this.mountNavbar();
    this.mountFooter();
    
    // Setup router
    this.setupRouter();
    
    // Check authentication status
    this.checkAuthStatus();
    
    // Setup event listeners
    this.setupEventListeners();
    
    console.log('App initialized');
  },
  
  // Mount navbar component
  mountNavbar() {
    const template = document.getElementById('navbar-template');
    const navbar = template.content.cloneNode(true);
    document.body.insertBefore(navbar, document.getElementById('app'));
  },
  
  // Mount footer component
  mountFooter() {
    const template = document.getElementById('footer-template');
    const footer = template.content.cloneNode(true);
    document.body.appendChild(footer);
  },
  
  // Setup router for client-side navigation
  setupRouter() {
    window.addEventListener('hashchange', () => this.handleRouteChange());
    this.handleRouteChange();
  },
  
  // Handle route change
  handleRouteChange() {
    const hash = window.location.hash.slice(1) || '/';
    const pathSegments = hash.split('/').filter(Boolean);
    const route = pathSegments[0] || 'home';
    
    this.currentPage = route;
    this.loadPage(route, pathSegments.slice(1));
    
    // Update active link in navbar
    this.updateActiveNav();
  },
  
  // Load page content based on route
  loadPage(route, params = []) {
    const appContainer = document.getElementById('app');
    
    // Clear current content
    appContainer.innerHTML = '';
    
    // Show loading spinner
    const loadingDiv = document.createElement('div');
    loadingDiv.className = 'loading-container';
    loadingDiv.innerHTML = '<div class="spinner-grow text-primary" role="status"><span class="visually-hidden">Loading...</span></div>';
    appContainer.appendChild(loadingDiv);
    
    // Load page content based on route
    switch (route) {
      case '':
      case 'home':
        this.loadHomePage();
        break;
      case 'login':
        this.loadLoginPage();
        break;
      case 'register':
        this.loadRegisterPage();
        break;
      case 'dashboard':
        this.requireAuth(() => this.loadDashboardPage());
        break;
      case 'inventory':
        this.requireAuth(() => this.loadInventoryPage());
        break;
      case 'donations':
        this.requireAuth(() => this.loadDonationsPage());
        break;
      case 'recipes':
        this.loadRecipesPage();
        break;
      case 'profile':
        this.requireAuth(() => this.loadProfilePage());
        break;
      case 'settings':
        this.requireAuth(() => this.loadSettingsPage());
        break;
      case 'about':
        this.loadAboutPage();
        break;
      case 'contact':
        this.loadContactPage();
        break;
      default:
        this.loadNotFoundPage();
    }
  },
  
  // Check if user is authenticated
  checkAuthStatus() {
    const token = localStorage.getItem('token');
    if (token) {
      fetch('/api/auth/user', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
      .then(response => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error('Authentication failed');
        }
      })
      .then(userData => {
        this.user = userData;
        this.isAuthenticated = true;
        this.updateAuthUI();
      })
      .catch(error => {
        console.error('Auth check error:', error);
        localStorage.removeItem('token');
        this.user = null;
        this.isAuthenticated = false;
        this.updateAuthUI();
      });
    } else {
      this.updateAuthUI();
    }
  },
  
  // Update UI based on authentication status
  updateAuthUI() {
    const authenticatedElements = document.querySelectorAll('.authenticated-only');
    const unauthenticatedElements = document.querySelectorAll('.unauthenticated-only');
    
    if (this.isAuthenticated) {
      authenticatedElements.forEach(el => el.style.display = 'block');
      unauthenticatedElements.forEach(el => el.style.display = 'none');
      
      // Update user name in dropdown
      const userNameElement = document.getElementById('user-name');
      if (userNameElement && this.user) {
        userNameElement.textContent = this.user.name;
      }
    } else {
      authenticatedElements.forEach(el => el.style.display = 'none');
      unauthenticatedElements.forEach(el => el.style.display = 'block');
    }
  },
  
  // Authentication middleware
  requireAuth(callback) {
    if (this.isAuthenticated) {
      callback();
    } else {
      window.location.hash = '#/login';
    }
  },
  
  // Setup global event listeners
  setupEventListeners() {
    // Logout button
    document.addEventListener('click', (event) => {
      if (event.target.id === 'logout-btn') {
        event.preventDefault();
        this.logout();
      }
    });
  },
  
  // Handle logout
  logout() {
    fetch('/api/auth/logout', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    })
    .then(() => {
      localStorage.removeItem('token');
      this.user = null;
      this.isAuthenticated = false;
      this.updateAuthUI();
      window.location.hash = '#/';
      this.showToast('Success', 'You have been logged out successfully');
    })
    .catch(error => {
      console.error('Logout error:', error);
      this.showToast('Error', 'An error occurred during logout');
    });
  },
  
  // Update active navigation link
  updateActiveNav() {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
      const href = link.getAttribute('href');
      if (href === '#/' + this.currentPage || (href === '#/' && this.currentPage === 'home')) {
        link.classList.add('active');
      } else {
        link.classList.remove('active');
      }
    });
  },
  
  // Show toast notification
  showToast(title, message, type = 'success') {
    const toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
      const container = document.createElement('div');
      container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
      document.body.appendChild(container);
    }
    
    const toastId = 'toast-' + Date.now();
    const toast = document.createElement('div');
    toast.className = `toast ${type === 'error' ? 'bg-danger text-white' : type === 'warning' ? 'bg-warning' : 'bg-success text-white'}`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    toast.id = toastId;
    
    toast.innerHTML = `
      <div class="toast-header">
        <strong class="me-auto">${title}</strong>
        <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
      </div>
      <div class="toast-body">
        ${message}
      </div>
    `;
    
    document.querySelector('.toast-container').appendChild(toast);
    
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();
    
    // Remove toast after it's hidden
    toast.addEventListener('hidden.bs.toast', () => {
      toast.remove();
    });
  },
  
  // Load home page content
  loadHomePage() {
    const template = document.getElementById('home-template');
    const content = template.content.cloneNode(true);
    
    const appContainer = document.getElementById('app');
    appContainer.innerHTML = '';
    appContainer.appendChild(content);
    
    // Update impact stats with some demo data
    document.getElementById('users-count').textContent = '1,200+';
    document.getElementById('donations-count').textContent = '5,000+';
    document.getElementById('meals-count').textContent = '20,000+';
    document.getElementById('waste-reduced').textContent = '15,000+';
    
    // Add event listeners for home page buttons
    document.getElementById('get-started-btn').addEventListener('click', () => {
      window.location.hash = this.isAuthenticated ? '#/dashboard' : '#/register';
    });
    
    document.getElementById('learn-more-btn').addEventListener('click', () => {
      window.location.hash = '#/about';
    });
    
    document.getElementById('register-cta-btn').addEventListener('click', () => {
      window.location.hash = '#/register';
    });
    
    document.getElementById('contact-cta-btn').addEventListener('click', () => {
      window.location.hash = '#/contact';
    });
  },
  
  // Load login page
  loadLoginPage() {
    // Redirect if already logged in
    if (this.isAuthenticated) {
      window.location.hash = '#/dashboard';
      return;
    }
    
    const appContainer = document.getElementById('app');
    appContainer.innerHTML = `
      <div class="container">
        <div class="auth-container">
          <h2 class="text-center mb-4">Login</h2>
          <form id="login-form">
            <div class="mb-3">
              <label for="email" class="form-label">Email address</label>
              <input type="email" class="form-control" id="email" required>
            </div>
            <div class="mb-3">
              <label for="password" class="form-label">Password</label>
              <input type="password" class="form-control" id="password" required>
            </div>
            <div class="mb-3 form-check">
              <input type="checkbox" class="form-check-input" id="remember-me">
              <label class="form-check-label" for="remember-me">Remember me</label>
            </div>
            <div class="d-grid">
              <button type="submit" class="btn btn-primary">Login</button>
            </div>
          </form>
          
          <div class="auth-separator">
            <span>OR</span>
          </div>
          
          <div class="text-center">
            <p>Don't have an account? <a href="#/register">Register here</a></p>
          </div>
        </div>
      </div>
    `;
    
    // Handle form submission
    document.getElementById('login-form').addEventListener('submit', (event) => {
      event.preventDefault();
      
      const email = document.getElementById('email').value;
      const password = document.getElementById('password').value;
      
      fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
      })
      .then(response => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error('Login failed');
        }
      })
      .then(data => {
        localStorage.setItem('token', data.token);
        this.user = data.user;
        this.isAuthenticated = true;
        this.updateAuthUI();
        window.location.hash = '#/dashboard';
        this.showToast('Success', 'You have been logged in successfully');
      })
      .catch(error => {
        console.error('Login error:', error);
        this.showToast('Error', 'Invalid email or password', 'error');
      });
    });
  },
  
  // Load register page
  loadRegisterPage() {
    // Redirect if already logged in
    if (this.isAuthenticated) {
      window.location.hash = '#/dashboard';
      return;
    }
    
    const appContainer = document.getElementById('app');
    appContainer.innerHTML = `
      <div class="container">
        <div class="auth-container">
          <h2 class="text-center mb-4">Register</h2>
          <form id="register-form">
            <div class="mb-3">
              <label for="name" class="form-label">Full Name</label>
              <input type="text" class="form-control" id="name" required>
            </div>
            <div class="mb-3">
              <label for="email" class="form-label">Email address</label>
              <input type="email" class="form-control" id="email" required>
            </div>
            <div class="mb-3">
              <label for="password" class="form-label">Password</label>
              <input type="password" class="form-control" id="password" required minlength="6">
            </div>
            <div class="mb-3">
              <label for="password-confirm" class="form-label">Confirm Password</label>
              <input type="password" class="form-control" id="password-confirm" required minlength="6">
            </div>
            <div class="mb-3">
              <label for="role" class="form-label">I am a...</label>
              <select class="form-select" id="role" required>
                <option value="user">Individual User</option>
                <option value="donor">Food Donor (Business)</option>
                <option value="ngo">Non-Profit Organization</option>
                <option value="volunteer">Volunteer</option>
              </select>
            </div>
            <div class="mb-3 form-check">
              <input type="checkbox" class="form-check-input" id="terms" required>
              <label class="form-check-label" for="terms">I agree to the <a href="#/terms">Terms and Conditions</a></label>
            </div>
            <div class="d-grid">
              <button type="submit" class="btn btn-primary">Register</button>
            </div>
          </form>
          
          <div class="auth-separator">
            <span>OR</span>
          </div>
          
          <div class="text-center">
            <p>Already have an account? <a href="#/login">Login here</a></p>
          </div>
        </div>
      </div>
    `;
    
    // Handle form submission
    document.getElementById('register-form').addEventListener('submit', (event) => {
      event.preventDefault();
      
      const name = document.getElementById('name').value;
      const email = document.getElementById('email').value;
      const password = document.getElementById('password').value;
      const passwordConfirm = document.getElementById('password-confirm').value;
      const role = document.getElementById('role').value;
      
      // Validate passwords match
      if (password !== passwordConfirm) {
        this.showToast('Error', 'Passwords do not match', 'error');
        return;
      }
      
      fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, email, password, role })
      })
      .then(response => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error('Registration failed');
        }
      })
      .then(data => {
        localStorage.setItem('token', data.token);
        this.user = data.user;
        this.isAuthenticated = true;
        this.updateAuthUI();
        window.location.hash = '#/dashboard';
        this.showToast('Success', 'Account created successfully');
      })
      .catch(error => {
        console.error('Registration error:', error);
        this.showToast('Error', 'Registration failed. Please try again.', 'error');
      });
    });
  },
  
  // Load dashboard page (placeholder)
  loadDashboardPage() {
    const appContainer = document.getElementById('app');
    appContainer.innerHTML = `
      <div class="container py-4">
        <h1 class="mb-4">Dashboard</h1>
        <p class="lead">Welcome to your food waste management dashboard.</p>
        <div class="alert alert-info">
          More features will be added soon. This is a placeholder dashboard.
        </div>
      </div>
    `;
  },
  
  // Load inventory page (placeholder)
  loadInventoryPage() {
    const appContainer = document.getElementById('app');
    appContainer.innerHTML = `
      <div class="container py-4">
        <h1 class="mb-4">Food Inventory</h1>
        <p class="lead">Manage your food items and track expiry dates.</p>
        <div class="alert alert-info">
          More features will be added soon. This is a placeholder inventory page.
        </div>
      </div>
    `;
  },
  
  // Load donations page (placeholder)
  loadDonationsPage() {
    const appContainer = document.getElementById('app');
    appContainer.innerHTML = `
      <div class="container py-4">
        <h1 class="mb-4">Donations</h1>
        <p class="lead">Donate surplus food to local organizations.</p>
        <div class="alert alert-info">
          More features will be added soon. This is a placeholder donations page.
        </div>
      </div>
    `;
  },
  
  // Load recipes page (placeholder)
  loadRecipesPage() {
    const appContainer = document.getElementById('app');
    appContainer.innerHTML = `
      <div class="container py-4">
        <h1 class="mb-4">Recipes</h1>
        <p class="lead">Find recipes based on ingredients you need to use soon.</p>
        <div class="alert alert-info">
          More features will be added soon. This is a placeholder recipes page.
        </div>
      </div>
    `;
  },
  
  // Load not found page
  loadNotFoundPage() {
    const appContainer = document.getElementById('app');
    appContainer.innerHTML = `
      <div class="container text-center py-5">
        <h1 class="display-1">404</h1>
        <h2 class="mb-4">Page Not Found</h2>
        <p class="lead mb-4">The page you are looking for does not exist.</p>
        <a href="#/" class="btn btn-primary">Back to Home</a>
      </div>
    `;
  },
  
  // Load about page
  loadAboutPage() {
    const appContainer = document.getElementById('app');
    appContainer.innerHTML = `
      <div class="container py-4">
        <h1 class="mb-4">About Us</h1>
        <p class="lead">Food Waste Management is a platform connecting food donors with NGOs and volunteers to reduce hunger and waste.</p>
        
        <div class="row mt-5">
          <div class="col-md-6">
            <h3>Our Mission</h3>
            <p>Our mission is to reduce food waste and address hunger by creating an efficient ecosystem for food donation and distribution.</p>
            
            <h3 class="mt-4">Why Food Waste Matters</h3>
            <ul>
              <li>One-third of food produced for human consumption is lost or wasted globally.</li>
              <li>Food waste represents a $940 billion economic loss annually.</li>
              <li>If food waste were a country, it would be the third-largest emitter of greenhouse gases.</li>
              <li>Meanwhile, over 820 million people in the world do not have enough to eat.</li>
            </ul>
          </div>
          
          <div class="col-md-6">
            <h3>How It Works</h3>
            <ol>
              <li><strong>Track Your Inventory</strong> - Keep track of your food items and get notifications before they expire.</li>
              <li><strong>Donate Surplus Food</strong> - Connect with local organizations and donate your extra food before it goes to waste.</li>
              <li><strong>Find Recipes</strong> - Discover recipes based on ingredients you need to use soon.</li>
              <li><strong>See Your Impact</strong> - Track your contribution to reducing food waste and fighting hunger.</li>
            </ol>
            
            <h3 class="mt-4">Join Us</h3>
            <p>Whether you're an individual, a business, or a non-profit organization, you can make a difference. Join our platform today and be part of the solution to food waste and hunger.</p>
            <a href="#/register" class="btn btn-primary mt-2">Sign Up Now</a>
          </div>
        </div>
      </div>
    `;
  },
  
  // Load contact page
  loadContactPage() {
    const appContainer = document.getElementById('app');
    appContainer.innerHTML = `
      <div class="container py-4">
        <h1 class="mb-4">Contact Us</h1>
        <p class="lead">Have questions or feedback? We'd love to hear from you.</p>
        
        <div class="row mt-5">
          <div class="col-md-6">
            <h3>Send Us a Message</h3>
            <form id="contact-form">
              <div class="mb-3">
                <label for="name" class="form-label">Your Name</label>
                <input type="text" class="form-control" id="name" required>
              </div>
              <div class="mb-3">
                <label for="email" class="form-label">Email address</label>
                <input type="email" class="form-control" id="email" required>
              </div>
              <div class="mb-3">
                <label for="subject" class="form-label">Subject</label>
                <input type="text" class="form-control" id="subject" required>
              </div>
              <div class="mb-3">
                <label for="message" class="form-label">Message</label>
                <textarea class="form-control" id="message" rows="5" required></textarea>
              </div>
              <button type="submit" class="btn btn-primary">Send Message</button>
            </form>
          </div>
          
          <div class="col-md-6">
            <h3>Contact Information</h3>
            <p><i class="fas fa-map-marker-alt me-2"></i> 123 Food Street, Green City, Earth</p>
            <p><i class="fas fa-phone me-2"></i> +1 (123) 456-7890</p>
            <p><i class="fas fa-envelope me-2"></i> contact@foodwastemanagement.org</p>
            
            <h3 class="mt-4">Connect With Us</h3>
            <div class="social-icons">
              <a href="#" class="btn btn-outline-primary me-2"><i class="fab fa-facebook"></i></a>
              <a href="#" class="btn btn-outline-primary me-2"><i class="fab fa-twitter"></i></a>
              <a href="#" class="btn btn-outline-primary me-2"><i class="fab fa-instagram"></i></a>
              <a href="#" class="btn btn-outline-primary me-2"><i class="fab fa-linkedin"></i></a>
            </div>
          </div>
        </div>
      </div>
    `;
    
    // Handle form submission
    document.getElementById('contact-form').addEventListener('submit', (event) => {
      event.preventDefault();
      this.showToast('Success', 'Your message has been sent. We will get back to you soon.');
      document.getElementById('contact-form').reset();
    });
  },
  
  // Load profile page (placeholder)
  loadProfilePage() {
    const appContainer = document.getElementById('app');
    appContainer.innerHTML = `
      <div class="container py-4">
        <h1 class="mb-4">Profile</h1>
        <p class="lead">View and update your profile information.</p>
        <div class="alert alert-info">
          More features will be added soon. This is a placeholder profile page.
        </div>
      </div>
    `;
  },
  
  // Load settings page (placeholder)
  loadSettingsPage() {
    const appContainer = document.getElementById('app');
    appContainer.innerHTML = `
      <div class="container py-4">
        <h1 class="mb-4">Settings</h1>
        <p class="lead">Manage your account settings and preferences.</p>
        <div class="alert alert-info">
          More features will be added soon. This is a placeholder settings page.
        </div>
      </div>
    `;
  }
};

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  App.init();
});