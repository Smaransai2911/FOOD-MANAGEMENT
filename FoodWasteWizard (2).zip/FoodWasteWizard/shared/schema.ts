import { pgTable, text, serial, integer, boolean, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User Model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  role: text("role", { enum: ["admin", "ngo", "volunteer", "donor"] }).notNull().default("donor"),
  phone: text("phone"),
  address: text("address"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  email: true,
  role: true,
  phone: true,
  address: true,
});

// Food Item Model
export const foodItems = pgTable("food_items", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  quantity: text("quantity").notNull(),
  unit: text("unit").notNull(),
  expiryDate: timestamp("expiry_date").notNull(),
  description: text("description"),
  imageUrl: text("image_url"),
  isAvailableForDonation: boolean("is_available_for_donation").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertFoodItemSchema = createInsertSchema(foodItems).pick({
  userId: true,
  name: true,
  category: true,
  quantity: true,
  unit: true,
  expiryDate: true,
  description: true,
  imageUrl: true,
  isAvailableForDonation: true,
});

// Donation Model
export const donations = pgTable("donations", {
  id: serial("id").primaryKey(),
  donorId: integer("donor_id").notNull(),
  recipientId: integer("recipient_id"),
  status: text("status", { enum: ["pending", "accepted", "scheduled", "completed", "cancelled"] }).notNull().default("pending"),
  pickupDate: timestamp("pickup_date"),
  pickupAddress: text("pickup_address"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertDonationSchema = createInsertSchema(donations).pick({
  donorId: true,
  recipientId: true,
  status: true,
  pickupDate: true,
  pickupAddress: true,
  notes: true,
});

// Donation Items Model (Junction table)
export const donationItems = pgTable("donation_items", {
  id: serial("id").primaryKey(),
  donationId: integer("donation_id").notNull(),
  foodItemId: integer("food_item_id").notNull(),
  quantity: text("quantity").notNull(),
});

export const insertDonationItemSchema = createInsertSchema(donationItems).pick({
  donationId: true,
  foodItemId: true,
  quantity: true,
});

// Recipe Model
export const recipes = pgTable("recipes", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  ingredients: text("ingredients").notNull(),
  instructions: text("instructions").notNull(),
  prepTime: integer("prep_time").notNull(),
  difficulty: text("difficulty", { enum: ["easy", "medium", "hard"] }).notNull(),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertRecipeSchema = createInsertSchema(recipes).pick({
  name: true,
  description: true,
  ingredients: true,
  instructions: true,
  prepTime: true,
  difficulty: true,
  imageUrl: true,
});

// Recipe Ingredient (for matching)
export const recipeIngredients = pgTable("recipe_ingredients", {
  id: serial("id").primaryKey(),
  recipeId: integer("recipe_id").notNull(),
  ingredientName: text("ingredient_name").notNull(),
});

export const insertRecipeIngredientSchema = createInsertSchema(recipeIngredients).pick({
  recipeId: true,
  ingredientName: true,
});

// NGO/Donation Location
export const donationLocations = pgTable("donation_locations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  type: text("type", { enum: ["food_bank", "shelter", "community_center", "school", "other"] }).notNull(),
  address: text("address").notNull(),
  latitude: text("latitude"),
  longitude: text("longitude"),
  contactPerson: text("contact_person"),
  phone: text("phone"),
  email: text("email"),
  operatingHours: text("operating_hours"),
  acceptsFoodTypes: text("accepts_food_types"),
  isActive: boolean("is_active").default(true),
});

export const insertDonationLocationSchema = createInsertSchema(donationLocations).pick({
  userId: true,
  name: true,
  type: true,
  address: true,
  latitude: true,
  longitude: true,
  contactPerson: true,
  phone: true,
  email: true,
  operatingHours: true,
  acceptsFoodTypes: true,
  isActive: true,
});

// Type exports
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type FoodItem = typeof foodItems.$inferSelect;
export type InsertFoodItem = z.infer<typeof insertFoodItemSchema>;

export type Donation = typeof donations.$inferSelect;
export type InsertDonation = z.infer<typeof insertDonationSchema>;

export type DonationItem = typeof donationItems.$inferSelect;
export type InsertDonationItem = z.infer<typeof insertDonationItemSchema>;

export type Recipe = typeof recipes.$inferSelect;
export type InsertRecipe = z.infer<typeof insertRecipeSchema>;

export type RecipeIngredient = typeof recipeIngredients.$inferSelect;
export type InsertRecipeIngredient = z.infer<typeof insertRecipeIngredientSchema>;

export type DonationLocation = typeof donationLocations.$inferSelect;
export type InsertDonationLocation = z.infer<typeof insertDonationLocationSchema>;
