// Define database schema using drizzle-orm with JavaScript
const { z } = require('zod');
const { pgTable, serial, text, integer, timestamp, boolean, varchar, doublePrecision, json } = require('drizzle-orm/pg-core');
const { createInsertSchema } = require('drizzle-zod');
const { relations } = require('drizzle-orm');

// User table
const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 50 }).notNull().unique(),
  password: text("password").notNull(),
  name: varchar("name", { length: 100 }).notNull(),
  email: varchar("email", { length: 100 }).notNull().unique(),
  role: varchar("role", { length: 20 }).notNull().default('donor'),
  createdAt: timestamp("created_at").defaultNow()
});

// Food items table
const foodItems = pgTable("food_items", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: varchar("name", { length: 100 }).notNull(),
  category: varchar("category", { length: 20 }).notNull(),
  quantity: doublePrecision("quantity").notNull(),
  unit: varchar("unit", { length: 20 }).notNull(),
  expiryDate: varchar("expiry_date").notNull(), // Store as ISO date string
  notes: text("notes"),
  markedForDonation: boolean("marked_for_donation").default(false),
  isUsed: boolean("is_used").default(false),
  isDonated: boolean("is_donated").default(false),
  createdAt: timestamp("created_at").defaultNow()
});

// Donations table
const donations = pgTable("donations", {
  id: serial("id").primaryKey(),
  donorId: integer("donor_id").notNull().references(() => users.id),
  recipientId: integer("recipient_id").notNull().references(() => users.id),
  status: varchar("status", { length: 20 }).notNull().default('pending'),
  pickupDateTime: varchar("pickup_date_time").notNull(), // Store as ISO date string
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow()
});

// Donation items table
const donationItems = pgTable("donation_items", {
  id: serial("id").primaryKey(),
  donationId: integer("donation_id").notNull().references(() => donations.id),
  foodItemId: integer("food_item_id").notNull().references(() => foodItems.id),
  quantity: doublePrecision("quantity").notNull(),
  notes: text("notes")
});

// Recipes table
const recipes = pgTable("recipes", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  description: text("description"),
  prepTime: integer("prep_time").notNull(),
  cookTime: integer("cook_time").notNull(),
  servings: integer("servings").notNull(),
  difficulty: varchar("difficulty", { length: 20 }).notNull().default('medium'),
  imageUrl: text("image_url"),
  instructions: json("instructions").notNull(), // Array of strings
  rating: doublePrecision("rating"),
  reviewCount: integer("review_count"),
  calories: integer("calories"),
  protein: varchar("protein", { length: 20 }),
  carbs: varchar("carbs", { length: 20 }),
  fat: varchar("fat", { length: 20 }),
  tips: json("tips"), // Array of strings
  createdAt: timestamp("created_at").defaultNow()
});

// Recipe ingredients table
const recipeIngredients = pgTable("recipe_ingredients", {
  id: serial("id").primaryKey(),
  recipeId: integer("recipe_id").notNull().references(() => recipes.id),
  name: varchar("name", { length: 100 }).notNull(),
  amount: doublePrecision("amount").notNull(),
  unit: varchar("unit", { length: 20 }).notNull()
});

// Donation locations table
const donationLocations = pgTable("donation_locations", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  type: varchar("type", { length: 20 }).notNull(),
  address: text("address").notNull(),
  phone: varchar("phone", { length: 20 }),
  email: varchar("email", { length: 100 }),
  hours: text("hours"),
  latitude: doublePrecision("latitude"),
  longitude: doublePrecision("longitude")
});

// Define relations
const usersRelations = relations(users, ({ many }) => ({
  foodItems: many(foodItems),
  donationsAsDonor: many(donations, { relationName: "donor" }),
  donationsAsRecipient: many(donations, { relationName: "recipient" })
}));

const foodItemsRelations = relations(foodItems, ({ one, many }) => ({
  user: one(users, {
    fields: [foodItems.userId],
    references: [users.id]
  }),
  donationItems: many(donationItems)
}));

const donationsRelations = relations(donations, ({ one, many }) => ({
  donor: one(users, {
    fields: [donations.donorId],
    references: [users.id],
    relationName: "donor"
  }),
  recipient: one(users, {
    fields: [donations.recipientId],
    references: [users.id],
    relationName: "recipient"
  }),
  donationItems: many(donationItems)
}));

const donationItemsRelations = relations(donationItems, ({ one }) => ({
  donation: one(donations, {
    fields: [donationItems.donationId],
    references: [donations.id]
  }),
  foodItem: one(foodItems, {
    fields: [donationItems.foodItemId],
    references: [foodItems.id]
  })
}));

const recipesRelations = relations(recipes, ({ many }) => ({
  ingredients: many(recipeIngredients)
}));

const recipeIngredientsRelations = relations(recipeIngredients, ({ one }) => ({
  recipe: one(recipes, {
    fields: [recipeIngredients.recipeId],
    references: [recipes.id]
  })
}));

// Create insert schemas (without id, createdAt)
const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true
});

const insertFoodItemSchema = createInsertSchema(foodItems).omit({
  id: true,
  createdAt: true
});

const insertDonationSchema = createInsertSchema(donations).omit({
  id: true,
  createdAt: true
});

const insertDonationItemSchema = createInsertSchema(donationItems).omit({
  id: true
});

const insertRecipeSchema = createInsertSchema(recipes).omit({
  id: true,
  createdAt: true
});

const insertRecipeIngredientSchema = createInsertSchema(recipeIngredients).omit({
  id: true
});

const insertDonationLocationSchema = createInsertSchema(donationLocations).omit({
  id: true
});

// Create validation schemas using Zod
const userSchema = z.object({
  id: z.number(),
  username: z.string().min(3).max(50),
  password: z.string().min(6),
  name: z.string().min(1),
  email: z.string().email(),
  role: z.enum(['admin', 'donor', 'ngo', 'volunteer']).default('donor'),
  createdAt: z.date().optional()
});

const foodItemSchema = z.object({
  id: z.number(),
  userId: z.number(),
  name: z.string().min(1).max(100),
  category: z.enum(['produce', 'dairy', 'meat', 'grains', 'canned', 'frozen', 'bakery', 'beverages', 'other']),
  quantity: z.number().positive(),
  unit: z.string(),
  expiryDate: z.string(), // ISO date string
  notes: z.string().optional(),
  markedForDonation: z.boolean().default(false),
  isUsed: z.boolean().default(false),
  isDonated: z.boolean().default(false),
  createdAt: z.date().optional()
});

const donationSchema = z.object({
  id: z.number(),
  donorId: z.number(),
  recipientId: z.number(),
  status: z.enum(['pending', 'accepted', 'scheduled', 'completed', 'cancelled']).default('pending'),
  pickupDateTime: z.string(), // ISO date string
  notes: z.string().optional(),
  createdAt: z.date().optional()
});

const donationItemSchema = z.object({
  id: z.number(),
  donationId: z.number(),
  foodItemId: z.number(),
  quantity: z.number().positive(),
  notes: z.string().optional()
});

const recipeSchema = z.object({
  id: z.number(),
  name: z.string().min(1).max(100),
  description: z.string().optional(),
  prepTime: z.number().int().positive(),
  cookTime: z.number().int().positive(),
  servings: z.number().int().positive(),
  difficulty: z.enum(['easy', 'medium', 'hard']).default('medium'),
  imageUrl: z.string().optional(),
  instructions: z.array(z.string()),
  rating: z.number().min(0).max(5).optional(),
  reviewCount: z.number().int().optional(),
  calories: z.number().int().optional(),
  protein: z.string().optional(),
  carbs: z.string().optional(),
  fat: z.string().optional(),
  tips: z.array(z.string()).optional(),
  createdAt: z.date().optional()
});

const recipeIngredientSchema = z.object({
  id: z.number(),
  recipeId: z.number(),
  name: z.string().min(1),
  amount: z.number().positive(),
  unit: z.string()
});

const donationLocationSchema = z.object({
  id: z.number(),
  name: z.string().min(1).max(100),
  type: z.enum(['foodbank', 'shelter', 'soupkitchen', 'community', 'other']),
  address: z.string().min(1),
  phone: z.string().optional(),
  email: z.string().email().optional(),
  hours: z.string().optional(),
  latitude: z.number().optional(),
  longitude: z.number().optional()
});

module.exports = {
  // Tables
  users,
  foodItems,
  donations,
  donationItems,
  recipes,
  recipeIngredients,
  donationLocations,
  
  // Relations
  usersRelations,
  foodItemsRelations,
  donationsRelations,
  donationItemsRelations,
  recipesRelations,
  recipeIngredientsRelations,
  
  // Schemas
  userSchema,
  foodItemSchema,
  donationSchema,
  donationItemSchema,
  recipeSchema,
  recipeIngredientSchema,
  donationLocationSchema,
  
  // Insert schemas
  insertUserSchema,
  insertFoodItemSchema,
  insertDonationSchema,
  insertDonationItemSchema,
  insertRecipeSchema,
  insertRecipeIngredientSchema,
  insertDonationLocationSchema
};