import { useAuth } from "@/hooks/use-auth";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  Home,
  Package2,
  Heart,
  BookOpen,
  Map,
  BarChart3,
  Info,
  Settings,
  LogOut,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface SidebarProps {
  className?: string;
}

export function Sidebar({ className }: SidebarProps) {
  const { user, logoutMutation } = useAuth();
  const [location] = useLocation();

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const routes = [
    {
      name: "Dashboard",
      path: "/",
      icon: <Home className="h-5 w-5 mr-3" />,
    },
    {
      name: "Food Inventory",
      path: "/inventory",
      icon: <Package2 className="h-5 w-5 mr-3" />,
    },
    {
      name: "Donate Food",
      path: "/donate",
      icon: <Heart className="h-5 w-5 mr-3" />,
    },
    {
      name: "Recipe Suggestions",
      path: "/recipes",
      icon: <BookOpen className="h-5 w-5 mr-3" />,
    },
    {
      name: "Donation Map",
      path: "/map",
      icon: <Map className="h-5 w-5 mr-3" />,
    },
    {
      name: "Education Hub",
      path: "/education",
      icon: <Info className="h-5 w-5 mr-3" />,
    },
    {
      name: "Impact Statistics",
      path: "/impact",
      icon: <BarChart3 className="h-5 w-5 mr-3" />,
    },
  ];

  return (
    <div className={cn("hidden md:flex flex-col w-64 bg-white border-r border-neutral-200", className)}>
      <div className="flex items-center justify-center h-16 border-b border-neutral-200">
        <h1 className="text-xl font-heading font-bold text-primary-600 flex items-center">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-8 w-8 mr-2"
            viewBox="0 0 20 20"
            fill="currentColor"
          >
            <path
              fillRule="evenodd"
              d="M3.293 9.707a1 1 0 010-1.414l6-6a1 1 0 011.414 0l6 6a1 1 0 01-1.414 1.414L11 5.414V17a1 1 0 11-2 0V5.414L4.707 9.707a1 1 0 01-1.414 0z"
              clipRule="evenodd"
            />
          </svg>
          FoodSaver
        </h1>
      </div>

      <div className="px-4 py-2 border-b border-neutral-200">
        <div className="flex items-center space-x-3 p-3 bg-primary-50 rounded-lg">
          <Avatar>
            <AvatarFallback className="bg-primary-100 text-primary-600">
              {user?.name?.charAt(0) || user?.username?.charAt(0) || "U"}
            </AvatarFallback>
          </Avatar>
          <div>
            <p className="text-sm font-medium text-neutral-900">{user?.name}</p>
            <p className="text-xs text-neutral-500 capitalize">{user?.role}</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto p-4">
        <div className="space-y-1">
          <h3 className="text-xs font-medium text-neutral-500 uppercase tracking-wider mb-2">
            Main Menu
          </h3>

          {routes.map((route) => (
            <Link
              key={route.path}
              href={route.path}
              className={cn(
                "flex items-center px-3 py-2 text-sm font-medium rounded-md",
                route.path === location
                  ? "bg-primary-50 text-primary-700"
                  : "text-neutral-700 hover:bg-neutral-100"
              )}
            >
              {route.icon}
              {route.name}
            </Link>
          ))}
        </div>
      </nav>

      <div className="p-4 border-t border-neutral-200">
        <Link
          href="/settings"
          className={cn(
            "flex items-center px-3 py-2 text-sm font-medium rounded-md",
            location === "/settings"
              ? "bg-primary-50 text-primary-700"
              : "text-neutral-700 hover:bg-neutral-100"
          )}
        >
          <Settings className="h-5 w-5 mr-3" />
          Settings
        </Link>

        <button
          onClick={handleLogout}
          className="flex items-center px-3 py-2 text-sm font-medium rounded-md text-red-600 hover:bg-red-50 w-full mt-2"
        >
          <LogOut className="h-5 w-5 mr-3" />
          Logout
        </button>
      </div>
    </div>
  );
}
