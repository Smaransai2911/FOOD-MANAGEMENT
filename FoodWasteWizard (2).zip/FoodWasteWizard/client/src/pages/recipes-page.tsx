import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Recipe, FoodItem } from "@shared/schema";
import { Layout } from "@/components/layout";
import { RecipeCard } from "@/components/dashboard/recipe-card";
import { useToast } from "@/hooks/use-toast";
import { 
  Search, 
  FilterX, 
  Clock, 
  ChefHat, 
  Loader2, 
  BookOpen 
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";

export default function RecipesPage() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [difficultyFilter, setDifficultyFilter] = useState("");
  const [timeFilter, setTimeFilter] = useState("");
  const [showRecipeDialog, setShowRecipeDialog] = useState(false);
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);

  // Fetch recipes
  const { data: recipes, isLoading: isLoadingRecipes } = useQuery<Recipe[]>({
    queryKey: ["/api/recipes"],
  });

  // Fetch food items (for matching recipes)
  const { data: foodItems, isLoading: isLoadingFoodItems } = useQuery<FoodItem[]>({
    queryKey: ["/api/food-items"],
  });

  // Get expiring food items
  const expiringItems = foodItems
    ? foodItems.filter((item) => {
        const expiryDate = new Date(item.expiryDate);
        const today = new Date();
        const daysUntilExpiry = Math.floor(
          (expiryDate.getTime() - today.getTime()) / (1000 * 3600 * 24)
        );
        return daysUntilExpiry <= 7;
      })
    : [];

  const handleViewRecipe = (recipe: Recipe) => {
    setSelectedRecipe(recipe);
    setShowRecipeDialog(true);
  };

  // Filter recipes based on search and filters
  const filteredRecipes = recipes
    ? recipes.filter((recipe) => {
        const matchesSearch =
          recipe.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          recipe.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
          recipe.ingredients.toLowerCase().includes(searchTerm.toLowerCase());
        
        const matchesDifficulty = !difficultyFilter || recipe.difficulty === difficultyFilter;
        
        const matchesTime = !timeFilter || 
          (timeFilter === "under15" && recipe.prepTime <= 15) ||
          (timeFilter === "under30" && recipe.prepTime <= 30) ||
          (timeFilter === "under60" && recipe.prepTime <= 60) ||
          (timeFilter === "over60" && recipe.prepTime > 60);
        
        return matchesSearch && matchesDifficulty && matchesTime;
      })
    : [];

  // Count matching ingredients for each recipe
  const getExpiringItemsCount = (recipe: Recipe) => {
    if (!expiringItems.length) return 0;
    
    return expiringItems.filter((item) => 
      recipe.ingredients.toLowerCase().includes(item.name.toLowerCase())
    ).length;
  };

  // Sort recipes by expiring items count (descending)
  const sortedRecipes = [...filteredRecipes].sort((a, b) => {
    const aCount = getExpiringItemsCount(a);
    const bCount = getExpiringItemsCount(b);
    return bCount - aCount;
  });

  return (
    <Layout>
      <div className="py-6">
        {/* Page Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <div>
            <h2 className="text-2xl font-heading font-bold text-neutral-900">Recipe Suggestions</h2>
            <p className="mt-1 text-sm text-neutral-600">Discover recipes to use your expiring ingredients</p>
          </div>
        </div>

        {/* Filters and Search */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row md:items-center gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-neutral-400" />
                <Input
                  placeholder="Search recipes or ingredients..."
                  className="pl-9"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <Select value={difficultyFilter} onValueChange={setDifficultyFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Any Difficulty" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Any Difficulty</SelectItem>
                  <SelectItem value="easy">Easy</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="hard">Hard</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={timeFilter} onValueChange={setTimeFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Any Time" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Any Time</SelectItem>
                  <SelectItem value="under15">Under 15 mins</SelectItem>
                  <SelectItem value="under30">Under 30 mins</SelectItem>
                  <SelectItem value="under60">Under 60 mins</SelectItem>
                  <SelectItem value="over60">Over 60 mins</SelectItem>
                </SelectContent>
              </Select>
              
              <Button variant="outline" onClick={() => {
                setSearchTerm("");
                setDifficultyFilter("");
                setTimeFilter("");
              }}>
                <FilterX className="h-4 w-4 mr-2" />
                Reset
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Expiring Ingredients Section */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Expiring Ingredients</CardTitle>
            <CardDescription>
              Recipes are prioritized to use these ingredients
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingFoodItems ? (
              <div className="flex justify-center py-4">
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
              </div>
            ) : expiringItems.length > 0 ? (
              <div className="flex flex-wrap gap-2">
                {expiringItems.map((item) => (
                  <Badge key={item.id} variant="outline" className="bg-neutral-100">
                    {item.name}
                  </Badge>
                ))}
              </div>
            ) : (
              <p className="text-neutral-500">
                No ingredients expiring soon. Great job managing your inventory!
              </p>
            )}
          </CardContent>
        </Card>

        {/* Recipes Grid */}
        <div className="mb-6">
          {isLoadingRecipes ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : sortedRecipes.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {sortedRecipes.map((recipe) => (
                <RecipeCard
                  key={recipe.id}
                  recipe={recipe}
                  expiringItemsCount={getExpiringItemsCount(recipe)}
                  onClick={handleViewRecipe}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-8 bg-white rounded-lg shadow">
              <BookOpen className="h-12 w-12 text-neutral-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-neutral-900 mb-1">No recipes found</h3>
              <p className="text-neutral-500 mb-4">
                {searchTerm || difficultyFilter || timeFilter
                  ? "Try changing your search or filter criteria"
                  : "No recipes are available at the moment"}
              </p>
              {(searchTerm || difficultyFilter || timeFilter) && (
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setSearchTerm("");
                    setDifficultyFilter("");
                    setTimeFilter("");
                  }}
                >
                  Clear Filters
                </Button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Recipe Details Dialog */}
      <Dialog open={showRecipeDialog} onOpenChange={setShowRecipeDialog}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>{selectedRecipe?.name}</DialogTitle>
            <DialogDescription>
              {selectedRecipe?.description}
            </DialogDescription>
          </DialogHeader>
          
          {selectedRecipe && (
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-medium mb-2">Preparation Time</h4>
                <p className="flex items-center text-sm">
                  <Clock className="h-4 w-4 mr-2 text-neutral-500" />
                  {selectedRecipe.prepTime} minutes | 
                  <span className="ml-1 capitalize">{selectedRecipe.difficulty} difficulty</span>
                </p>
              </div>
              
              <div>
                <h4 className="text-sm font-medium mb-2">Ingredients</h4>
                <ul className="list-disc pl-5 space-y-1">
                  {selectedRecipe.ingredients.split(',').map((ingredient, index) => (
                    <li key={index} className="text-sm">{ingredient.trim()}</li>
                  ))}
                </ul>
              </div>
              
              <div>
                <h4 className="text-sm font-medium mb-2">Instructions</h4>
                <div className="text-sm space-y-2">
                  {selectedRecipe.instructions.split('\n').map((step, index) => (
                    <p key={index}>{step}</p>
                  ))}
                </div>
              </div>
              
              <div className="flex justify-end space-x-2 pt-4">
                <Button onClick={() => setShowRecipeDialog(false)}>Close</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
