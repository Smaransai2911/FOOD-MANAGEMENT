import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '../lib/queryClient';

export default function MapPage() {
  const [filterType, setFilterType] = useState('all');
  const [selectedLocation, setSelectedLocation] = useState(null);
  
  // Fetch donation locations
  const { data: locations = [], isLoading } = useQuery({
    queryKey: ['/api/donation-locations'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/donation-locations');
      return await res.json();
    }
  });
  
  // Filter locations by type
  const filteredLocations = filterType === 'all' 
    ? locations 
    : locations.filter(location => location.type === filterType);
  
  // Unique types of locations
  const locationTypes = ['all', ...new Set(locations.map(location => location.type))];
  
  // Show location details
  const handleLocationClick = (location) => {
    setSelectedLocation(location);
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">Donation Map</h1>
          <p className="text-muted-foreground">
            Find nearby locations to donate food
          </p>
        </div>
      </div>
      
      {/* Filters */}
      <div className="bg-card rounded-lg shadow p-4 mb-6">
        <div className="flex flex-wrap gap-2">
          {locationTypes.map((type) => (
            <button
              key={type}
              className={`px-4 py-2 rounded-md ${
                filterType === type 
                  ? 'bg-primary text-white' 
                  : 'bg-muted hover:bg-muted/80'
              }`}
              onClick={() => setFilterType(type)}
            >
              {type === 'all' ? 'All Locations' : type.charAt(0).toUpperCase() + type.slice(1)}
            </button>
          ))}
        </div>
      </div>
      
      {/* Map Interface */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Location List */}
        <div className="bg-card rounded-lg shadow overflow-hidden">
          <div className="p-3 bg-muted border-b">
            <h2 className="font-medium">
              {filteredLocations.length} {filterType === 'all' ? 'Locations' : filterType.charAt(0).toUpperCase() + filterType.slice(1) + 's'}
            </h2>
          </div>
          
          {isLoading ? (
            <div className="p-6 flex justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
            </div>
          ) : filteredLocations.length === 0 ? (
            <div className="p-6 text-center text-muted-foreground">
              No locations found. Try a different filter.
            </div>
          ) : (
            <div className="overflow-y-auto max-h-[70vh]">
              {filteredLocations.map(location => (
                <div 
                  key={location.id}
                  className={`p-4 border-b cursor-pointer hover:bg-muted/50 ${
                    selectedLocation?.id === location.id ? 'bg-primary/10' : ''
                  }`}
                  onClick={() => handleLocationClick(location)}
                >
                  <h3 className="font-medium">{location.name}</h3>
                  <p className="text-sm text-muted-foreground capitalize">{location.type}</p>
                  <p className="text-sm mt-1">{location.address}</p>
                  
                  {location.distance && (
                    <div className="mt-2 text-sm text-primary">
                      {location.distance.toFixed(1)} miles away
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
        
        {/* Map Area */}
        <div className="md:col-span-2 bg-card rounded-lg shadow overflow-hidden h-[500px] md:h-auto md:min-h-[500px]">
          {/* 
            Note: In a real implementation, use a mapping library like Leaflet, Google Maps, or Mapbox.
            For now, this is a placeholder that would be replaced with an actual map.
          */}
          <div className="h-full bg-gray-200 flex items-center justify-center">
            <div className="text-center p-6">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-16 w-16 mx-auto text-muted-foreground mb-4"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"
                />
              </svg>
              <h3 className="text-xl font-medium mb-2">Map Display</h3>
              <p className="text-muted-foreground mb-4">
                The map would display donation locations here
              </p>
              {selectedLocation && (
                <div className="bg-white p-4 rounded-lg shadow max-w-sm mx-auto text-left">
                  <h4 className="font-medium">{selectedLocation.name}</h4>
                  <p className="text-sm text-muted-foreground capitalize">{selectedLocation.type}</p>
                  <p className="text-sm mt-1">{selectedLocation.address}</p>
                  
                  {selectedLocation.phone && (
                    <p className="text-sm mt-2">
                      <span className="font-medium">Phone: </span>
                      {selectedLocation.phone}
                    </p>
                  )}
                  
                  {selectedLocation.email && (
                    <p className="text-sm mt-1">
                      <span className="font-medium">Email: </span>
                      {selectedLocation.email}
                    </p>
                  )}
                  
                  {selectedLocation.hours && (
                    <p className="text-sm mt-1">
                      <span className="font-medium">Hours: </span>
                      {selectedLocation.hours}
                    </p>
                  )}
                  
                  <div className="mt-3">
                    <a 
                      href={`https://maps.google.com/?q=${selectedLocation.address}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary text-sm font-medium"
                    >
                      Get Directions →
                    </a>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* Information Section */}
      <div className="mt-8 bg-card rounded-lg shadow p-6">
        <h2 className="text-xl font-bold mb-4">Donation Guidelines</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="font-medium mb-3">What to Donate</h3>
            <ul className="list-disc list-inside space-y-2 text-muted-foreground">
              <li>Non-perishable food items (canned goods, rice, pasta)</li>
              <li>Fresh produce (fruits and vegetables)</li>
              <li>Refrigerated items (dairy products, meats) that are unexpired</li>
              <li>Frozen foods (properly stored and transported)</li>
              <li>Packaged foods (cereals, snacks) within expiration dates</li>
              <li>Beverages (non-alcoholic)</li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-medium mb-3">How to Donate</h3>
            <ol className="list-decimal list-inside space-y-2 text-muted-foreground">
              <li>Check that food items are clean and unopened</li>
              <li>Ensure all items are within their expiration date</li>
              <li>Use clean containers for transport</li>
              <li>Contact the donation center before bringing perishable items</li>
              <li>Follow any specific guidelines from the receiving organization</li>
              <li>Keep temperature-sensitive items properly cooled during transport</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
}