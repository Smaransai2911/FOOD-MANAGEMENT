import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { DonationLocation } from "@shared/schema";
import { Layout } from "@/components/layout";
import { useToast } from "@/hooks/use-toast";
import { 
  MapPin, 
  Loader2, 
  ChevronDown, 
  Phone, 
  Mail, 
  Clock, 
  Info 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

export default function MapPage() {
  const { toast } = useToast();
  const [typeFilter, setTypeFilter] = useState("");
  const [selectedLocation, setSelectedLocation] = useState<DonationLocation | null>(null);

  // Fetch donation locations
  const { data: locations, isLoading } = useQuery<DonationLocation[]>({
    queryKey: ["/api/donation-locations"],
  });

  // Filter locations by type
  const filteredLocations = locations
    ? typeFilter
      ? locations.filter((location) => location.type === typeFilter)
      : locations
    : [];

  // Group locations by type
  const locationsByType = filteredLocations.reduce((acc, location) => {
    const type = location.type;
    if (!acc[type]) {
      acc[type] = [];
    }
    acc[type].push(location);
    return acc;
  }, {} as Record<string, DonationLocation[]>);

  // Get location type label
  const getTypeLabel = (type: string) => {
    switch (type) {
      case "food_bank":
        return "Food Bank";
      case "shelter":
        return "Shelter";
      case "community_center":
        return "Community Center";
      case "school":
        return "School";
      default:
        return "Other";
    }
  };

  // Get location type color
  const getTypeColor = (type: string) => {
    switch (type) {
      case "food_bank":
        return "bg-primary-50 text-primary-700";
      case "shelter":
        return "bg-amber-50 text-amber-700";
      case "community_center":
        return "bg-blue-50 text-blue-700";
      case "school":
        return "bg-purple-50 text-purple-700";
      default:
        return "bg-gray-50 text-gray-700";
    }
  };

  return (
    <Layout>
      <div className="py-6">
        {/* Page Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <div>
            <h2 className="text-2xl font-heading font-bold text-neutral-900">Donation Map</h2>
            <p className="mt-1 text-sm text-neutral-600">Find locations accepting food donations near you</p>
          </div>
          
          <div className="mt-4 md:mt-0">
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="All Locations" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Locations</SelectItem>
                <SelectItem value="food_bank">Food Banks</SelectItem>
                <SelectItem value="shelter">Shelters</SelectItem>
                <SelectItem value="community_center">Community Centers</SelectItem>
                <SelectItem value="school">Schools</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Map and Locations Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Map */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Donation Locations</CardTitle>
              <CardDescription>
                Interactive map showing nearby donation locations
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex justify-center items-center h-96">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : (
                <div className="relative">
                  <div className="bg-neutral-100 h-96 rounded-md flex items-center justify-center">
                    <MapPin className="h-12 w-12 text-primary-500" />
                    <div className="absolute bottom-4 right-4 bg-white rounded-lg shadow-md p-4">
                      <div className="text-sm font-medium mb-2">Legend</div>
                      <div className="space-y-2">
                        <div className="flex items-center">
                          <span className="inline-block w-3 h-3 rounded-full bg-primary-500 mr-2"></span>
                          <span className="text-xs">Food Banks ({locationsByType.food_bank?.length || 0})</span>
                        </div>
                        <div className="flex items-center">
                          <span className="inline-block w-3 h-3 rounded-full bg-amber-500 mr-2"></span>
                          <span className="text-xs">Shelters ({locationsByType.shelter?.length || 0})</span>
                        </div>
                        <div className="flex items-center">
                          <span className="inline-block w-3 h-3 rounded-full bg-blue-500 mr-2"></span>
                          <span className="text-xs">Community Centers ({locationsByType.community_center?.length || 0})</span>
                        </div>
                        <div className="flex items-center">
                          <span className="inline-block w-3 h-3 rounded-full bg-purple-500 mr-2"></span>
                          <span className="text-xs">Schools ({locationsByType.school?.length || 0})</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="bg-primary-50 p-3 rounded-md text-center">
                  <p className="text-xs font-medium text-primary-600">Food Banks</p>
                  <p className="text-lg font-heading font-bold text-primary-800">
                    {locationsByType.food_bank?.length || 0}
                  </p>
                </div>
                
                <div className="bg-amber-50 p-3 rounded-md text-center">
                  <p className="text-xs font-medium text-amber-600">Shelters</p>
                  <p className="text-lg font-heading font-bold text-amber-800">
                    {locationsByType.shelter?.length || 0}
                  </p>
                </div>
                
                <div className="bg-blue-50 p-3 rounded-md text-center">
                  <p className="text-xs font-medium text-blue-600">Community Centers</p>
                  <p className="text-lg font-heading font-bold text-blue-800">
                    {locationsByType.community_center?.length || 0}
                  </p>
                </div>
                
                <div className="bg-purple-50 p-3 rounded-md text-center">
                  <p className="text-xs font-medium text-purple-600">Schools</p>
                  <p className="text-lg font-heading font-bold text-purple-800">
                    {locationsByType.school?.length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Locations List */}
          <Card>
            <CardHeader>
              <CardTitle>Locations List</CardTitle>
              <CardDescription>
                Organizations accepting food donations
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : filteredLocations.length > 0 ? (
                <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2">
                  {filteredLocations.map((location) => (
                    <Collapsible
                      key={location.id}
                      className="border rounded-lg overflow-hidden"
                      open={selectedLocation?.id === location.id}
                      onOpenChange={(open) => setSelectedLocation(open ? location : null)}
                    >
                      <div className={`${getTypeColor(location.type)} px-3 py-1 text-xs font-semibold`}>
                        {getTypeLabel(location.type)}
                      </div>
                      <div className="p-4">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="font-medium">{location.name}</h3>
                          <CollapsibleTrigger asChild>
                            <Button variant="ghost" size="sm" className="p-0 h-6 w-6">
                              <ChevronDown className="h-4 w-4" />
                              <span className="sr-only">Toggle</span>
                            </Button>
                          </CollapsibleTrigger>
                        </div>
                        <p className="text-sm text-neutral-500 flex items-start mb-2">
                          <MapPin className="h-4 w-4 mr-1 mt-0.5 flex-shrink-0" />
                          {location.address}
                        </p>
                        
                        <CollapsibleContent>
                          <div className="mt-4 pt-4 border-t space-y-3">
                            {location.contactPerson && (
                              <p className="text-sm">
                                <span className="font-medium">Contact: </span>
                                {location.contactPerson}
                              </p>
                            )}
                            
                            {location.phone && (
                              <p className="text-sm flex items-center">
                                <Phone className="h-4 w-4 mr-2 text-neutral-400" />
                                {location.phone}
                              </p>
                            )}
                            
                            {location.email && (
                              <p className="text-sm flex items-center">
                                <Mail className="h-4 w-4 mr-2 text-neutral-400" />
                                {location.email}
                              </p>
                            )}
                            
                            {location.operatingHours && (
                              <p className="text-sm flex items-center">
                                <Clock className="h-4 w-4 mr-2 text-neutral-400" />
                                {location.operatingHours}
                              </p>
                            )}
                            
                            {location.acceptsFoodTypes && (
                              <div>
                                <p className="text-sm font-medium mb-1 flex items-center">
                                  <Info className="h-4 w-4 mr-2 text-neutral-400" />
                                  Accepted Food Types
                                </p>
                                <div className="flex flex-wrap gap-1 mt-1">
                                  {location.acceptsFoodTypes.split(',').map((type, index) => (
                                    <Badge key={index} variant="outline" className="text-xs">
                                      {type.trim()}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                            )}
                            
                            <div className="pt-2">
                              <Button size="sm" className="w-full">Get Directions</Button>
                            </div>
                          </div>
                        </CollapsibleContent>
                      </div>
                    </Collapsible>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <MapPin className="h-12 w-12 text-neutral-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-neutral-900 mb-1">No locations found</h3>
                  <p className="text-neutral-500 mb-4">
                    {typeFilter
                      ? `No ${getTypeLabel(typeFilter).toLowerCase()} locations found`
                      : "No donation locations available at the moment"}
                  </p>
                  {typeFilter && (
                    <Button 
                      variant="outline" 
                      onClick={() => setTypeFilter("")}
                    >
                      Show All Locations
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
