import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { FoodItem } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Layout } from "@/components/layout";
import { FoodItemForm } from "@/components/forms/food-item-form";
import { useToast } from "@/hooks/use-toast";
import { format, differenceInDays } from "date-fns";
import { 
  Plus, 
  Search, 
  FilterX, 
  Trash2, 
  Edit, 
  ArrowUpDown,
  Calendar,
  Package2,
  Circle,
  Loader2,
  Share2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

export default function InventoryPage() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("");
  const [sortBy, setSortBy] = useState<string>("expiryDate");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [selectedItem, setSelectedItem] = useState<FoodItem | null>(null);

  // Fetch food items
  const { data: foodItems, isLoading } = useQuery<FoodItem[]>({
    queryKey: ["/api/food-items"],
  });

  // Add food item mutation
  const addFoodItemMutation = useMutation({
    mutationFn: async (formData: Partial<FoodItem>) => {
      const res = await apiRequest("POST", "/api/food-items", formData);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Food item added successfully",
      });
      setShowAddDialog(false);
      queryClient.invalidateQueries({ queryKey: ["/api/food-items"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update food item mutation
  const updateFoodItemMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<FoodItem> }) => {
      const res = await apiRequest("PUT", `/api/food-items/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Food item updated successfully",
      });
      setShowEditDialog(false);
      queryClient.invalidateQueries({ queryKey: ["/api/food-items"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Delete food item mutation
  const deleteFoodItemMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/food-items/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Food item deleted successfully",
      });
      setShowDeleteDialog(false);
      queryClient.invalidateQueries({ queryKey: ["/api/food-items"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Mark food as available for donation
  const markForDonationMutation = useMutation({
    mutationFn: async (itemId: number) => {
      const res = await apiRequest("PUT", `/api/food-items/${itemId}`, {
        isAvailableForDonation: true,
      });
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Item marked as available for donation",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/food-items"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleAddItem = (formData: Partial<FoodItem>) => {
    addFoodItemMutation.mutate(formData);
  };

  const handleEditItem = (formData: Partial<FoodItem>) => {
    if (selectedItem) {
      updateFoodItemMutation.mutate({ id: selectedItem.id, data: formData });
    }
  };

  const handleDeleteItem = () => {
    if (selectedItem) {
      deleteFoodItemMutation.mutate(selectedItem.id);
    }
  };

  const handleMarkForDonation = (item: FoodItem) => {
    markForDonationMutation.mutate(item.id);
  };

  const openEditDialog = (item: FoodItem) => {
    setSelectedItem(item);
    setShowEditDialog(true);
  };

  const openDeleteDialog = (item: FoodItem) => {
    setSelectedItem(item);
    setShowDeleteDialog(true);
  };

  // Filter and sort food items
  const filteredAndSortedItems = foodItems
    ? foodItems
        .filter((item) => {
          const matchesSearch = item.name
            .toLowerCase()
            .includes(searchTerm.toLowerCase());
          const matchesCategory = !categoryFilter || item.category === categoryFilter;
          return matchesSearch && matchesCategory;
        })
        .sort((a, b) => {
          if (sortBy === "name") {
            return sortOrder === "asc"
              ? a.name.localeCompare(b.name)
              : b.name.localeCompare(a.name);
          } else if (sortBy === "expiryDate") {
            return sortOrder === "asc"
              ? new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime()
              : new Date(b.expiryDate).getTime() - new Date(a.expiryDate).getTime();
          } else if (sortBy === "category") {
            return sortOrder === "asc"
              ? a.category.localeCompare(b.category)
              : b.category.localeCompare(a.category);
          }
          return 0;
        })
    : [];

  const getExpiryStatusBadge = (expiryDate: Date) => {
    const daysUntilExpiry = differenceInDays(new Date(expiryDate), new Date());
    
    if (daysUntilExpiry < 0) {
      return <Badge variant="destructive">Expired</Badge>;
    } else if (daysUntilExpiry === 0) {
      return <Badge variant="destructive">Expires Today</Badge>;
    } else if (daysUntilExpiry <= 3) {
      return <Badge variant="destructive">Expires Soon</Badge>;
    } else if (daysUntilExpiry <= 7) {
      return <Badge variant="warning" className="bg-yellow-500">Expiring</Badge>;
    } else {
      return <Badge variant="outline">Good</Badge>;
    }
  };

  const getCategoryBadge = (category: string) => {
    const colors: Record<string, string> = {
      vegetables: "bg-green-100 text-green-800",
      fruits: "bg-yellow-100 text-yellow-800",
      dairy: "bg-blue-100 text-blue-800",
      grains: "bg-amber-100 text-amber-800",
      protein: "bg-red-100 text-red-800",
      bakery: "bg-orange-100 text-orange-800",
      canned: "bg-purple-100 text-purple-800",
      frozen: "bg-sky-100 text-sky-800",
      beverages: "bg-indigo-100 text-indigo-800",
      other: "bg-gray-100 text-gray-800",
    };

    return (
      <span className={`px-2 py-1 text-xs font-medium rounded-full ${colors[category] || colors.other}`}>
        {category.charAt(0).toUpperCase() + category.slice(1)}
      </span>
    );
  };

  return (
    <Layout>
      <div className="py-6">
        {/* Page Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <div>
            <h2 className="text-2xl font-heading font-bold text-neutral-900">Food Inventory</h2>
            <p className="mt-1 text-sm text-neutral-600">Manage your food items and track expiry dates</p>
          </div>
          
          <div className="mt-4 md:mt-0">
            <Button 
              onClick={() => setShowAddDialog(true)}
              className="inline-flex items-center"
            >
              <Plus className="h-5 w-5 mr-2" />
              Add Food Item
            </Button>
          </div>
        </div>

        {/* Filters and Search */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row md:items-center gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-neutral-400" />
                <Input
                  placeholder="Search items..."
                  className="pl-9"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Categories</SelectItem>
                  <SelectItem value="vegetables">Vegetables</SelectItem>
                  <SelectItem value="fruits">Fruits</SelectItem>
                  <SelectItem value="dairy">Dairy</SelectItem>
                  <SelectItem value="grains">Grains</SelectItem>
                  <SelectItem value="protein">Protein</SelectItem>
                  <SelectItem value="bakery">Bakery</SelectItem>
                  <SelectItem value="canned">Canned Goods</SelectItem>
                  <SelectItem value="frozen">Frozen</SelectItem>
                  <SelectItem value="beverages">Beverages</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="flex items-center">
                    <ArrowUpDown className="h-4 w-4 mr-2" />
                    Sort By
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>Sort Options</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => { setSortBy("name"); setSortOrder("asc"); }}>
                    Name (A-Z)
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => { setSortBy("name"); setSortOrder("desc"); }}>
                    Name (Z-A)
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => { setSortBy("expiryDate"); setSortOrder("asc"); }}>
                    Expiry Date (Earliest First)
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => { setSortBy("expiryDate"); setSortOrder("desc"); }}>
                    Expiry Date (Latest First)
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => { setSortBy("category"); setSortOrder("asc"); }}>
                    Category (A-Z)
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              
              <Button variant="outline" onClick={() => {
                setSearchTerm("");
                setCategoryFilter("");
                setSortBy("expiryDate");
                setSortOrder("asc");
              }}>
                <FilterX className="h-4 w-4 mr-2" />
                Reset
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Inventory Table */}
        <Card>
          <CardHeader>
            <CardTitle>Your Food Items</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : filteredAndSortedItems.length > 0 ? (
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[200px]">Name</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Quantity</TableHead>
                      <TableHead>Expiry Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAndSortedItems.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.name}</TableCell>
                        <TableCell>{getCategoryBadge(item.category)}</TableCell>
                        <TableCell>
                          {item.quantity} {item.unit}
                        </TableCell>
                        <TableCell>
                          {format(new Date(item.expiryDate), "MMM dd, yyyy")}
                        </TableCell>
                        <TableCell>
                          {getExpiryStatusBadge(new Date(item.expiryDate))}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end items-center space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleMarkForDonation(item)}
                              disabled={item.isAvailableForDonation}
                            >
                              <Share2 className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => openEditDialog(item)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              className="text-red-500 hover:text-red-600"
                              onClick={() => openDeleteDialog(item)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="text-center py-8">
                <Package2 className="h-12 w-12 text-neutral-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-neutral-900 mb-1">No food items found</h3>
                <p className="text-neutral-500 mb-4">
                  {searchTerm || categoryFilter
                    ? "Try changing your search or filter criteria"
                    : "Add some items to your inventory to get started"}
                </p>
                <Button onClick={() => setShowAddDialog(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Food Item
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Add Food Item Dialog */}
      <FoodItemForm
        open={showAddDialog}
        onOpenChange={setShowAddDialog}
        onSubmit={handleAddItem}
        isLoading={addFoodItemMutation.isPending}
      />

      {/* Edit Food Item Dialog */}
      <FoodItemForm
        open={showEditDialog}
        onOpenChange={setShowEditDialog}
        onSubmit={handleEditItem}
        initialData={selectedItem || undefined}
        isLoading={updateFoodItemMutation.isPending}
      />

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete {selectedItem?.name}? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleDeleteItem}
              disabled={deleteFoodItemMutation.isPending}
            >
              {deleteFoodItemMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
