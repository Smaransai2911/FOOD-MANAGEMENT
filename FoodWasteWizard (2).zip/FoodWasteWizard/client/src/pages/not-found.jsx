import React from 'react';
import { Link } from 'wouter';

export default function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-background text-foreground">
      <div className="container px-4 py-8 mx-auto text-center">
        <h1 className="text-6xl font-bold mb-6">404</h1>
        <h2 className="text-2xl font-semibold mb-4">Page Not Found</h2>
        <p className="text-muted-foreground mb-8">
          The page you are looking for doesn't exist or has been moved.
        </p>
        <div className="flex gap-4 justify-center">
          <Link href="/">
            <a className="px-6 py-3 rounded-md bg-primary text-primary-foreground hover:bg-primary/90 transition-colors">
              Back to Home
            </a>
          </Link>
        </div>
      </div>
    </div>
  );
}