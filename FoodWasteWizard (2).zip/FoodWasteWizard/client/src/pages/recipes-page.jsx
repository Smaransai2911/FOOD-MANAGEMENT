import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '../lib/queryClient';
import { daysUntilExpiry } from '../lib/utils';

export default function RecipesPage() {
  const [showRecipeModal, setShowRecipeModal] = useState(false);
  const [selectedRecipe, setSelectedRecipe] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterIngredients, setFilterIngredients] = useState([]);
  
  // Fetch recipes
  const { data: recipes = [], isLoading: isLoadingRecipes } = useQuery({
    queryKey: ['/api/recipes'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/recipes');
      return await res.json();
    }
  });
  
  // Fetch user's inventory
  const { data: inventory = [], isLoading: isLoadingInventory } = useQuery({
    queryKey: ['/api/inventory'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/inventory');
      return await res.json();
    }
  });
  
  // Filter recipes based on search term and filter ingredients
  const filteredRecipes = recipes.filter(recipe => {
    const matchesSearch = recipe.name.toLowerCase().includes(searchTerm.toLowerCase());
    
    // If no ingredients are selected for filtering, return all recipes that match the search
    if (filterIngredients.length === 0) {
      return matchesSearch;
    }
    
    // Check if recipe has at least one of the selected ingredients
    const hasIngredients = filterIngredients.some(ingredientName => 
      recipe.ingredients.some(ri => ri.name.toLowerCase().includes(ingredientName.toLowerCase()))
    );
    
    return matchesSearch && hasIngredients;
  });
  
  // Display recipe details
  const handleViewRecipe = (recipe) => {
    setSelectedRecipe(recipe);
    setShowRecipeModal(true);
  };
  
  // Get unique ingredients from inventory for filtering
  const uniqueIngredients = [...new Set(inventory.map(item => item.name))];
  
  // Toggle ingredient selection for filtering
  const toggleIngredientFilter = (ingredient) => {
    setFilterIngredients(prev => 
      prev.includes(ingredient)
        ? prev.filter(i => i !== ingredient)
        : [...prev, ingredient]
    );
  };
  
  // Check if a recipe can be made with inventory
  const getUserIngredientsStatus = (recipe) => {
    if (!recipe.ingredients || recipe.ingredients.length === 0) {
      return {
        percentage: 0,
        missingIngredients: []
      };
    }
    
    const totalIngredients = recipe.ingredients.length;
    const userIngredients = inventory.map(item => item.name.toLowerCase());
    
    const missingIngredients = recipe.ingredients.filter(
      ingredient => !userIngredients.includes(ingredient.name.toLowerCase())
    );
    
    const matchingCount = totalIngredients - missingIngredients.length;
    const percentage = Math.round((matchingCount / totalIngredients) * 100);
    
    return {
      percentage,
      missingIngredients
    };
  };
  
  // Get the count of expiring items that can be used in a recipe
  const getExpiringItemsCount = (recipe) => {
    if (!recipe.ingredients || !inventory || inventory.length === 0) {
      return 0;
    }
    
    // Get ingredient names from recipe
    const recipeIngredientNames = recipe.ingredients.map(i => i.name.toLowerCase());
    
    // Find inventory items that are expiring soon (within 5 days) and are used in this recipe
    const expiringItems = inventory.filter(item => {
      const days = daysUntilExpiry(item.expiryDate);
      return days >= 0 && days <= 5 && recipeIngredientNames.includes(item.name.toLowerCase());
    });
    
    return expiringItems.length;
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">Recipes</h1>
          <p className="text-muted-foreground">
            Find recipes based on ingredients you have
          </p>
        </div>
      </div>
      
      {/* Search and Filters */}
      <div className="bg-card rounded-lg shadow p-4 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="search" className="block text-sm font-medium mb-1">
              Search Recipes
            </label>
            <div className="relative">
              <input
                id="search"
                type="text"
                placeholder="Search by recipe name..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-3 py-2 border rounded-md pl-10"
              />
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                />
              </svg>
            </div>
          </div>
          
          {uniqueIngredients.length > 0 && (
            <div>
              <label className="block text-sm font-medium mb-1">
                Filter by Ingredients You Have
              </label>
              <div className="flex flex-wrap gap-2 max-h-24 overflow-y-auto p-1">
                {uniqueIngredients.map((ingredient) => (
                  <button
                    key={ingredient}
                    className={`px-2 py-1 text-xs rounded-full ${
                      filterIngredients.includes(ingredient)
                        ? 'bg-primary text-white'
                        : 'bg-muted text-muted-foreground hover:bg-muted/80'
                    }`}
                    onClick={() => toggleIngredientFilter(ingredient)}
                  >
                    {ingredient}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Recipes Grid */}
      {isLoadingRecipes ? (
        <div className="flex justify-center py-8">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </div>
      ) : filteredRecipes.length === 0 ? (
        <div className="bg-card rounded-lg shadow p-8 text-center">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-16 w-16 mx-auto text-muted-foreground mb-4"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"
            />
          </svg>
          <h3 className="text-xl font-medium mb-2">No recipes found</h3>
          <p className="text-muted-foreground">
            Try changing your search or filter criteria
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredRecipes.map((recipe) => {
            const ingredientStatus = getUserIngredientsStatus(recipe);
            const expiringItemsCount = getExpiringItemsCount(recipe);
            
            return (
              <div key={recipe.id} className="bg-card rounded-lg shadow overflow-hidden">
                <div className="h-48 overflow-hidden relative">
                  <img
                    src={recipe.imageUrl || '/img/default-recipe.jpg'}
                    alt={recipe.name}
                    className="w-full h-full object-cover"
                  />
                  {expiringItemsCount > 0 && (
                    <span className="absolute top-2 right-2 bg-red-600 text-white text-xs px-2 py-1 rounded-full">
                      Uses {expiringItemsCount} expiring {expiringItemsCount === 1 ? 'item' : 'items'}
                    </span>
                  )}
                </div>
                
                <div className="p-4">
                  <h3 className="font-bold text-xl mb-2">{recipe.name}</h3>
                  
                  <div className="flex items-center gap-1 mb-3">
                    <div className="text-yellow-500">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <span key={i}>
                          {i < Math.floor(recipe.rating) ? (
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 inline" viewBox="0 0 20 20" fill="currentColor">
                              <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                            </svg>
                          ) : (
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 inline" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                            </svg>
                          )}
                        </span>
                      ))}
                    </div>
                    <span className="text-sm text-muted-foreground">
                      ({recipe.reviewCount || 0} reviews)
                    </span>
                  </div>
                  
                  <p className="text-muted-foreground mb-3 line-clamp-2">
                    {recipe.description || 'No description available.'}
                  </p>
                  
                  <div className="mb-4">
                    <div className="flex justify-between text-sm mb-1">
                      <span>Ingredients match</span>
                      <span>{ingredientStatus.percentage}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full ${
                          ingredientStatus.percentage >= 75 ? 'bg-green-500' : 
                          ingredientStatus.percentage >= 50 ? 'bg-yellow-500' : 'bg-red-500'
                        }`}
                        style={{ width: `${ingredientStatus.percentage}%` }}
                      ></div>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <div className="text-sm">
                      <span className="text-muted-foreground">
                        Prep: {recipe.prepTime} min
                      </span>
                      {recipe.cookTime && (
                        <span className="text-muted-foreground ml-2">
                          Cook: {recipe.cookTime} min
                        </span>
                      )}
                    </div>
                    
                    <button
                      onClick={() => handleViewRecipe(recipe)}
                      className="px-3 py-1 text-sm bg-primary text-white rounded-md hover:bg-primary/90 transition"
                    >
                      View Recipe
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
      
      {/* Recipe Details Modal */}
      {showRecipeModal && selectedRecipe && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-card rounded-lg shadow-lg max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="p-4 border-b flex justify-between items-center">
              <h2 className="text-xl font-semibold">{selectedRecipe.name}</h2>
              <button 
                onClick={() => setShowRecipeModal(false)}
                className="text-muted-foreground hover:text-foreground"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            
            <div className="p-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <img
                    src={selectedRecipe.imageUrl || '/img/default-recipe.jpg'}
                    alt={selectedRecipe.name}
                    className="w-full h-64 object-cover rounded-md"
                  />
                </div>
                
                <div>
                  <div className="mb-4">
                    <h3 className="font-medium mb-2">Description</h3>
                    <p className="text-muted-foreground">
                      {selectedRecipe.description || 'No description available.'}
                    </p>
                  </div>
                  
                  <div className="mb-4">
                    <h3 className="font-medium mb-2">Details</h3>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <p className="text-sm text-muted-foreground">Prep Time</p>
                        <p>{selectedRecipe.prepTime} minutes</p>
                      </div>
                      
                      <div>
                        <p className="text-sm text-muted-foreground">Cook Time</p>
                        <p>{selectedRecipe.cookTime} minutes</p>
                      </div>
                      
                      <div>
                        <p className="text-sm text-muted-foreground">Servings</p>
                        <p>{selectedRecipe.servings}</p>
                      </div>
                      
                      <div>
                        <p className="text-sm text-muted-foreground">Difficulty</p>
                        <p className="capitalize">{selectedRecipe.difficulty || 'Medium'}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="font-medium mb-2">Nutrition (per serving)</h3>
                    <div className="grid grid-cols-4 gap-2">
                      <div>
                        <p className="text-sm text-muted-foreground">Calories</p>
                        <p>{selectedRecipe.calories || 'N/A'}</p>
                      </div>
                      
                      <div>
                        <p className="text-sm text-muted-foreground">Protein</p>
                        <p>{selectedRecipe.protein || 'N/A'}</p>
                      </div>
                      
                      <div>
                        <p className="text-sm text-muted-foreground">Carbs</p>
                        <p>{selectedRecipe.carbs || 'N/A'}</p>
                      </div>
                      
                      <div>
                        <p className="text-sm text-muted-foreground">Fat</p>
                        <p>{selectedRecipe.fat || 'N/A'}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div>
                  <h3 className="font-medium mb-3">Ingredients</h3>
                  <ul className="space-y-2">
                    {selectedRecipe.ingredients.map((ingredient, index) => {
                      const haveIngredient = inventory.some(
                        item => item.name.toLowerCase() === ingredient.name.toLowerCase()
                      );
                      
                      return (
                        <li 
                          key={index} 
                          className={`flex items-center ${haveIngredient ? 'text-green-600' : ''}`}
                        >
                          {haveIngredient && (
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                          )}
                          <span>
                            {ingredient.amount} {ingredient.unit} {ingredient.name}
                          </span>
                        </li>
                      );
                    })}
                  </ul>
                </div>
                
                <div className="md:col-span-2">
                  <h3 className="font-medium mb-3">Instructions</h3>
                  <ol className="space-y-4 list-decimal list-inside">
                    {selectedRecipe.instructions.map((instruction, index) => (
                      <li key={index} className="pl-1">
                        {instruction}
                      </li>
                    ))}
                  </ol>
                </div>
              </div>
              
              {selectedRecipe.tips && (
                <div className="mb-6">
                  <h3 className="font-medium mb-3">Tips</h3>
                  <ul className="space-y-2 list-disc list-inside">
                    {selectedRecipe.tips.map((tip, index) => (
                      <li key={index} className="pl-1 text-muted-foreground">
                        {tip}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}