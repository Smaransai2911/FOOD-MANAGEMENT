import React, { useState, useEffect } from 'react';
import { useAuth } from '../hooks/use-auth.jsx';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '../lib/queryClient';
import toast from 'react-hot-toast';

export default function SettingsPage() {
  const { user, refetchUser } = useAuth();
  const [activeTab, setActiveTab] = useState('profile');
  
  // Profile form state
  const [profileForm, setProfileForm] = useState({
    name: '',
    email: '',
    phone: '',
    location: ''
  });
  
  // Password form state
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  
  // Notification preferences state
  const [notificationPrefs, setNotificationPrefs] = useState({
    emailNotifications: true,
    expiryReminders: true,
    reminderDays: 3,
    donationUpdates: true,
    weeklyDigest: false,
    marketingEmails: false
  });
  
  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data) => {
      const res = await apiRequest('PATCH', '/users/profile', data);
      return await res.json();
    },
    onSuccess: () => {
      refetchUser();
      toast.success('Profile updated successfully');
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to update profile');
    }
  });
  
  // Update password mutation
  const updatePasswordMutation = useMutation({
    mutationFn: async (data) => {
      const res = await apiRequest('POST', '/users/change-password', data);
      return await res.json();
    },
    onSuccess: () => {
      setPasswordForm({
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
      });
      toast.success('Password changed successfully');
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to change password');
    }
  });
  
  // Update notification preferences mutation
  const updateNotificationPrefsMutation = useMutation({
    mutationFn: async (data) => {
      const res = await apiRequest('PATCH', '/users/notification-preferences', data);
      return await res.json();
    },
    onSuccess: () => {
      toast.success('Notification preferences updated');
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to update notification preferences');
    }
  });
  
  // Export data mutation
  const exportDataMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('GET', '/users/export-data');
      return await res.json();
    },
    onSuccess: (data) => {
      // Create download link for exported data
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(data));
      const downloadAnchorNode = document.createElement('a');
      downloadAnchorNode.setAttribute("href", dataStr);
      downloadAnchorNode.setAttribute("download", "food_waste_data.json");
      document.body.appendChild(downloadAnchorNode);
      downloadAnchorNode.click();
      downloadAnchorNode.remove();
      
      toast.success('Data exported successfully');
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to export data');
    }
  });
  
  // Delete account mutation
  const deleteAccountMutation = useMutation({
    mutationFn: async (data) => {
      const res = await apiRequest('POST', '/users/delete-account', data);
      return await res.json();
    },
    onSuccess: () => {
      window.location.href = '/auth';
      toast.success('Account deleted successfully');
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to delete account');
    }
  });
  
  // Initialize form with user data when available
  useEffect(() => {
    if (user) {
      setProfileForm({
        name: user.name || '',
        email: user.email || '',
        phone: user.phone || '',
        location: user.location || ''
      });
      
      // If notification preferences are available in user data
      if (user.notificationPreferences) {
        setNotificationPrefs(user.notificationPreferences);
      }
    }
  }, [user]);
  
  // Handle profile form input changes
  const handleProfileInputChange = (e) => {
    const { name, value } = e.target;
    setProfileForm(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // Handle password form input changes
  const handlePasswordInputChange = (e) => {
    const { name, value } = e.target;
    setPasswordForm(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // Handle notification toggle changes
  const handleNotificationToggle = (setting) => {
    setNotificationPrefs(prev => ({
      ...prev,
      [setting]: !prev[setting]
    }));
  };
  
  // Handle notification days change
  const handleReminderDaysChange = (e) => {
    const value = parseInt(e.target.value);
    setNotificationPrefs(prev => ({
      ...prev,
      reminderDays: value
    }));
  };
  
  // Submit profile form
  const handleProfileSubmit = (e) => {
    e.preventDefault();
    updateProfileMutation.mutate(profileForm);
  };
  
  // Submit password form
  const handlePasswordSubmit = (e) => {
    e.preventDefault();
    
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      toast.error('New passwords do not match');
      return;
    }
    
    updatePasswordMutation.mutate({
      currentPassword: passwordForm.currentPassword,
      newPassword: passwordForm.newPassword
    });
  };
  
  // Save notification preferences
  const handleSaveNotificationPrefs = () => {
    updateNotificationPrefsMutation.mutate(notificationPrefs);
  };
  
  // Export user data
  const handleExportData = () => {
    exportDataMutation.mutate();
  };
  
  // Delete account with confirmation
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');
  
  const handleDeleteAccount = () => {
    if (deleteConfirmText !== 'DELETE') {
      toast.error('Please type DELETE to confirm');
      return;
    }
    
    deleteAccountMutation.mutate({ password: passwordForm.currentPassword });
  };
  
  if (!user) {
    return (
      <div className="container mx-auto px-4 py-8 flex justify-center">
        <div className="bg-card rounded-lg shadow p-6 max-w-md w-full text-center">
          <p className="mb-4">Please log in to access settings</p>
          <a 
            href="/auth" 
            className="inline-block px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90 transition"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Settings</h1>
        <p className="text-muted-foreground">
          Manage your account and preferences
        </p>
      </div>
      
      {/* Settings Navigation */}
      <div className="bg-card rounded-lg shadow overflow-hidden">
        <div className="md:flex">
          {/* Sidebar */}
          <div className="md:w-64 bg-muted p-4 md:min-h-[600px]">
            <nav className="space-y-1">
              <button 
                className={`w-full px-4 py-2 rounded-md text-left ${
                  activeTab === 'profile' 
                    ? 'bg-primary text-white' 
                    : 'hover:bg-muted/80'
                }`}
                onClick={() => setActiveTab('profile')}
              >
                Profile
              </button>
              <button 
                className={`w-full px-4 py-2 rounded-md text-left ${
                  activeTab === 'security' 
                    ? 'bg-primary text-white' 
                    : 'hover:bg-muted/80'
                }`}
                onClick={() => setActiveTab('security')}
              >
                Security
              </button>
              <button 
                className={`w-full px-4 py-2 rounded-md text-left ${
                  activeTab === 'notifications' 
                    ? 'bg-primary text-white' 
                    : 'hover:bg-muted/80'
                }`}
                onClick={() => setActiveTab('notifications')}
              >
                Notifications
              </button>
              <button 
                className={`w-full px-4 py-2 rounded-md text-left ${
                  activeTab === 'data' 
                    ? 'bg-primary text-white' 
                    : 'hover:bg-muted/80'
                }`}
                onClick={() => setActiveTab('data')}
              >
                Data & Privacy
              </button>
            </nav>
          </div>
          
          {/* Content */}
          <div className="flex-1 p-6">
            {/* Profile Settings */}
            {activeTab === 'profile' && (
              <div>
                <h2 className="text-xl font-bold mb-6">Profile Settings</h2>
                
                <form onSubmit={handleProfileSubmit} className="space-y-4 max-w-md">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium mb-1">
                      Full Name
                    </label>
                    <input
                      id="name"
                      name="name"
                      type="text"
                      value={profileForm.name}
                      onChange={handleProfileInputChange}
                      className="w-full px-3 py-2 border rounded-md"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium mb-1">
                      Email Address
                    </label>
                    <input
                      id="email"
                      name="email"
                      type="email"
                      value={profileForm.email}
                      onChange={handleProfileInputChange}
                      className="w-full px-3 py-2 border rounded-md"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium mb-1">
                      Phone Number (optional)
                    </label>
                    <input
                      id="phone"
                      name="phone"
                      type="tel"
                      value={profileForm.phone}
                      onChange={handleProfileInputChange}
                      className="w-full px-3 py-2 border rounded-md"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="location" className="block text-sm font-medium mb-1">
                      Location (optional)
                    </label>
                    <input
                      id="location"
                      name="location"
                      type="text"
                      value={profileForm.location}
                      onChange={handleProfileInputChange}
                      className="w-full px-3 py-2 border rounded-md"
                      placeholder="City, State"
                    />
                  </div>
                  
                  <div className="pt-2">
                    <button
                      type="submit"
                      className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90 transition"
                      disabled={updateProfileMutation.isPending}
                    >
                      {updateProfileMutation.isPending ? 'Saving...' : 'Save Changes'}
                    </button>
                  </div>
                </form>
              </div>
            )}
            
            {/* Security Settings */}
            {activeTab === 'security' && (
              <div>
                <h2 className="text-xl font-bold mb-6">Security Settings</h2>
                
                <form onSubmit={handlePasswordSubmit} className="space-y-4 max-w-md">
                  <div>
                    <label htmlFor="currentPassword" className="block text-sm font-medium mb-1">
                      Current Password
                    </label>
                    <input
                      id="currentPassword"
                      name="currentPassword"
                      type="password"
                      value={passwordForm.currentPassword}
                      onChange={handlePasswordInputChange}
                      className="w-full px-3 py-2 border rounded-md"
                      required
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="newPassword" className="block text-sm font-medium mb-1">
                      New Password
                    </label>
                    <input
                      id="newPassword"
                      name="newPassword"
                      type="password"
                      value={passwordForm.newPassword}
                      onChange={handlePasswordInputChange}
                      className="w-full px-3 py-2 border rounded-md"
                      required
                      minLength={8}
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="confirmPassword" className="block text-sm font-medium mb-1">
                      Confirm New Password
                    </label>
                    <input
                      id="confirmPassword"
                      name="confirmPassword"
                      type="password"
                      value={passwordForm.confirmPassword}
                      onChange={handlePasswordInputChange}
                      className="w-full px-3 py-2 border rounded-md"
                      required
                      minLength={8}
                    />
                  </div>
                  
                  <div className="pt-2">
                    <button
                      type="submit"
                      className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90 transition"
                      disabled={updatePasswordMutation.isPending}
                    >
                      {updatePasswordMutation.isPending ? 'Changing...' : 'Change Password'}
                    </button>
                  </div>
                </form>
                
                <div className="mt-12">
                  <h3 className="text-lg font-medium mb-4">Session Management</h3>
                  <p className="text-muted-foreground mb-4">
                    You're currently signed in on this device. If you think your account has been 
                    compromised, sign out everywhere and change your password.
                  </p>
                  <button 
                    className="px-4 py-2 border border-red-600 text-red-600 rounded-md hover:bg-red-50 transition"
                  >
                    Sign Out from All Devices
                  </button>
                </div>
              </div>
            )}
            
            {/* Notification Settings */}
            {activeTab === 'notifications' && (
              <div>
                <h2 className="text-xl font-bold mb-6">Notification Settings</h2>
                
                <div className="space-y-6 max-w-md">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Email Notifications</h3>
                      <p className="text-sm text-muted-foreground">
                        Receive all notifications via email
                      </p>
                    </div>
                    <div>
                      <button
                        type="button"
                        className={`relative inline-flex h-6 w-11 items-center rounded-full ${
                          notificationPrefs.emailNotifications 
                            ? 'bg-primary' 
                            : 'bg-muted'
                        }`}
                        onClick={() => handleNotificationToggle('emailNotifications')}
                      >
                        <span
                          className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${
                            notificationPrefs.emailNotifications 
                              ? 'translate-x-6' 
                              : 'translate-x-1'
                          }`}
                        />
                      </button>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Expiry Reminders</h3>
                      <p className="text-sm text-muted-foreground">
                        Get notified when food items are about to expire
                      </p>
                    </div>
                    <div>
                      <button
                        type="button"
                        className={`relative inline-flex h-6 w-11 items-center rounded-full ${
                          notificationPrefs.expiryReminders 
                            ? 'bg-primary' 
                            : 'bg-muted'
                        }`}
                        onClick={() => handleNotificationToggle('expiryReminders')}
                      >
                        <span
                          className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${
                            notificationPrefs.expiryReminders 
                              ? 'translate-x-6' 
                              : 'translate-x-1'
                          }`}
                        />
                      </button>
                    </div>
                  </div>
                  
                  {notificationPrefs.expiryReminders && (
                    <div className="ml-6 border-l-2 pl-4 border-muted">
                      <label htmlFor="reminderDays" className="block text-sm font-medium mb-1">
                        Remind me
                      </label>
                      <select
                        id="reminderDays"
                        value={notificationPrefs.reminderDays}
                        onChange={handleReminderDaysChange}
                        className="px-3 py-2 border rounded-md"
                      >
                        <option value={1}>1 day before expiry</option>
                        <option value={2}>2 days before expiry</option>
                        <option value={3}>3 days before expiry</option>
                        <option value={5}>5 days before expiry</option>
                        <option value={7}>7 days before expiry</option>
                      </select>
                    </div>
                  )}
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Donation Updates</h3>
                      <p className="text-sm text-muted-foreground">
                        Get notified about your donation status updates
                      </p>
                    </div>
                    <div>
                      <button
                        type="button"
                        className={`relative inline-flex h-6 w-11 items-center rounded-full ${
                          notificationPrefs.donationUpdates 
                            ? 'bg-primary' 
                            : 'bg-muted'
                        }`}
                        onClick={() => handleNotificationToggle('donationUpdates')}
                      >
                        <span
                          className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${
                            notificationPrefs.donationUpdates 
                              ? 'translate-x-6' 
                              : 'translate-x-1'
                          }`}
                        />
                      </button>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Weekly Digest</h3>
                      <p className="text-sm text-muted-foreground">
                        Receive a weekly summary of your inventory and impact
                      </p>
                    </div>
                    <div>
                      <button
                        type="button"
                        className={`relative inline-flex h-6 w-11 items-center rounded-full ${
                          notificationPrefs.weeklyDigest 
                            ? 'bg-primary' 
                            : 'bg-muted'
                        }`}
                        onClick={() => handleNotificationToggle('weeklyDigest')}
                      >
                        <span
                          className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${
                            notificationPrefs.weeklyDigest 
                              ? 'translate-x-6' 
                              : 'translate-x-1'
                          }`}
                        />
                      </button>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Marketing Emails</h3>
                      <p className="text-sm text-muted-foreground">
                        Receive updates about features and news
                      </p>
                    </div>
                    <div>
                      <button
                        type="button"
                        className={`relative inline-flex h-6 w-11 items-center rounded-full ${
                          notificationPrefs.marketingEmails 
                            ? 'bg-primary' 
                            : 'bg-muted'
                        }`}
                        onClick={() => handleNotificationToggle('marketingEmails')}
                      >
                        <span
                          className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${
                            notificationPrefs.marketingEmails 
                              ? 'translate-x-6' 
                              : 'translate-x-1'
                          }`}
                        />
                      </button>
                    </div>
                  </div>
                  
                  <div className="pt-2">
                    <button
                      type="button"
                      className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90 transition"
                      onClick={handleSaveNotificationPrefs}
                      disabled={updateNotificationPrefsMutation.isPending}
                    >
                      {updateNotificationPrefsMutation.isPending ? 'Saving...' : 'Save Preferences'}
                    </button>
                  </div>
                </div>
              </div>
            )}
            
            {/* Data & Privacy Settings */}
            {activeTab === 'data' && (
              <div>
                <h2 className="text-xl font-bold mb-6">Data & Privacy</h2>
                
                <div className="space-y-8">
                  <div className="bg-muted p-5 rounded-lg">
                    <h3 className="text-lg font-medium mb-2">Export Your Data</h3>
                    <p className="text-muted-foreground mb-4">
                      Download all your data including profile information, inventory, 
                      donations, and impact data in JSON format.
                    </p>
                    <button
                      type="button"
                      className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90 transition"
                      onClick={handleExportData}
                      disabled={exportDataMutation.isPending}
                    >
                      {exportDataMutation.isPending ? 'Exporting...' : 'Export Data'}
                    </button>
                  </div>
                  
                  <div className="bg-red-50 p-5 rounded-lg">
                    <h3 className="text-lg font-medium text-red-600 mb-2">Delete Your Account</h3>
                    <p className="text-red-600/80 mb-4">
                      Permanently delete your account and all associated data. This action cannot be undone.
                    </p>
                    {!showDeleteConfirmation ? (
                      <button
                        type="button"
                        className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition"
                        onClick={() => setShowDeleteConfirmation(true)}
                      >
                        Delete Account
                      </button>
                    ) : (
                      <div className="space-y-3">
                        <p className="text-red-600/80 text-sm">
                          Please type <strong>DELETE</strong> to confirm account deletion:
                        </p>
                        <input
                          type="text"
                          value={deleteConfirmText}
                          onChange={(e) => setDeleteConfirmText(e.target.value)}
                          className="w-full px-3 py-2 border border-red-300 rounded-md focus:border-red-500 focus:ring-red-500"
                          placeholder="Type DELETE to confirm"
                        />
                        <div className="flex gap-2">
                          <button
                            type="button"
                            className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition"
                            onClick={handleDeleteAccount}
                            disabled={deleteAccountMutation.isPending}
                          >
                            {deleteAccountMutation.isPending ? 'Deleting...' : 'Confirm Deletion'}
                          </button>
                          <button
                            type="button"
                            className="px-4 py-2 border border-red-600 text-red-600 rounded-md hover:bg-red-50 transition"
                            onClick={() => {
                              setShowDeleteConfirmation(false);
                              setDeleteConfirmText('');
                            }}
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <div className="bg-card border rounded-lg p-5">
                    <h3 className="text-lg font-medium mb-2">Privacy Policy</h3>
                    <p className="text-muted-foreground mb-4">
                      Read our privacy policy to understand how we collect, use, and protect your data.
                    </p>
                    <a 
                      href="/privacy-policy" 
                      className="text-primary hover:underline"
                    >
                      View Privacy Policy
                    </a>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}