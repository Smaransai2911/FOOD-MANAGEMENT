import mongoose from 'mongoose';

// Main donation schema
const DonationSchema = new mongoose.Schema({
  donorId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  recipientId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  status: {
    type: String,
    enum: ['pending', 'accepted', 'scheduled', 'completed', 'cancelled'],
    default: 'pending'
  },
  pickupDate: {
    type: Date
  },
  pickupAddress: {
    type: String,
    required: true
  },
  notes: {
    type: String
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Donation item schema (to track individual food items in a donation)
const DonationItemSchema = new mongoose.Schema({
  donationId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Donation',
    required: true
  },
  foodItemId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'FoodItem',
    required: true
  },
  quantity: {
    type: String,
    required: true
  },
  notes: {
    type: String
  }
});

// Donation location schema (for mapping feature)
const DonationLocationSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  type: {
    type: String,
    enum: ['food_bank', 'shelter', 'community_center', 'school', 'other'],
    default: 'food_bank'
  },
  address: {
    type: String,
    required: true
  },
  latitude: {
    type: Number
  },
  longitude: {
    type: Number
  },
  contactPerson: {
    type: String
  },
  phone: {
    type: String
  },
  email: {
    type: String
  },
  website: {
    type: String
  },
  operatingHours: {
    type: String
  },
  acceptsFoodTypes: {
    type: String
  },
  isVerified: {
    type: Boolean,
    default: false
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
});

// Indexes for faster queries
DonationSchema.index({ donorId: 1, status: 1 });
DonationSchema.index({ recipientId: 1 });
DonationItemSchema.index({ donationId: 1 });
DonationLocationSchema.index({ type: 1 });
DonationLocationSchema.index({ 
  latitude: '2dsphere',
  longitude: '2dsphere'
});

// Create models from schemas
const Donation = mongoose.model('Donation', DonationSchema);
const DonationItem = mongoose.model('DonationItem', DonationItemSchema);
const DonationLocation = mongoose.model('DonationLocation', DonationLocationSchema);

export { Donation, DonationItem, DonationLocation };