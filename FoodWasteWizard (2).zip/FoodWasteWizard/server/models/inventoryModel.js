import mongoose from 'mongoose';

const FoodItemSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  category: {
    type: String,
    enum: ['vegetables', 'fruits', 'dairy', 'grains', 'protein', 'bakery', 'canned', 'frozen', 'beverages', 'other'],
    default: 'other'
  },
  quantity: {
    type: String,
    required: true
  },
  unit: {
    type: String,
    enum: ['kg', 'g', 'lb', 'oz', 'l', 'ml', 'units', 'servings', 'pcs', 'packages'],
    default: 'units'
  },
  expiryDate: {
    type: Date,
    required: true
  },
  purchaseDate: {
    type: Date,
    default: Date.now
  },
  description: {
    type: String
  },
  imageUrl: {
    type: String
  },
  isAvailableForDonation: {
    type: Boolean,
    default: false
  },
  barcodeData: {
    type: String
  },
  storageLocation: {
    type: String,
    default: 'Kitchen'
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Virtual for days until expiry
FoodItemSchema.virtual('daysUntilExpiry').get(function() {
  const now = new Date();
  const expiryDate = new Date(this.expiryDate);
  const diffTime = expiryDate - now;
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
});

// Indexes for faster queries
FoodItemSchema.index({ userId: 1, expiryDate: 1 });
FoodItemSchema.index({ isAvailableForDonation: 1 });

const FoodItem = mongoose.model('FoodItem', FoodItemSchema);

export default FoodItem;