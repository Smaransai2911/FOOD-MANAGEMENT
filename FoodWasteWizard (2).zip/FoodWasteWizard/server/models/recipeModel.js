import mongoose from 'mongoose';

// Main recipe schema
const RecipeSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  ingredients: {
    type: String,
    required: true
  },
  instructions: {
    type: String,
    required: true
  },
  prepTime: {
    type: Number,
    required: true
  },
  cookTime: {
    type: Number
  },
  servings: {
    type: Number
  },
  difficulty: {
    type: String,
    enum: ['easy', 'medium', 'hard'],
    default: 'medium'
  },
  cuisine: {
    type: String
  },
  mealType: {
    type: String,
    enum: ['breakfast', 'lunch', 'dinner', 'snack', 'dessert'],
  },
  dietaryPreferences: {
    type: [String],
    enum: ['vegetarian', 'vegan', 'gluten-free', 'dairy-free', 'low-carb', 'keto', 'paleo']
  },
  imageUrl: {
    type: String
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  isPublic: {
    type: Boolean,
    default: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Recipe ingredient schema (for more structured recipe ingredients)
const RecipeIngredientSchema = new mongoose.Schema({
  recipeId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Recipe',
    required: true
  },
  name: {
    type: String,
    required: true
  },
  quantity: {
    type: String
  },
  unit: {
    type: String
  },
  notes: {
    type: String
  },
  isOptional: {
    type: Boolean,
    default: false
  }
});

// Create indexes for faster queries
RecipeSchema.index({ name: 'text', description: 'text', ingredients: 'text' });
RecipeSchema.index({ difficulty: 1 });
RecipeSchema.index({ prepTime: 1 });
RecipeSchema.index({ mealType: 1 });
RecipeSchema.index({ dietaryPreferences: 1 });
RecipeIngredientSchema.index({ recipeId: 1 });

// Create models from schemas
const Recipe = mongoose.model('Recipe', RecipeSchema);
const RecipeIngredient = mongoose.model('RecipeIngredient', RecipeIngredientSchema);

export { Recipe, RecipeIngredient };