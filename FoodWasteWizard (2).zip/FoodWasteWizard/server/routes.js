const { createServer } = require('http');
const { storage } = require('./storage');
const { setupAuth } = require('./auth');
const { z } = require('zod');

// This would import the schemas defined in shared/schema.js in a real app
// For now, this will act as a mock
const schema = {
  insertFoodItemSchema: z.any(),
  insertDonationSchema: z.any(),
  insertDonationItemSchema: z.any()
};

function registerRoutes(app) {
  // Setup authentication routes
  setupAuth(app);

  // Food Items API
  app.get("/api/food-items", (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const userId = req.user.id;
      storage.getFoodItemsByUser(userId)
        .then(foodItems => res.json(foodItems))
        .catch(err => res.status(500).json({ message: "Failed to fetch food items" }));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch food items" });
    }
  });

  app.get("/api/food-items/expiring", (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const userId = req.user.id;
      const days = parseInt(req.query.days) || 7;
      
      storage.getExpiringFoodItems(userId, days)
        .then(expiringItems => res.json(expiringItems))
        .catch(err => res.status(500).json({ message: "Failed to fetch expiring food items" }));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch expiring food items" });
    }
  });

  app.post("/api/food-items", (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const userId = req.user.id;
      
      // In a real app, we would validate the data with Zod
      // const validatedData = schema.insertFoodItemSchema.parse({
      //   ...req.body,
      //   userId
      // });
      
      const validatedData = {
        ...req.body,
        userId
      };
      
      storage.createFoodItem(validatedData)
        .then(foodItem => res.status(201).json(foodItem))
        .catch(err => res.status(500).json({ message: "Failed to create food item" }));
    } catch (error) {
      if (error.name === 'ZodError') {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create food item" });
    }
  });

  app.put("/api/food-items/:id", (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const id = parseInt(req.params.id);
      
      storage.getFoodItem(id)
        .then(foodItem => {
          if (!foodItem) {
            return res.status(404).json({ message: "Food item not found" });
          }
          
          if (foodItem.userId !== req.user.id) {
            return res.status(403).json({ message: "Forbidden" });
          }
          
          return storage.updateFoodItem(id, req.body);
        })
        .then(updatedItem => {
          if (updatedItem) {
            res.json(updatedItem);
          }
        })
        .catch(err => res.status(500).json({ message: "Failed to update food item" }));
    } catch (error) {
      res.status(500).json({ message: "Failed to update food item" });
    }
  });

  app.delete("/api/food-items/:id", (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const id = parseInt(req.params.id);
      
      storage.getFoodItem(id)
        .then(foodItem => {
          if (!foodItem) {
            return res.status(404).json({ message: "Food item not found" });
          }
          
          if (foodItem.userId !== req.user.id) {
            return res.status(403).json({ message: "Forbidden" });
          }
          
          return storage.deleteFoodItem(id);
        })
        .then(success => {
          if (success) {
            res.status(204).send();
          }
        })
        .catch(err => res.status(500).json({ message: "Failed to delete food item" }));
    } catch (error) {
      res.status(500).json({ message: "Failed to delete food item" });
    }
  });

  // Recipes API
  app.get("/api/recipes", (req, res) => {
    try {
      storage.getAllRecipes()
        .then(recipes => res.json(recipes))
        .catch(err => res.status(500).json({ message: "Failed to fetch recipes" }));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recipes" });
    }
  });

  app.get("/api/recipes/:id", (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      storage.getRecipe(id)
        .then(recipe => {
          if (!recipe) {
            return res.status(404).json({ message: "Recipe not found" });
          }
          
          res.json(recipe);
        })
        .catch(err => res.status(500).json({ message: "Failed to fetch recipe" }));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recipe" });
    }
  });

  app.get("/api/recipes/match", (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      // Handle both array and comma-separated string formats
      let ingredients = req.query.ingredients;
      
      if (typeof ingredients === 'string') {
        ingredients = ingredients.split(',').map(i => i.trim());
      }
      
      if (!ingredients || !Array.isArray(ingredients) || ingredients.length === 0) {
        return res.status(400).json({ message: "Ingredients must be provided as an array or comma-separated list" });
      }
      
      storage.getRecipesByIngredients(ingredients)
        .then(matchingRecipes => res.json(matchingRecipes))
        .catch(err => res.status(500).json({ message: "Failed to match recipes" }));
    } catch (error) {
      console.error("Recipe matching error:", error);
      res.status(500).json({ message: "Failed to match recipes" });
    }
  });
  
  // Additional route for recipe matching - alternative path
  app.get("/api/match-recipes", (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      // Handle both array and comma-separated string formats
      let ingredients = req.query.ingredients;
      
      if (typeof ingredients === 'string') {
        ingredients = ingredients.split(',').map(i => i.trim());
      }
      
      if (!ingredients || !Array.isArray(ingredients) || ingredients.length === 0) {
        return res.status(400).json({ message: "Ingredients must be provided as an array or comma-separated list" });
      }
      
      storage.getRecipesByIngredients(ingredients)
        .then(matchingRecipes => res.json(matchingRecipes))
        .catch(err => res.status(500).json({ message: "Failed to match recipes" }));
    } catch (error) {
      console.error("Recipe matching error:", error);
      res.status(500).json({ message: "Failed to match recipes" });
    }
  });

  // Donation Locations API
  app.get("/api/donation-locations", (req, res) => {
    try {
      let locationsPromise;
      
      if (req.query.type) {
        locationsPromise = storage.getDonationLocationsByType(req.query.type);
      } else {
        locationsPromise = storage.getAllDonationLocations();
      }
      
      locationsPromise
        .then(locations => res.json(locations))
        .catch(err => res.status(500).json({ message: "Failed to fetch donation locations" }));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch donation locations" });
    }
  });

  // Donations API
  app.get("/api/donations", (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const userId = req.user.id;
      
      storage.getDonationsByDonor(userId)
        .then(donations => res.json(donations))
        .catch(err => res.status(500).json({ message: "Failed to fetch donations" }));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch donations" });
    }
  });
  
  app.get("/api/donations/:id", (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const id = parseInt(req.params.id);
      
      storage.getDonation(id)
        .then(donation => {
          if (!donation) {
            return res.status(404).json({ message: "Donation not found" });
          }
          
          // Check if user is the donor or recipient
          if (donation.donorId !== req.user.id && donation.recipientId !== req.user.id) {
            return res.status(403).json({ message: "Forbidden" });
          }
          
          // Get the donation items
          return storage.getDonationItems(id)
            .then(items => {
              res.json({ ...donation, items });
            });
        })
        .catch(err => res.status(500).json({ message: "Failed to fetch donation" }));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch donation" });
    }
  });
  
  app.post("/api/donations", (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const donorId = req.user.id;
      
      // Validate data
      const validatedData = {
        ...req.body,
        donorId,
        status: 'pending', // Initial status is always pending
        createdAt: new Date()
      };
      
      storage.createDonation(validatedData)
        .then(donation => {
          // If there are items, add them
          if (req.body.items && Array.isArray(req.body.items)) {
            const itemPromises = req.body.items.map(item => {
              return storage.addDonationItem({
                donationId: donation.id,
                foodItemId: item.foodItemId,
                quantity: item.quantity,
                unit: item.unit
              });
            });
            
            return Promise.all(itemPromises)
              .then(donationItems => {
                res.status(201).json({ ...donation, items: donationItems });
              });
          } else {
            res.status(201).json(donation);
          }
        })
        .catch(err => {
          console.error("Donation creation error:", err);
          res.status(500).json({ message: "Failed to create donation" });
        });
    } catch (error) {
      console.error("Donation error:", error);
      if (error.name === 'ZodError') {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create donation" });
    }
  });
  
  app.put("/api/donations/:id/status", (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!status || !['pending', 'accepted', 'completed', 'cancelled'].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      storage.getDonation(id)
        .then(donation => {
          if (!donation) {
            return res.status(404).json({ message: "Donation not found" });
          }
          
          // Check if user is donor or recipient based on status change
          if (status === 'cancelled' && donation.donorId !== req.user.id) {
            return res.status(403).json({ message: "Only the donor can cancel a donation" });
          }
          
          if ((status === 'accepted' || status === 'completed') && 
              donation.recipientId !== req.user.id) {
            return res.status(403).json({ message: "Only the recipient can accept or complete a donation" });
          }
          
          return storage.updateDonation(id, { status });
        })
        .then(updatedDonation => {
          if (updatedDonation) {
            res.json(updatedDonation);
          }
        })
        .catch(err => res.status(500).json({ message: "Failed to update donation status" }));
    } catch (error) {
      res.status(500).json({ message: "Failed to update donation status" });
    }
  });

  // Impact data APIs
  app.get("/api/impact/user", (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    // In a real app, we would fetch from a database
    // For now, we return mock data for demonstration
    res.json({
      wasteReducedKg: 12.5,
      donationsCount: 5,
      itemsDonatedCount: 15,
      moneySaved: 75.50,
      badges: [
        {
          id: 1,
          name: 'First Donation',
          description: 'Make your first donation',
          unlocked: true,
          unlockedAt: new Date('2023-01-15'),
          icon: '/img/badges/first-donation.svg'
        },
        {
          id: 2,
          name: 'Waste Warrior',
          description: 'Reduce 10kg of food waste',
          unlocked: true,
          unlockedAt: new Date('2023-02-10'),
          icon: '/img/badges/waste-warrior.svg'
        },
        {
          id: 3,
          name: 'Inventory Master',
          description: 'Track 50 items in your inventory',
          unlocked: false,
          icon: '/img/badges/inventory-master.svg'
        },
        {
          id: 4,
          name: 'Recipe Explorer',
          description: 'Try 10 different recipes',
          unlocked: false,
          icon: '/img/badges/recipe-explorer.svg'
        }
      ]
    });
  });

  app.get("/api/impact/community", (req, res) => {
    // In a real app, this would be fetched from a database
    // For now, we return mock data for demonstration
    res.json({
      activeUsers: 1250,
      totalWasteReducedKg: 15000,
      totalDonationsCount: 5230,
      mealsProvided: 22500,
      topContributors: [
        {
          id: 101,
          username: 'EcoWarrior',
          wasteReducedKg: 86.5,
          donationsCount: 32,
          isCurrentUser: false
        },
        {
          id: 102,
          username: 'FoodSaver123',
          wasteReducedKg: 75.2,
          donationsCount: 28,
          isCurrentUser: false
        },
        {
          id: 103,
          username: 'GreenChef',
          wasteReducedKg: 52.8,
          donationsCount: 19,
          isCurrentUser: false
        },
        {
          id: 104,
          username: 'SustainableSam',
          wasteReducedKg: 45.1,
          donationsCount: 17,
          isCurrentUser: false
        },
        {
          id: 105,
          username: 'ZeroWasteHero',
          wasteReducedKg: 38.7,
          donationsCount: 14,
          isCurrentUser: true
        }
      ]
    });
  });

  // Create HTTP server
  const httpServer = createServer(app);
  return httpServer;
}

module.exports = { registerRoutes };