// This file is a placeholder for database configuration
// We're using in-memory storage by default for GitHub deployment simplicity

// Dummy objects to prevent errors when imported
const pool = null;
const db = {
  select: () => ({ from: () => ({ where: () => [], limit: () => [] }) }),
  insert: () => ({ values: () => ({ returning: () => [] }) }),
  update: () => ({ set: () => ({ where: () => ({ returning: () => [] }) }) }),
  delete: () => ({ where: () => ({ returning: () => [] }) })
};

module.exports = { pool, db };