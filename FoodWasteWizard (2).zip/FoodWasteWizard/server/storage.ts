import { 
  User, InsertUser, 
  FoodItem, InsertFoodItem,
  Donation, InsertDonation,
  DonationItem, InsertDonationItem,
  Recipe, InsertRecipe,
  RecipeIngredient, InsertRecipeIngredient,
  DonationLocation, InsertDonationLocation
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User Operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  
  // Food Item Operations
  getFoodItem(id: number): Promise<FoodItem | undefined>;
  getFoodItemsByUser(userId: number): Promise<FoodItem[]>;
  getExpiringFoodItems(userId: number, days: number): Promise<FoodItem[]>;
  createFoodItem(item: InsertFoodItem): Promise<FoodItem>;
  updateFoodItem(id: number, item: Partial<FoodItem>): Promise<FoodItem | undefined>;
  deleteFoodItem(id: number): Promise<boolean>;
  
  // Donation Operations
  getDonation(id: number): Promise<Donation | undefined>;
  getDonationsByDonor(donorId: number): Promise<Donation[]>;
  getDonationsByRecipient(recipientId: number): Promise<Donation[]>;
  getDonationsByStatus(status: string): Promise<Donation[]>;
  createDonation(donation: InsertDonation): Promise<Donation>;
  updateDonation(id: number, donation: Partial<Donation>): Promise<Donation | undefined>;
  
  // Donation Items Operations
  getDonationItems(donationId: number): Promise<DonationItem[]>;
  addDonationItem(item: InsertDonationItem): Promise<DonationItem>;
  removeDonationItem(id: number): Promise<boolean>;
  
  // Recipe Operations
  getRecipe(id: number): Promise<Recipe | undefined>;
  getAllRecipes(): Promise<Recipe[]>;
  getRecipesByIngredients(ingredients: string[]): Promise<Recipe[]>;
  createRecipe(recipe: InsertRecipe): Promise<Recipe>;
  
  // Recipe Ingredients Operations
  getRecipeIngredients(recipeId: number): Promise<RecipeIngredient[]>;
  addRecipeIngredient(ingredient: InsertRecipeIngredient): Promise<RecipeIngredient>;
  
  // Donation Location Operations
  getDonationLocation(id: number): Promise<DonationLocation | undefined>;
  getDonationLocationsByType(type: string): Promise<DonationLocation[]>;
  getAllDonationLocations(): Promise<DonationLocation[]>;
  createDonationLocation(location: InsertDonationLocation): Promise<DonationLocation>;
  updateDonationLocation(id: number, location: Partial<DonationLocation>): Promise<DonationLocation | undefined>;

  // Session store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private foodItems: Map<number, FoodItem>;
  private donations: Map<number, Donation>;
  private donationItems: Map<number, DonationItem>;
  private recipes: Map<number, Recipe>;
  private recipeIngredients: Map<number, RecipeIngredient>;
  private donationLocations: Map<number, DonationLocation>;
  
  private nextUserId: number;
  private nextFoodItemId: number;
  private nextDonationId: number;
  private nextDonationItemId: number;
  private nextRecipeId: number;
  private nextRecipeIngredientId: number;
  private nextDonationLocationId: number;
  
  sessionStore: session.SessionStore;

  constructor() {
    this.users = new Map();
    this.foodItems = new Map();
    this.donations = new Map();
    this.donationItems = new Map();
    this.recipes = new Map();
    this.recipeIngredients = new Map();
    this.donationLocations = new Map();
    
    this.nextUserId = 1;
    this.nextFoodItemId = 1;
    this.nextDonationId = 1;
    this.nextDonationItemId = 1;
    this.nextRecipeId = 1;
    this.nextRecipeIngredientId = 1;
    this.nextDonationLocationId = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
    
    // Add sample recipes
    this.initializeRecipes();
  }

  // User Operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.nextUserId++;
    const now = new Date();
    const user: User = { ...insertUser, id, createdAt: now };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Food Item Operations
  async getFoodItem(id: number): Promise<FoodItem | undefined> {
    return this.foodItems.get(id);
  }

  async getFoodItemsByUser(userId: number): Promise<FoodItem[]> {
    return Array.from(this.foodItems.values()).filter(
      (item) => item.userId === userId
    );
  }

  async getExpiringFoodItems(userId: number, days: number): Promise<FoodItem[]> {
    const now = new Date();
    const futureDate = new Date();
    futureDate.setDate(now.getDate() + days);
    
    return Array.from(this.foodItems.values()).filter(
      (item) => 
        item.userId === userId && 
        item.expiryDate <= futureDate &&
        item.expiryDate >= now
    );
  }

  async createFoodItem(item: InsertFoodItem): Promise<FoodItem> {
    const id = this.nextFoodItemId++;
    const now = new Date();
    const foodItem: FoodItem = { ...item, id, createdAt: now };
    this.foodItems.set(id, foodItem);
    return foodItem;
  }

  async updateFoodItem(id: number, itemData: Partial<FoodItem>): Promise<FoodItem | undefined> {
    const item = this.foodItems.get(id);
    if (!item) return undefined;
    
    const updatedItem = { ...item, ...itemData };
    this.foodItems.set(id, updatedItem);
    return updatedItem;
  }

  async deleteFoodItem(id: number): Promise<boolean> {
    return this.foodItems.delete(id);
  }

  // Donation Operations
  async getDonation(id: number): Promise<Donation | undefined> {
    return this.donations.get(id);
  }

  async getDonationsByDonor(donorId: number): Promise<Donation[]> {
    return Array.from(this.donations.values()).filter(
      (donation) => donation.donorId === donorId
    );
  }

  async getDonationsByRecipient(recipientId: number): Promise<Donation[]> {
    return Array.from(this.donations.values()).filter(
      (donation) => donation.recipientId === recipientId
    );
  }

  async getDonationsByStatus(status: string): Promise<Donation[]> {
    return Array.from(this.donations.values()).filter(
      (donation) => donation.status === status
    );
  }

  async createDonation(donation: InsertDonation): Promise<Donation> {
    const id = this.nextDonationId++;
    const now = new Date();
    const newDonation: Donation = { ...donation, id, createdAt: now };
    this.donations.set(id, newDonation);
    return newDonation;
  }

  async updateDonation(id: number, donationData: Partial<Donation>): Promise<Donation | undefined> {
    const donation = this.donations.get(id);
    if (!donation) return undefined;
    
    const updatedDonation = { ...donation, ...donationData };
    this.donations.set(id, updatedDonation);
    return updatedDonation;
  }

  // Donation Items Operations
  async getDonationItems(donationId: number): Promise<DonationItem[]> {
    return Array.from(this.donationItems.values()).filter(
      (item) => item.donationId === donationId
    );
  }

  async addDonationItem(item: InsertDonationItem): Promise<DonationItem> {
    const id = this.nextDonationItemId++;
    const donationItem: DonationItem = { ...item, id };
    this.donationItems.set(id, donationItem);
    return donationItem;
  }

  async removeDonationItem(id: number): Promise<boolean> {
    return this.donationItems.delete(id);
  }

  // Recipe Operations
  async getRecipe(id: number): Promise<Recipe | undefined> {
    return this.recipes.get(id);
  }

  async getAllRecipes(): Promise<Recipe[]> {
    return Array.from(this.recipes.values());
  }

  async getRecipesByIngredients(ingredients: string[]): Promise<Recipe[]> {
    const allRecipeIngredients = Array.from(this.recipeIngredients.values());
    const matchingRecipeIds = new Set<number>();
    
    // Normalize input ingredients (lowercase, trim)
    const normalizedIngredients = ingredients.map(i => i.toLowerCase().trim());
    
    // Find all recipes that have at least one matching ingredient
    for (const recipeIngredient of allRecipeIngredients) {
      const ingredientName = recipeIngredient.ingredientName.toLowerCase().trim();
      if (normalizedIngredients.some(i => ingredientName.includes(i) || i.includes(ingredientName))) {
        matchingRecipeIds.add(recipeIngredient.recipeId);
      }
    }
    
    // Get the actual recipe objects
    return Array.from(matchingRecipeIds).map(id => this.recipes.get(id)!).filter(Boolean);
  }

  async createRecipe(recipe: InsertRecipe): Promise<Recipe> {
    const id = this.nextRecipeId++;
    const now = new Date();
    const newRecipe: Recipe = { ...recipe, id, createdAt: now };
    this.recipes.set(id, newRecipe);
    return newRecipe;
  }

  // Recipe Ingredients Operations
  async getRecipeIngredients(recipeId: number): Promise<RecipeIngredient[]> {
    return Array.from(this.recipeIngredients.values()).filter(
      (ingredient) => ingredient.recipeId === recipeId
    );
  }

  async addRecipeIngredient(ingredient: InsertRecipeIngredient): Promise<RecipeIngredient> {
    const id = this.nextRecipeIngredientId++;
    const recipeIngredient: RecipeIngredient = { ...ingredient, id };
    this.recipeIngredients.set(id, recipeIngredient);
    return recipeIngredient;
  }

  // Donation Location Operations
  async getDonationLocation(id: number): Promise<DonationLocation | undefined> {
    return this.donationLocations.get(id);
  }

  async getDonationLocationsByType(type: string): Promise<DonationLocation[]> {
    return Array.from(this.donationLocations.values()).filter(
      (location) => location.type === type && location.isActive
    );
  }

  async getAllDonationLocations(): Promise<DonationLocation[]> {
    return Array.from(this.donationLocations.values()).filter(
      (location) => location.isActive
    );
  }

  async createDonationLocation(location: InsertDonationLocation): Promise<DonationLocation> {
    const id = this.nextDonationLocationId++;
    const donationLocation: DonationLocation = { ...location, id };
    this.donationLocations.set(id, donationLocation);
    return donationLocation;
  }

  async updateDonationLocation(id: number, locationData: Partial<DonationLocation>): Promise<DonationLocation | undefined> {
    const location = this.donationLocations.get(id);
    if (!location) return undefined;
    
    const updatedLocation = { ...location, ...locationData };
    this.donationLocations.set(id, updatedLocation);
    return updatedLocation;
  }

  // Initialize sample recipes
  private initializeRecipes() {
    const recipeData: InsertRecipe[] = [
      {
        name: "Vegetable Stir Fry",
        description: "A quick and healthy stir fry using your expiring vegetables. Ready in just 20 minutes!",
        ingredients: "Bell peppers, carrots, broccoli, onions, garlic, ginger, soy sauce, vegetable oil",
        instructions: "1. Heat oil in a pan\n2. Add garlic and ginger\n3. Add vegetables and stir fry for 5-7 minutes\n4. Add soy sauce and seasonings\n5. Serve hot",
        prepTime: 20,
        difficulty: "easy",
        imageUrl: "https://images.unsplash.com/photo-1490645935967-10de6ba17061",
      },
      {
        name: "Bread Pudding",
        description: "Transform your stale bread into a delicious dessert with this simple bread pudding recipe.",
        ingredients: "Stale bread, milk, eggs, sugar, vanilla extract, cinnamon, butter",
        instructions: "1. Preheat oven to 350°F\n2. Cut bread into cubes\n3. Mix milk, eggs, sugar, vanilla, and cinnamon\n4. Soak bread in mixture\n5. Pour into greased baking dish\n6. Bake for 40-45 minutes",
        prepTime: 45,
        difficulty: "medium",
        imageUrl: "https://images.unsplash.com/photo-1548247416-ec66f4900b2e",
      },
      {
        name: "Yogurt Parfait",
        description: "A nutritious breakfast or dessert option using yogurt, fruits, and granola.",
        ingredients: "Greek yogurt, honey, granola, mixed berries or fruits",
        instructions: "1. Layer yogurt in a glass\n2. Add a layer of honey\n3. Add a layer of fruits\n4. Top with granola\n5. Repeat layers as desired",
        prepTime: 10,
        difficulty: "easy",
        imageUrl: "https://images.unsplash.com/photo-1542691457-cbe4df041eb2",
      }
    ];

    // Create recipes
    recipeData.forEach(recipe => {
      const id = this.nextRecipeId++;
      const now = new Date();
      const newRecipe: Recipe = { ...recipe, id, createdAt: now };
      this.recipes.set(id, newRecipe);
      
      // Add ingredients for matching
      const ingredients = recipe.ingredients.split(',').map(i => i.trim());
      ingredients.forEach(ingredient => {
        const ingredientId = this.nextRecipeIngredientId++;
        const recipeIngredient: RecipeIngredient = {
          id: ingredientId,
          recipeId: id,
          ingredientName: ingredient
        };
        this.recipeIngredients.set(ingredientId, recipeIngredient);
      });
    });
  }
}

export const storage = new MemStorage();
