const express = require('express');
const session = require('express-session');
const { createServer } = require('http');
const path = require('path');
const { storage } = require('./storage');
const { setupAuth } = require('./auth');

// Create Express app
const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Session setup
const sessionConfig = {
  secret: process.env.SESSION_SECRET || 'dev-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    maxAge: 24 * 60 * 60 * 1000 // 1 day
  },
  store: storage.sessionStore
};

app.use(session(sessionConfig));

// Set up authentication
setupAuth(app);

// API routes
app.get('/api/inventory', (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  
  const userId = req.user.id;
  storage.getFoodItemsByUser(userId)
    .then(items => res.json(items))
    .catch(err => res.status(500).json({ message: 'Failed to fetch inventory items', error: err.message }));
});

app.post('/api/inventory', (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  
  const userId = req.user.id;
  const itemData = {
    ...req.body,
    userId
  };
  
  storage.createFoodItem(itemData)
    .then(item => res.status(201).json(item))
    .catch(err => res.status(500).json({ message: 'Failed to create item', error: err.message }));
});

app.get('/api/inventory/:id', (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  
  const id = parseInt(req.params.id);
  
  storage.getFoodItem(id)
    .then(item => {
      if (!item) {
        return res.status(404).json({ message: 'Item not found' });
      }
      
      // Check ownership
      if (item.userId !== req.user.id) {
        return res.status(403).json({ message: 'Forbidden' });
      }
      
      res.json(item);
    })
    .catch(err => res.status(500).json({ message: 'Failed to fetch item', error: err.message }));
});

app.patch('/api/inventory/:id', (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  
  const id = parseInt(req.params.id);
  
  storage.getFoodItem(id)
    .then(item => {
      if (!item) {
        return res.status(404).json({ message: 'Item not found' });
      }
      
      // Check ownership
      if (item.userId !== req.user.id) {
        return res.status(403).json({ message: 'Forbidden' });
      }
      
      return storage.updateFoodItem(id, req.body);
    })
    .then(updatedItem => {
      if (updatedItem) {
        res.json(updatedItem);
      }
    })
    .catch(err => res.status(500).json({ message: 'Failed to update item', error: err.message }));
});

app.delete('/api/inventory/:id', (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  
  const id = parseInt(req.params.id);
  
  storage.getFoodItem(id)
    .then(item => {
      if (!item) {
        return res.status(404).json({ message: 'Item not found' });
      }
      
      // Check ownership
      if (item.userId !== req.user.id) {
        return res.status(403).json({ message: 'Forbidden' });
      }
      
      return storage.deleteFoodItem(id);
    })
    .then(success => {
      if (success) {
        res.status(204).send();
      }
    })
    .catch(err => res.status(500).json({ message: 'Failed to delete item', error: err.message }));
});

// Recipes routes
app.get('/api/recipes', (req, res) => {
  storage.getAllRecipes()
    .then(recipes => res.json(recipes))
    .catch(err => res.status(500).json({ message: 'Failed to fetch recipes', error: err.message }));
});

app.get('/api/recipes/:id', (req, res) => {
  const id = parseInt(req.params.id);
  
  storage.getRecipe(id)
    .then(recipe => {
      if (!recipe) {
        return res.status(404).json({ message: 'Recipe not found' });
      }
      
      res.json(recipe);
    })
    .catch(err => res.status(500).json({ message: 'Failed to fetch recipe', error: err.message }));
});

// Donation routes
app.get('/api/donations', (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  
  const userId = req.user.id;
  
  storage.getDonationsByDonor(userId)
    .then(donations => res.json(donations))
    .catch(err => res.status(500).json({ message: 'Failed to fetch donations', error: err.message }));
});

app.post('/api/donations', (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  
  const donorId = req.user.id;
  const donationData = {
    ...req.body,
    donorId,
    status: 'pending'
  };
  
  storage.createDonation(donationData)
    .then(donation => res.status(201).json(donation))
    .catch(err => res.status(500).json({ message: 'Failed to create donation', error: err.message }));
});

// Donation locations routes
app.get('/api/donation-locations', (req, res) => {
  storage.getAllDonationLocations()
    .then(locations => res.json(locations))
    .catch(err => res.status(500).json({ message: 'Failed to fetch donation locations', error: err.message }));
});

// Impact data routes
app.get('/api/impact/user', (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  
  const userId = req.user.id;
  const timeRange = req.query.timeRange || 'all';
  
  // In a real app, this would fetch from a database
  // For now, we return mock data for demonstration
  res.json({
    wasteReducedKg: 12.5,
    donationsCount: 5,
    itemsDonatedCount: 15,
    moneySaved: 75.50,
    badges: [
      {
        id: 1,
        name: 'First Donation',
        description: 'Make your first donation',
        unlocked: true,
        unlockedAt: new Date('2023-01-15'),
        icon: '/img/badges/first-donation.svg'
      },
      {
        id: 2,
        name: 'Waste Warrior',
        description: 'Reduce 10kg of food waste',
        unlocked: true,
        unlockedAt: new Date('2023-02-10'),
        icon: '/img/badges/waste-warrior.svg'
      },
      {
        id: 3,
        name: 'Inventory Master',
        description: 'Track 50 items in your inventory',
        unlocked: false,
        icon: '/img/badges/inventory-master.svg'
      },
      {
        id: 4,
        name: 'Recipe Explorer',
        description: 'Try 10 different recipes',
        unlocked: false,
        icon: '/img/badges/recipe-explorer.svg'
      }
    ]
  });
});

app.get('/api/impact/community', (req, res) => {
  // In a real app, this would be fetched from a database
  // For now, we return mock data for demonstration
  res.json({
    activeUsers: 1250,
    totalWasteReducedKg: 15000,
    totalDonationsCount: 5230,
    mealsProvided: 22500,
    topContributors: [
      {
        id: 101,
        username: 'EcoWarrior',
        wasteReducedKg: 86.5,
        donationsCount: 32,
        isCurrentUser: false
      },
      {
        id: 102,
        username: 'FoodSaver123',
        wasteReducedKg: 75.2,
        donationsCount: 28,
        isCurrentUser: false
      },
      {
        id: 103,
        username: 'GreenChef',
        wasteReducedKg: 52.8,
        donationsCount: 19,
        isCurrentUser: false
      },
      {
        id: 104,
        username: 'SustainableSam',
        wasteReducedKg: 45.1,
        donationsCount: 17,
        isCurrentUser: false
      },
      {
        id: 105,
        username: 'ZeroWasteHero',
        wasteReducedKg: 38.7,
        donationsCount: 14,
        isCurrentUser: true
      }
    ]
  });
});

// Inventory available for donation
app.get('/api/inventory/available-for-donation', (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  
  const userId = req.user.id;
  
  storage.getFoodItemsByUser(userId)
    .then(items => {
      // Filter items that are available for donation
      const availableItems = items.filter(item => !item.isUsed && !item.isDonated);
      res.json(availableItems);
    })
    .catch(err => res.status(500).json({ message: 'Failed to fetch available items', error: err.message }));
});

// Mark food item for donation
app.post('/api/inventory/:id/donate', (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  
  const id = parseInt(req.params.id);
  
  storage.getFoodItem(id)
    .then(item => {
      if (!item) {
        return res.status(404).json({ message: 'Item not found' });
      }
      
      // Check ownership
      if (item.userId !== req.user.id) {
        return res.status(403).json({ message: 'Forbidden' });
      }
      
      return storage.updateFoodItem(id, { markedForDonation: true });
    })
    .then(updatedItem => {
      if (updatedItem) {
        res.json(updatedItem);
      }
    })
    .catch(err => res.status(500).json({ message: 'Failed to mark item for donation', error: err.message }));
});

// User profile update
app.patch('/api/users/profile', (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  
  const userId = req.user.id;
  const updatedFields = {
    name: req.body.name,
    email: req.body.email,
    phone: req.body.phone,
    location: req.body.location
  };
  
  storage.updateUser(userId, updatedFields)
    .then(user => {
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      res.json(user);
    })
    .catch(err => res.status(500).json({ message: 'Failed to update profile', error: err.message }));
});

// Change password
app.post('/api/users/change-password', (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  
  const userId = req.user.id;
  const { currentPassword, newPassword } = req.body;
  
  if (!currentPassword || !newPassword) {
    return res.status(400).json({ message: 'Current password and new password are required' });
  }
  
  // In a real app, we would verify the current password and hash the new password
  // For this demo, we'll just assume it works
  res.json({ success: true, message: 'Password changed successfully' });
});

// Update notification preferences
app.patch('/api/users/notification-preferences', (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  
  const userId = req.user.id;
  
  storage.updateUser(userId, { notificationPreferences: req.body })
    .then(user => {
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      res.json(user.notificationPreferences);
    })
    .catch(err => res.status(500).json({ message: 'Failed to update notification preferences', error: err.message }));
});

// Export user data
app.get('/api/users/export-data', (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  
  const userId = req.user.id;
  
  Promise.all([
    storage.getUser(userId),
    storage.getFoodItemsByUser(userId),
    storage.getDonationsByDonor(userId)
  ])
    .then(([user, foodItems, donations]) => {
      // Remove sensitive data
      if (user) {
        delete user.password;
      }
      
      res.json({
        user,
        foodItems,
        donations
      });
    })
    .catch(err => res.status(500).json({ message: 'Failed to export data', error: err.message }));
});

// Delete account
app.post('/api/users/delete-account', (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  
  // In a real app, we would delete the user account and all associated data
  // For this demo, we'll just simulate it
  
  // Log the user out
  req.logout(err => {
    if (err) {
      return res.status(500).json({ message: 'Logout failed during account deletion', error: err.message });
    }
    
    res.json({ success: true, message: 'Account deleted successfully' });
  });
});

// Create HTTP server
const httpServer = createServer(app);

// Export server
module.exports = httpServer;