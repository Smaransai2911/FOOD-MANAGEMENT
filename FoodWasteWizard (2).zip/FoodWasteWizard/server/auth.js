const passport = require('passport');
const { Strategy: LocalStrategy } = require('passport-local');
const session = require('express-session');
const { scrypt, randomBytes, timingSafeEqual } = require('crypto');
const { promisify } = require('util');
const { storage } = require('./storage');

// Use promisify to convert callback-based scrypt to promise-based
const scryptAsync = promisify(scrypt);

// Regex for password validation
const STRONG_PASSWORD_REGEX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

// Maximum failed login attempts before lockout
const MAX_LOGIN_ATTEMPTS = 5;
const LOCKOUT_TIME = 15 * 60 * 1000; // 15 minutes in milliseconds

// Track failed login attempts
const failedLoginAttempts = new Map();

/**
 * Check if a password meets security requirements
 * @param {string} password - The password to check
 * @returns {object} - Validation result with isValid and message properties
 */
function validatePassword(password) {
  if (!password || password.length < 8) {
    return { 
      isValid: false, 
      message: "Password must be at least 8 characters long" 
    };
  }
  
  if (!STRONG_PASSWORD_REGEX.test(password)) {
    return { 
      isValid: false, 
      message: "Password must include at least one uppercase letter, one lowercase letter, one number, and one special character" 
    };
  }
  
  return { isValid: true };
}

/**
 * Track login attempts and check for account lockouts
 * @param {string} username - The username attempting to login
 * @param {boolean} success - Whether the login was successful
 * @returns {object} - Information about account lockout status
 */
function trackLoginAttempt(username, success) {
  const key = username.toLowerCase();
  const now = Date.now();
  
  // Get current attempts data or initialize if not exists
  const attemptsData = failedLoginAttempts.get(key) || { 
    count: 0, 
    firstAttempt: now,
    lockUntil: 0
  };
  
  // Check if user is currently locked out
  if (attemptsData.lockUntil > now) {
    const remainingTime = Math.ceil((attemptsData.lockUntil - now) / 1000 / 60);
    return {
      isLocked: true,
      remainingMinutes: remainingTime,
      message: `Account is locked. Please try again in ${remainingTime} minutes.`
    };
  }
  
  // Reset on successful login
  if (success) {
    failedLoginAttempts.delete(key);
    return { isLocked: false };
  }
  
  // Increment failed attempts
  attemptsData.count++;
  
  // Check if we should lock the account
  if (attemptsData.count >= MAX_LOGIN_ATTEMPTS) {
    attemptsData.lockUntil = now + LOCKOUT_TIME;
    failedLoginAttempts.set(key, attemptsData);
    return {
      isLocked: true,
      remainingMinutes: LOCKOUT_TIME / 1000 / 60,
      message: `Too many failed login attempts. Account is locked for ${LOCKOUT_TIME / 1000 / 60} minutes.`
    };
  }
  
  // Update the attempts data
  failedLoginAttempts.set(key, attemptsData);
  
  return {
    isLocked: false,
    attemptsLeft: MAX_LOGIN_ATTEMPTS - attemptsData.count
  };
}

/**
 * Hash a password with a random salt using scrypt
 * @param {string} password - The plain text password to hash
 * @returns {Promise<string>} - The hashed password with salt
 */
async function hashPassword(password) {
  const salt = randomBytes(16).toString('hex');
  const buf = await scryptAsync(password, salt, 64);
  return `${buf.toString('hex')}.${salt}`;
}

/**
 * Compare a supplied password with a stored hashed password
 * @param {string} supplied - The plain text password to check
 * @param {string} stored - The stored hashed password with salt
 * @returns {Promise<boolean>} - Whether the passwords match
 */
async function comparePasswords(supplied, stored) {
  const [hashed, salt] = stored.split('.');
  const hashedBuf = Buffer.from(hashed, 'hex');
  const suppliedBuf = await scryptAsync(supplied, salt, 64);
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

function setupAuth(app) {
  const sessionSettings = {
    secret: process.env.SESSION_SECRET || 'github-deployment-secret',
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      maxAge: 1000 * 60 * 60 * 24 * 7, // 1 week
      httpOnly: true,
      secure: false, // Set to false to work with GitHub by default
      sameSite: 'lax'
    }
  };

  app.set('trust proxy', 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        // Check if the account is locked
        const lockStatus = trackLoginAttempt(username, false);
        if (lockStatus.isLocked) {
          return done(null, false, { message: lockStatus.message });
        }
        
        const user = await storage.getUserByUsername(username);
        if (!user || !(await comparePasswords(password, user.password))) {
          // Track failed attempt
          const failedAttempt = trackLoginAttempt(username, false);
          let message = "Invalid username or password";
          
          if (failedAttempt.attemptsLeft) {
            message += `. You have ${failedAttempt.attemptsLeft} attempts remaining before your account is locked.`;
          }
          
          return done(null, false, { message });
        } else {
          // Reset failed attempts on successful login
          trackLoginAttempt(username, true);
          return done(null, user);
        }
      } catch (err) {
        return done(err);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  
  passport.deserializeUser(async (id, done) => {
    try {
      const user = await storage.getUser(id);
      if (!user) {
        return done(null, false);
      }
      
      // Don't send the password hash to the client
      const { password, ...userWithoutPassword } = user;
      done(null, userWithoutPassword);
    } catch (err) {
      done(err);
    }
  });

  app.post("/api/register", async (req, res, next) => {
    try {
      // Validate username
      if (!req.body.username || req.body.username.length < 3) {
        return res.status(400).json({ 
          message: "Username must be at least 3 characters long" 
        });
      }
      
      // Validate password
      const passwordValidation = validatePassword(req.body.password);
      if (!passwordValidation.isValid) {
        return res.status(400).json({ message: passwordValidation.message });
      }
      
      // Check for existing user
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      // Create user with hashed password
      const user = await storage.createUser({
        ...req.body,
        password: await hashPassword(req.body.password),
        createdAt: new Date()
      });

      // Log the user in
      const { password, ...userWithoutPassword } = user;
      req.login(userWithoutPassword, (err) => {
        if (err) return next(err);
        res.status(201).json(userWithoutPassword);
      });
    } catch (err) {
      console.error("Registration error:", err);
      next(err);
    }
  });

  // Custom login handler with better error messages
  app.post("/api/login", (req, res, next) => {
    // Check for empty credentials
    if (!req.body.username || !req.body.password) {
      return res.status(400).json({ message: "Username and password are required" });
    }
    
    // Check if account is locked
    const lockStatus = trackLoginAttempt(req.body.username, false);
    if (lockStatus.isLocked) {
      return res.status(403).json({ message: lockStatus.message });
    }
    
    // Use passport for authentication
    passport.authenticate('local', (err, user, info) => {
      if (err) return next(err);
      
      if (!user) {
        // Authentication failed
        return res.status(401).json({ message: info?.message || "Authentication failed" });
      }
      
      // Manual login
      req.login(user, (err) => {
        if (err) return next(err);
        
        // Track successful login and reset failed attempts
        trackLoginAttempt(req.body.username, true);
        res.status(200).json(user);
      });
    })(req, res, next);
  });

  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    res.json(req.user);
  });
}

module.exports = { 
  setupAuth,
  hashPassword,
  comparePasswords,
  validatePassword,
  trackLoginAttempt
};