const express = require('express');
const path = require('path');
const { log, setupVite, serveStatic } = require('./vite');
const { registerRoutes } = require('./routes');

// Start server with proper error handling
const PORT = process.env.PORT || 5000;

// Create Express app
const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Add security-related headers
app.use((req, res, next) => {
  // Prevent browsers from incorrectly detecting non-scripts as scripts
  res.setHeader('X-Content-Type-Options', 'nosniff');
  // Prevent clickjacking by not allowing the site to be framed
  res.setHeader('X-Frame-Options', 'DENY');
  // Turn on the Cross-site scripting (XSS) filter in browsers
  res.setHeader('X-XSS-Protection', '1; mode=block');
  next();
});

// Set up routes and get server instance
const server = registerRoutes(app);

// Add Vite middleware in development
if (process.env.NODE_ENV === 'development') {
  setupVite(app, server)
    .then(() => {
      // Start server
      server.listen(PORT, '0.0.0.0', () => {
        log(`serving on port ${PORT}`);
      });
    })
    .catch((err) => {
      console.error('Error setting up Vite:', err);
      process.exit(1);
    });
} else {
  // Production: serve static files and start server
  serveStatic(app);
  
  server.listen(PORT, '0.0.0.0', () => {
    log(`serving on port ${PORT}`);
  });
}

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
  process.exit(1);
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  // Don't exit the process in this case
});