const session = require('express-session');
const createMemoryStore = require('memorystore');
const connectPg = require('connect-pg-simple');
const { db, pool } = require('./db');
const { eq, and, lte, gte, desc, sql } = require('drizzle-orm');
const {
  users,
  foodItems,
  donations,
  donationItems,
  recipes,
  recipeIngredients,
  donationLocations
} = require('../shared/schema');

const MemoryStore = createMemoryStore(session);
const PostgresSessionStore = connectPg(session);

// Database storage class
class DatabaseStorage {
  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
    
    // Initialize sample data when running for the first time
    this.initializeDataIfEmpty();
  }
  
  async initializeDataIfEmpty() {
    // Check if any users exist
    const existingUsers = await db.select().from(users).limit(1);
    if (existingUsers.length === 0) {
      console.log('Initializing database with sample data...');
      await this.initializeData();
    }
  }
  
  // User Operations
  async getUser(id) {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }
  
  async getUserByUsername(username) {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }
  
  async createUser(userData) {
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }
  
  async updateUser(id, userData) {
    const [updatedUser] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return updatedUser || undefined;
  }
  
  // Food Item Operations
  async getFoodItem(id) {
    const [item] = await db.select().from(foodItems).where(eq(foodItems.id, id));
    return item || undefined;
  }
  
  async getFoodItemsByUser(userId) {
    return await db
      .select()
      .from(foodItems)
      .where(eq(foodItems.userId, userId))
      .orderBy(desc(foodItems.createdAt));
  }
  
  async getExpiringFoodItems(userId, days) {
    const now = new Date();
    const expiryDate = new Date();
    expiryDate.setDate(now.getDate() + days);
    
    // Because expiryDate is stored as ISO string, we need to convert dates for comparison
    const nowIso = now.toISOString();
    const expiryIso = expiryDate.toISOString();
    
    return await db
      .select()
      .from(foodItems)
      .where(
        and(
          eq(foodItems.userId, userId),
          sql`${foodItems.expiryDate} <= ${expiryIso}`,
          sql`${foodItems.expiryDate} >= ${nowIso}`
        )
      )
      .orderBy(foodItems.expiryDate);
  }
  
  async createFoodItem(itemData) {
    const [item] = await db.insert(foodItems).values(itemData).returning();
    return item;
  }
  
  async updateFoodItem(id, itemData) {
    const [updatedItem] = await db
      .update(foodItems)
      .set(itemData)
      .where(eq(foodItems.id, id))
      .returning();
    return updatedItem || undefined;
  }
  
  async deleteFoodItem(id) {
    const [deletedItem] = await db
      .delete(foodItems)
      .where(eq(foodItems.id, id))
      .returning();
    return !!deletedItem;
  }
  
  // Donation Operations
  async getDonation(id) {
    const [donation] = await db.select().from(donations).where(eq(donations.id, id));
    return donation || undefined;
  }
  
  async getDonationsByDonor(donorId) {
    return await db
      .select()
      .from(donations)
      .where(eq(donations.donorId, donorId))
      .orderBy(desc(donations.createdAt));
  }
  
  async getDonationsByRecipient(recipientId) {
    return await db
      .select()
      .from(donations)
      .where(eq(donations.recipientId, recipientId))
      .orderBy(desc(donations.createdAt));
  }
  
  async getDonationsByStatus(status) {
    return await db
      .select()
      .from(donations)
      .where(eq(donations.status, status))
      .orderBy(desc(donations.createdAt));
  }
  
  async createDonation(donationData) {
    const [donation] = await db.insert(donations).values(donationData).returning();
    return donation;
  }
  
  async updateDonation(id, donationData) {
    const [updatedDonation] = await db
      .update(donations)
      .set(donationData)
      .where(eq(donations.id, id))
      .returning();
    return updatedDonation || undefined;
  }
  
  // Donation Items Operations
  async getDonationItems(donationId) {
    return await db
      .select()
      .from(donationItems)
      .where(eq(donationItems.donationId, donationId));
  }
  
  async addDonationItem(itemData) {
    const [item] = await db.insert(donationItems).values(itemData).returning();
    return item;
  }
  
  async removeDonationItem(id) {
    const [deletedItem] = await db
      .delete(donationItems)
      .where(eq(donationItems.id, id))
      .returning();
    return !!deletedItem;
  }
  
  // Recipe Operations
  async getRecipe(id) {
    const [recipe] = await db.select().from(recipes).where(eq(recipes.id, id));
    return recipe || undefined;
  }
  
  async getAllRecipes() {
    return await db.select().from(recipes);
  }
  
  async getRecipesByIngredients(ingredients) {
    // First, get all recipe ingredients that match any of our ingredients
    const lowerCaseIngredients = ingredients.map(i => i.toLowerCase());
    
    const matchingRecipeIds = await db
      .select({ recipeId: recipeIngredients.recipeId })
      .from(recipeIngredients)
      .where(
        sql`LOWER(${recipeIngredients.name}) IN (${lowerCaseIngredients.join(', ')})`
      );
    
    if (matchingRecipeIds.length === 0) {
      return [];
    }
    
    // Get unique recipe IDs
    const recipeIds = [...new Set(matchingRecipeIds.map(r => r.recipeId))];
    
    // Now get the full recipe details for these IDs
    return await db
      .select()
      .from(recipes)
      .where(
        sql`${recipes.id} IN (${recipeIds.join(', ')})`
      );
  }
  
  async createRecipe(recipe) {
    const [newRecipe] = await db.insert(recipes).values(recipe).returning();
    return newRecipe;
  }
  
  // Recipe Ingredients Operations
  async getRecipeIngredients(recipeId) {
    return await db
      .select()
      .from(recipeIngredients)
      .where(eq(recipeIngredients.recipeId, recipeId));
  }
  
  async addRecipeIngredient(ingredient) {
    const [newIngredient] = await db.insert(recipeIngredients).values(ingredient).returning();
    return newIngredient;
  }
  
  // Donation Location Operations
  async getDonationLocation(id) {
    const [location] = await db.select().from(donationLocations).where(eq(donationLocations.id, id));
    return location || undefined;
  }
  
  async getDonationLocationsByType(type) {
    return await db
      .select()
      .from(donationLocations)
      .where(eq(donationLocations.type, type));
  }
  
  async getAllDonationLocations() {
    return await db.select().from(donationLocations);
  }
  
  async createDonationLocation(location) {
    const [newLocation] = await db.insert(donationLocations).values(location).returning();
    return newLocation;
  }
  
  async updateDonationLocation(id, locationData) {
    const [updatedLocation] = await db
      .update(donationLocations)
      .set(locationData)
      .where(eq(donationLocations.id, id))
      .returning();
    return updatedLocation || undefined;
  }
  
  // Initialize sample data for database
  async initializeData() {
    const now = new Date();
    
    // Sample user (password: password123)
    const hashedPassword = '5361f3b7b3098c51faf4c2bf994e2922cdbf6050f204638b26ea9d65c3bd59d8dc62e9575391cdbffe8c7dbf082c10c92bd0e1c25a1e98b453a7bd43b380e5ed.89b03c33d5c94f6df48a6b399b67aa94';
    
    // Insert demo user
    const [demoUser] = await db.insert(users).values({
      username: 'demo',
      password: hashedPassword,
      name: 'Demo User',
      email: 'demo@example.com',
      role: 'donor'
    }).returning();
    
    // Add sample food items
    const foodItemsData = [
      {
        userId: demoUser.id,
        name: 'Organic Apples',
        category: 'produce',
        quantity: 5,
        unit: 'pieces',
        expiryDate: new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000).toISOString(), // 5 days from now
        notes: 'Fresh from the local market',
        markedForDonation: false,
        isUsed: false,
        isDonated: false,
      },
      {
        userId: demoUser.id,
        name: 'Whole Milk',
        category: 'dairy',
        quantity: 1,
        unit: 'liter',
        expiryDate: new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000).toISOString(), // 3 days from now
        notes: 'Organic valley brand',
        markedForDonation: false,
        isUsed: false,
        isDonated: false,
      },
      {
        userId: demoUser.id,
        name: 'Whole Wheat Bread',
        category: 'bakery',
        quantity: 1,
        unit: 'loaf',
        expiryDate: new Date(now.getTime() + 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days from now
        markedForDonation: true,
        isUsed: false,
        isDonated: false,
      },
      {
        userId: demoUser.id,
        name: 'Canned Beans',
        category: 'canned',
        quantity: 3,
        unit: 'cans',
        expiryDate: new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000).toISOString(), // 1 year from now
        notes: 'Black beans',
        markedForDonation: false,
        isUsed: false,
        isDonated: false,
      }
    ];
    
    // Insert food items
    await db.insert(foodItems).values(foodItemsData);
    
    // Add donation locations
    const donationLocationsData = [
      {
        name: 'Community Food Bank',
        type: 'foodbank',
        address: '123 Main St, Anytown, USA',
        phone: '555-123-4567',
        email: 'info@communityfoodbank.org',
        hours: 'Mon-Fri: 9am-5pm, Sat: 10am-2pm',
        latitude: 40.712776,
        longitude: -74.005974
      },
      {
        name: 'Hope Shelter',
        type: 'shelter',
        address: '456 Oak Ave, Anytown, USA',
        phone: '555-987-6543',
        email: 'contact@hopeshelter.org',
        hours: '24/7',
        latitude: 40.714541,
        longitude: -74.007789
      },
      {
        name: 'Neighborhood Soup Kitchen',
        type: 'soupkitchen',
        address: '789 Elm St, Anytown, USA',
        phone: '555-456-7890',
        email: 'help@neighborsoup.org',
        hours: 'Mon-Sun: 11am-1pm, 5pm-7pm',
        latitude: 40.718217,
        longitude: -74.013937
      }
    ];
    
    // Insert donation locations
    await db.insert(donationLocations).values(donationLocationsData);
    
    // Add sample recipes
    const recipesData = [
      {
        name: 'Apple Cinnamon Oatmeal',
        description: 'A warm and comforting breakfast using apples that are about to expire.',
        prepTime: 5,
        cookTime: 10,
        servings: 2,
        difficulty: 'easy',
        imageUrl: '/img/recipes/apple-oatmeal.jpg',
        instructions: JSON.stringify([
          'Dice the apples into small cubes.',
          'In a saucepan, bring water to a boil and add oats.',
          'Add diced apples, cinnamon, and a pinch of salt.',
          'Cook for 5 minutes, stirring occasionally.',
          'Remove from heat and let stand for 2 minutes.',
          'Drizzle with honey or maple syrup if desired.'
        ]),
        rating: 4.5,
        reviewCount: 28,
        calories: 220,
        protein: '6g',
        carbs: '42g',
        fat: '3g',
        tips: JSON.stringify([
          'Add a tablespoon of nut butter for extra protein.',
          'Sprinkle with chopped nuts for added crunch.',
          'This recipe works well with any type of apple.'
        ])
      },
      {
        name: 'Vegetable Stir Fry',
        description: 'Quick stir fry that uses up vegetables before they go bad.',
        prepTime: 15,
        cookTime: 10,
        servings: 3,
        difficulty: 'medium',
        imageUrl: '/img/recipes/veggie-stir-fry.jpg',
        instructions: JSON.stringify([
          'Slice all vegetables into bite-sized pieces.',
          'Heat oil in a wok or large pan over high heat.',
          'Add garlic and ginger, stir for 30 seconds.',
          'Add vegetables in order of cooking time (harder veggies first).',
          'Stir frequently for 5-7 minutes until vegetables are tender-crisp.',
          'Add soy sauce, sesame oil, and any other seasonings.',
          'Serve over rice or noodles.'
        ]),
        rating: 4.3,
        reviewCount: 42,
        calories: 180,
        protein: '5g',
        carbs: '20g',
        fat: '8g',
        tips: JSON.stringify([
          'Add tofu, chicken, or beef for extra protein.',
          'Use any combination of vegetables you have on hand.',
          'Sauce can be made ahead and stored in the fridge.'
        ])
      },
      {
        name: 'Banana Bread',
        description: 'Perfect way to use overripe bananas.',
        prepTime: 15,
        cookTime: 60,
        servings: 10,
        difficulty: 'easy',
        imageUrl: '/img/recipes/banana-bread.jpg',
        instructions: JSON.stringify([
          'Preheat oven to 350°F (175°C).',
          'Mash bananas in a large bowl.',
          'Add melted butter, sugar, egg, and vanilla, and mix well.',
          'In a separate bowl, combine flour, baking soda, and salt.',
          'Fold dry ingredients into wet ingredients.',
          'Pour batter into a greased loaf pan.',
          'Bake for 55-60 minutes, or until a toothpick comes out clean.',
          'Let cool before slicing.'
        ]),
        rating: 4.8,
        reviewCount: 120,
        calories: 240,
        protein: '3g',
        carbs: '36g',
        fat: '10g',
        tips: JSON.stringify([
          'Add chocolate chips or nuts for extra flavor.',
          'The riper the bananas, the sweeter the bread.',
          'Freeze slices for a quick snack later.'
        ])
      }
    ];
    
    // Insert recipes and get the returned recipes with IDs
    const insertedRecipes = await db.insert(recipes).values(recipesData).returning();
    
    // Add recipe ingredients for each recipe
    const recipeIngredientsData = [
      // For Apple Cinnamon Oatmeal
      { recipeId: insertedRecipes[0].id, name: 'apple', amount: 2, unit: 'medium' },
      { recipeId: insertedRecipes[0].id, name: 'rolled oats', amount: 1, unit: 'cup' },
      { recipeId: insertedRecipes[0].id, name: 'water', amount: 2, unit: 'cups' },
      { recipeId: insertedRecipes[0].id, name: 'cinnamon', amount: 1, unit: 'teaspoon' },
      { recipeId: insertedRecipes[0].id, name: 'salt', amount: 0.25, unit: 'teaspoon' },
      { recipeId: insertedRecipes[0].id, name: 'honey', amount: 1, unit: 'tablespoon' },
      
      // For Vegetable Stir Fry
      { recipeId: insertedRecipes[1].id, name: 'bell pepper', amount: 1, unit: 'medium' },
      { recipeId: insertedRecipes[1].id, name: 'broccoli', amount: 1, unit: 'cup' },
      { recipeId: insertedRecipes[1].id, name: 'carrot', amount: 2, unit: 'medium' },
      { recipeId: insertedRecipes[1].id, name: 'snow peas', amount: 1, unit: 'cup' },
      { recipeId: insertedRecipes[1].id, name: 'garlic', amount: 2, unit: 'cloves' },
      { recipeId: insertedRecipes[1].id, name: 'ginger', amount: 1, unit: 'tablespoon' },
      { recipeId: insertedRecipes[1].id, name: 'vegetable oil', amount: 2, unit: 'tablespoons' },
      { recipeId: insertedRecipes[1].id, name: 'soy sauce', amount: 3, unit: 'tablespoons' },
      { recipeId: insertedRecipes[1].id, name: 'sesame oil', amount: 1, unit: 'teaspoon' },
      
      // For Banana Bread
      { recipeId: insertedRecipes[2].id, name: 'ripe bananas', amount: 3, unit: 'medium' },
      { recipeId: insertedRecipes[2].id, name: 'butter', amount: 0.5, unit: 'cup' },
      { recipeId: insertedRecipes[2].id, name: 'sugar', amount: 0.75, unit: 'cup' },
      { recipeId: insertedRecipes[2].id, name: 'egg', amount: 1, unit: 'large' },
      { recipeId: insertedRecipes[2].id, name: 'vanilla extract', amount: 1, unit: 'teaspoon' },
      { recipeId: insertedRecipes[2].id, name: 'all-purpose flour', amount: 1.5, unit: 'cups' },
      { recipeId: insertedRecipes[2].id, name: 'baking soda', amount: 1, unit: 'teaspoon' },
      { recipeId: insertedRecipes[2].id, name: 'salt', amount: 0.5, unit: 'teaspoon' }
    ];
    
    // Insert recipe ingredients
    await db.insert(recipeIngredients).values(recipeIngredientsData);
    
    console.log('Sample data initialized successfully!');
  }
}

// Memory storage class (fallback if database is not available)
class MemStorage {
  constructor() {
    this.users = new Map();
    this.foodItems = new Map();
    this.donations = new Map();
    this.donationItems = new Map();
    this.recipes = new Map();
    this.recipeIngredients = new Map();
    this.donationLocations = new Map();
    
    this.nextUserId = 1;
    this.nextFoodItemId = 1;
    this.nextDonationId = 1;
    this.nextDonationItemId = 1;
    this.nextRecipeId = 1;
    this.nextRecipeIngredientId = 1;
    this.nextDonationLocationId = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
    
    // Initialize some sample data for testing
    this.initializeData();
  }
  
  // User Operations
  async getUser(id) {
    return this.users.get(id);
  }
  
  async getUserByUsername(username) {
    for (const user of this.users.values()) {
      if (user.username === username) {
        return user;
      }
    }
    return undefined;
  }
  
  async createUser(userData) {
    const id = this.nextUserId++;
    const now = new Date();
    const user = { ...userData, id, createdAt: now };
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id, userData) {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  // Food Item Operations
  async getFoodItem(id) {
    return this.foodItems.get(id);
  }
  
  async getFoodItemsByUser(userId) {
    const result = [];
    for (const item of this.foodItems.values()) {
      if (item.userId === userId) {
        result.push(item);
      }
    }
    return result;
  }
  
  async getExpiringFoodItems(userId, days) {
    const now = new Date();
    const expiryDate = new Date();
    expiryDate.setDate(now.getDate() + days);
    
    const result = [];
    for (const item of this.foodItems.values()) {
      if (item.userId === userId) {
        const itemExpiry = new Date(item.expiryDate);
        if (itemExpiry <= expiryDate && itemExpiry >= now) {
          result.push(item);
        }
      }
    }
    return result;
  }
  
  async createFoodItem(itemData) {
    const id = this.nextFoodItemId++;
    const now = new Date();
    const foodItem = { ...itemData, id, createdAt: now };
    this.foodItems.set(id, foodItem);
    return foodItem;
  }
  
  async updateFoodItem(id, itemData) {
    const item = this.foodItems.get(id);
    if (!item) return undefined;
    
    const updatedItem = { ...item, ...itemData };
    this.foodItems.set(id, updatedItem);
    return updatedItem;
  }
  
  async deleteFoodItem(id) {
    return this.foodItems.delete(id);
  }
  
  // Donation Operations
  async getDonation(id) {
    return this.donations.get(id);
  }
  
  async getDonationsByDonor(donorId) {
    const result = [];
    for (const donation of this.donations.values()) {
      if (donation.donorId === donorId) {
        result.push(donation);
      }
    }
    return result;
  }
  
  async getDonationsByRecipient(recipientId) {
    const result = [];
    for (const donation of this.donations.values()) {
      if (donation.recipientId === recipientId) {
        result.push(donation);
      }
    }
    return result;
  }
  
  async getDonationsByStatus(status) {
    const result = [];
    for (const donation of this.donations.values()) {
      if (donation.status === status) {
        result.push(donation);
      }
    }
    return result;
  }
  
  async createDonation(donationData) {
    const id = this.nextDonationId++;
    const now = new Date();
    const newDonation = { ...donationData, id, createdAt: now };
    this.donations.set(id, newDonation);
    return newDonation;
  }
  
  async updateDonation(id, donationData) {
    const donation = this.donations.get(id);
    if (!donation) return undefined;
    
    const updatedDonation = { ...donation, ...donationData };
    this.donations.set(id, updatedDonation);
    return updatedDonation;
  }
  
  // Donation Items Operations
  async getDonationItems(donationId) {
    const result = [];
    for (const item of this.donationItems.values()) {
      if (item.donationId === donationId) {
        result.push(item);
      }
    }
    return result;
  }
  
  async addDonationItem(itemData) {
    const id = this.nextDonationItemId++;
    const donationItem = { ...itemData, id };
    this.donationItems.set(id, donationItem);
    return donationItem;
  }
  
  async removeDonationItem(id) {
    return this.donationItems.delete(id);
  }
  
  // Recipe Operations
  async getRecipe(id) {
    return this.recipes.get(id);
  }
  
  async getAllRecipes() {
    return Array.from(this.recipes.values());
  }
  
  async getRecipesByIngredients(ingredients) {
    // This is a simplified version that checks if any of the ingredients
    // for a recipe match any of the provided ingredients
    const result = [];
    const lowerCaseIngredients = ingredients.map(i => i.toLowerCase());
    
    // Get all recipes
    const allRecipes = await this.getAllRecipes();
    
    for (const recipe of allRecipes) {
      // Get ingredients for this recipe
      const recipeIngredients = await this.getRecipeIngredients(recipe.id);
      const ingredientNames = recipeIngredients.map(i => i.name.toLowerCase());
      
      // Check if there's any overlap in ingredients
      const hasMatchingIngredient = lowerCaseIngredients.some(ingredient => 
        ingredientNames.includes(ingredient)
      );
      
      if (hasMatchingIngredient) {
        result.push(recipe);
      }
    }
    
    return result;
  }
  
  async createRecipe(recipe) {
    const id = this.nextRecipeId++;
    const now = new Date();
    const newRecipe = { ...recipe, id, createdAt: now };
    this.recipes.set(id, newRecipe);
    return newRecipe;
  }
  
  // Recipe Ingredients Operations
  async getRecipeIngredients(recipeId) {
    const result = [];
    for (const ingredient of this.recipeIngredients.values()) {
      if (ingredient.recipeId === recipeId) {
        result.push(ingredient);
      }
    }
    return result;
  }
  
  async addRecipeIngredient(ingredient) {
    const id = this.nextRecipeIngredientId++;
    const recipeIngredient = { ...ingredient, id };
    this.recipeIngredients.set(id, recipeIngredient);
    return recipeIngredient;
  }
  
  // Donation Location Operations
  async getDonationLocation(id) {
    return this.donationLocations.get(id);
  }
  
  async getDonationLocationsByType(type) {
    const result = [];
    for (const location of this.donationLocations.values()) {
      if (location.type === type) {
        result.push(location);
      }
    }
    return result;
  }
  
  async getAllDonationLocations() {
    return Array.from(this.donationLocations.values());
  }
  
  async createDonationLocation(location) {
    const id = this.nextDonationLocationId++;
    const donationLocation = { ...location, id };
    this.donationLocations.set(id, donationLocation);
    return donationLocation;
  }
  
  async updateDonationLocation(id, locationData) {
    const location = this.donationLocations.get(id);
    if (!location) return undefined;
    
    const updatedLocation = { ...location, ...locationData };
    this.donationLocations.set(id, updatedLocation);
    return updatedLocation;
  }
  
  // Initialize sample data
  initializeData() {
    // Add a test user
    const now = new Date();
    
    // Sample user (password: password123)
    this.users.set(1, {
      id: 1,
      username: 'demo',
      password: '5361f3b7b3098c51faf4c2bf994e2922cdbf6050f204638b26ea9d65c3bd59d8dc62e9575391cdbffe8c7dbf082c10c92bd0e1c25a1e98b453a7bd43b380e5ed.89b03c33d5c94f6df48a6b399b67aa94',
      name: 'Demo User',
      email: 'demo@example.com',
      role: 'donor',
      createdAt: now
    });
    this.nextUserId = 2;
    
    // Add sample food items
    const foodItems = [
      {
        userId: 1,
        name: 'Organic Apples',
        category: 'produce',
        quantity: 5,
        unit: 'pieces',
        expiryDate: new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000).toISOString(), // 5 days from now
        notes: 'Fresh from the local market',
        markedForDonation: false,
        isUsed: false,
        isDonated: false,
      },
      {
        userId: 1,
        name: 'Whole Milk',
        category: 'dairy',
        quantity: 1,
        unit: 'liter',
        expiryDate: new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000).toISOString(), // 3 days from now
        notes: 'Organic valley brand',
        markedForDonation: false,
        isUsed: false,
        isDonated: false,
      },
      {
        userId: 1,
        name: 'Whole Wheat Bread',
        category: 'bakery',
        quantity: 1,
        unit: 'loaf',
        expiryDate: new Date(now.getTime() + 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days from now
        markedForDonation: true,
        isUsed: false,
        isDonated: false,
      },
      {
        userId: 1,
        name: 'Canned Beans',
        category: 'canned',
        quantity: 3,
        unit: 'cans',
        expiryDate: new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000).toISOString(), // 1 year from now
        notes: 'Black beans',
        markedForDonation: false,
        isUsed: false,
        isDonated: false,
      }
    ];
    
    foodItems.forEach(item => {
      const id = this.nextFoodItemId++;
      this.foodItems.set(id, {
        ...item,
        id,
        createdAt: now
      });
    });
    
    // Initialize some donation locations
    const donationLocations = [
      {
        name: 'Community Food Bank',
        type: 'foodbank',
        address: '123 Main St, Anytown, USA',
        phone: '555-123-4567',
        email: 'info@communityfoodbank.org',
        hours: 'Mon-Fri: 9am-5pm, Sat: 10am-2pm',
        latitude: 40.712776,
        longitude: -74.005974
      },
      {
        name: 'Hope Shelter',
        type: 'shelter',
        address: '456 Oak Ave, Anytown, USA',
        phone: '555-987-6543',
        email: 'contact@hopeshelter.org',
        hours: '24/7',
        latitude: 40.714541,
        longitude: -74.007789
      },
      {
        name: 'Neighborhood Soup Kitchen',
        type: 'soupkitchen',
        address: '789 Elm St, Anytown, USA',
        phone: '555-456-7890',
        email: 'help@neighborsoup.org',
        hours: 'Mon-Sun: 11am-1pm, 5pm-7pm',
        latitude: 40.718217,
        longitude: -74.013937
      }
    ];
    
    donationLocations.forEach(location => {
      const id = this.nextDonationLocationId++;
      this.donationLocations.set(id, {
        ...location,
        id
      });
    });
    
    // Initialize sample recipes
    this.initializeRecipes();
  }
  
  initializeRecipes() {
    const now = new Date();
    
    const recipes = [
      {
        name: 'Apple Cinnamon Oatmeal',
        description: 'A warm and comforting breakfast using apples that are about to expire.',
        prepTime: 5,
        cookTime: 10,
        servings: 2,
        difficulty: 'easy',
        imageUrl: '/img/recipes/apple-oatmeal.jpg',
        instructions: [
          'Dice the apples into small cubes.',
          'In a saucepan, bring water to a boil and add oats.',
          'Add diced apples, cinnamon, and a pinch of salt.',
          'Cook for 5 minutes, stirring occasionally.',
          'Remove from heat and let stand for 2 minutes.',
          'Drizzle with honey or maple syrup if desired.'
        ],
        rating: 4.5,
        reviewCount: 28,
        calories: 220,
        protein: '6g',
        carbs: '42g',
        fat: '3g',
        tips: [
          'Add a tablespoon of nut butter for extra protein.',
          'Sprinkle with chopped nuts for added crunch.',
          'This recipe works well with any type of apple.'
        ]
      },
      {
        name: 'Vegetable Stir Fry',
        description: 'Quick stir fry that uses up vegetables before they go bad.',
        prepTime: 15,
        cookTime: 10,
        servings: 3,
        difficulty: 'medium',
        imageUrl: '/img/recipes/veggie-stir-fry.jpg',
        instructions: [
          'Slice all vegetables into bite-sized pieces.',
          'Heat oil in a wok or large pan over high heat.',
          'Add garlic and ginger, stir for 30 seconds.',
          'Add vegetables in order of cooking time (harder veggies first).',
          'Stir frequently for 5-7 minutes until vegetables are tender-crisp.',
          'Add soy sauce, sesame oil, and any other seasonings.',
          'Serve over rice or noodles.'
        ],
        rating: 4.3,
        reviewCount: 42,
        calories: 180,
        protein: '5g',
        carbs: '20g',
        fat: '8g',
        tips: [
          'Add tofu, chicken, or beef for extra protein.',
          'Use any combination of vegetables you have on hand.',
          'Sauce can be made ahead and stored in the fridge.'
        ]
      },
      {
        name: 'Banana Bread',
        description: 'Perfect way to use overripe bananas.',
        prepTime: 15,
        cookTime: 60,
        servings: 10,
        difficulty: 'easy',
        imageUrl: '/img/recipes/banana-bread.jpg',
        instructions: [
          'Preheat oven to 350°F (175°C).',
          'Mash bananas in a large bowl.',
          'Add melted butter, sugar, egg, and vanilla, and mix well.',
          'In a separate bowl, combine flour, baking soda, and salt.',
          'Fold dry ingredients into wet ingredients.',
          'Pour batter into a greased loaf pan.',
          'Bake for 55-60 minutes, or until a toothpick comes out clean.',
          'Let cool before slicing.'
        ],
        rating: 4.8,
        reviewCount: 120,
        calories: 240,
        protein: '3g',
        carbs: '36g',
        fat: '10g',
        tips: [
          'Add chocolate chips or nuts for extra flavor.',
          'The riper the bananas, the sweeter the bread.',
          'Freeze slices for a quick snack later.'
        ]
      }
    ];
    
    recipes.forEach(recipe => {
      const id = this.nextRecipeId++;
      this.recipes.set(id, {
        ...recipe,
        id,
        createdAt: now
      });
    });
    
    // Add recipe ingredients
    const recipeIngredients = [
      // For Apple Cinnamon Oatmeal
      { recipeId: 1, name: 'apple', amount: 2, unit: 'medium' },
      { recipeId: 1, name: 'rolled oats', amount: 1, unit: 'cup' },
      { recipeId: 1, name: 'water', amount: 2, unit: 'cups' },
      { recipeId: 1, name: 'cinnamon', amount: 1, unit: 'teaspoon' },
      { recipeId: 1, name: 'salt', amount: 0.25, unit: 'teaspoon' },
      { recipeId: 1, name: 'honey', amount: 1, unit: 'tablespoon' },
      
      // For Vegetable Stir Fry
      { recipeId: 2, name: 'bell pepper', amount: 1, unit: 'medium' },
      { recipeId: 2, name: 'broccoli', amount: 1, unit: 'cup' },
      { recipeId: 2, name: 'carrot', amount: 2, unit: 'medium' },
      { recipeId: 2, name: 'snow peas', amount: 1, unit: 'cup' },
      { recipeId: 2, name: 'garlic', amount: 2, unit: 'cloves' },
      { recipeId: 2, name: 'ginger', amount: 1, unit: 'tablespoon' },
      { recipeId: 2, name: 'vegetable oil', amount: 2, unit: 'tablespoons' },
      { recipeId: 2, name: 'soy sauce', amount: 3, unit: 'tablespoons' },
      { recipeId: 2, name: 'sesame oil', amount: 1, unit: 'teaspoon' },
      
      // For Banana Bread
      { recipeId: 3, name: 'ripe bananas', amount: 3, unit: 'medium' },
      { recipeId: 3, name: 'butter', amount: 0.5, unit: 'cup' },
      { recipeId: 3, name: 'sugar', amount: 0.75, unit: 'cup' },
      { recipeId: 3, name: 'egg', amount: 1, unit: 'large' },
      { recipeId: 3, name: 'vanilla extract', amount: 1, unit: 'teaspoon' },
      { recipeId: 3, name: 'all-purpose flour', amount: 1.5, unit: 'cups' },
      { recipeId: 3, name: 'baking soda', amount: 1, unit: 'teaspoon' },
      { recipeId: 3, name: 'salt', amount: 0.5, unit: 'teaspoon' }
    ];
    
    recipeIngredients.forEach(ingredient => {
      const id = this.nextRecipeIngredientId++;
      this.recipeIngredients.set(id, {
        ...ingredient,
        id
      });
    });
  }
}

// Create and export the storage instance
// Always use in-memory storage for GitHub deployment simplicity
const storage = new MemStorage();
console.log('Using in-memory storage for data persistence');

module.exports = { storage, DatabaseStorage, MemStorage };