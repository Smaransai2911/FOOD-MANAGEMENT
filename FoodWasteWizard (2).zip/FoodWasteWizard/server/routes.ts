import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { insertFoodItemSchema, insertDonationSchema, insertDonationItemSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // Food Items API
  app.get("/api/food-items", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const userId = req.user!.id;
      const foodItems = await storage.getFoodItemsByUser(userId);
      res.json(foodItems);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch food items" });
    }
  });

  app.get("/api/food-items/expiring", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const userId = req.user!.id;
      const days = parseInt(req.query.days as string) || 7;
      const expiringItems = await storage.getExpiringFoodItems(userId, days);
      res.json(expiringItems);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch expiring food items" });
    }
  });

  app.post("/api/food-items", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const userId = req.user!.id;
      const validatedData = insertFoodItemSchema.parse({
        ...req.body,
        userId
      });
      
      const foodItem = await storage.createFoodItem(validatedData);
      res.status(201).json(foodItem);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create food item" });
    }
  });

  app.put("/api/food-items/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const id = parseInt(req.params.id);
      const foodItem = await storage.getFoodItem(id);
      
      if (!foodItem) {
        return res.status(404).json({ message: "Food item not found" });
      }
      
      if (foodItem.userId !== req.user!.id) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const updatedItem = await storage.updateFoodItem(id, req.body);
      res.json(updatedItem);
    } catch (error) {
      res.status(500).json({ message: "Failed to update food item" });
    }
  });

  app.delete("/api/food-items/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const id = parseInt(req.params.id);
      const foodItem = await storage.getFoodItem(id);
      
      if (!foodItem) {
        return res.status(404).json({ message: "Food item not found" });
      }
      
      if (foodItem.userId !== req.user!.id) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      await storage.deleteFoodItem(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete food item" });
    }
  });

  // Donations API
  app.get("/api/donations", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const userId = req.user!.id;
      let donations;
      
      if (req.user!.role === "donor") {
        donations = await storage.getDonationsByDonor(userId);
      } else if (["ngo", "volunteer"].includes(req.user!.role)) {
        donations = await storage.getDonationsByRecipient(userId);
      } else if (req.user!.role === "admin") {
        // Admins can see all donations
        const status = req.query.status as string;
        if (status) {
          donations = await storage.getDonationsByStatus(status);
        } else {
          // Get all donations (would need additional method in a real app)
          const pendingDonations = await storage.getDonationsByStatus("pending");
          const acceptedDonations = await storage.getDonationsByStatus("accepted");
          const scheduledDonations = await storage.getDonationsByStatus("scheduled");
          const completedDonations = await storage.getDonationsByStatus("completed");
          const cancelledDonations = await storage.getDonationsByStatus("cancelled");
          
          donations = [
            ...pendingDonations, 
            ...acceptedDonations, 
            ...scheduledDonations,
            ...completedDonations,
            ...cancelledDonations
          ];
        }
      }
      
      res.json(donations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch donations" });
    }
  });

  app.post("/api/donations", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    if (req.user!.role !== "donor") {
      return res.status(403).json({ message: "Only donors can create donations" });
    }
    
    try {
      const donorId = req.user!.id;
      const validatedData = insertDonationSchema.parse({
        ...req.body,
        donorId
      });
      
      const donation = await storage.createDonation(validatedData);
      
      // Process donation items if provided
      if (req.body.items && Array.isArray(req.body.items)) {
        for (const item of req.body.items) {
          const validatedItem = insertDonationItemSchema.parse({
            ...item,
            donationId: donation.id
          });
          
          await storage.addDonationItem(validatedItem);
          
          // Update food item availability
          const foodItem = await storage.getFoodItem(validatedItem.foodItemId);
          if (foodItem && foodItem.userId === donorId) {
            await storage.updateFoodItem(foodItem.id, {
              isAvailableForDonation: true
            });
          }
        }
      }
      
      res.status(201).json(donation);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create donation" });
    }
  });

  app.put("/api/donations/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const id = parseInt(req.params.id);
      const donation = await storage.getDonation(id);
      
      if (!donation) {
        return res.status(404).json({ message: "Donation not found" });
      }
      
      // Check permissions based on role
      const userId = req.user!.id;
      const userRole = req.user!.role;
      
      if (userRole === "donor" && donation.donorId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      if (userRole === "ngo" && donation.recipientId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      // Update donation
      const updatedDonation = await storage.updateDonation(id, req.body);
      res.json(updatedDonation);
    } catch (error) {
      res.status(500).json({ message: "Failed to update donation" });
    }
  });

  app.get("/api/donations/:id/items", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const donationId = parseInt(req.params.id);
      const donation = await storage.getDonation(donationId);
      
      if (!donation) {
        return res.status(404).json({ message: "Donation not found" });
      }
      
      // Check access permissions
      const userId = req.user!.id;
      const userRole = req.user!.role;
      
      if (userRole === "donor" && donation.donorId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      if (userRole === "ngo" && donation.recipientId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const donationItems = await storage.getDonationItems(donationId);
      
      // Get the related food items for each donation item
      const donationItemsWithDetails = await Promise.all(donationItems.map(async (item) => {
        const foodItem = await storage.getFoodItem(item.foodItemId);
        return {
          ...item,
          foodItem
        };
      }));
      
      res.json(donationItemsWithDetails);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch donation items" });
    }
  });

  // Recipes API
  app.get("/api/recipes", async (req, res) => {
    try {
      const recipes = await storage.getAllRecipes();
      res.json(recipes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recipes" });
    }
  });

  app.get("/api/recipes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const recipe = await storage.getRecipe(id);
      
      if (!recipe) {
        return res.status(404).json({ message: "Recipe not found" });
      }
      
      res.json(recipe);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recipe" });
    }
  });

  app.get("/api/recipes/match", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const ingredients = req.query.ingredients as string[];
      
      if (!ingredients || !Array.isArray(ingredients)) {
        return res.status(400).json({ message: "Ingredients must be provided as an array" });
      }
      
      const matchingRecipes = await storage.getRecipesByIngredients(ingredients);
      res.json(matchingRecipes);
    } catch (error) {
      res.status(500).json({ message: "Failed to match recipes" });
    }
  });

  // Donation Locations API
  app.get("/api/donation-locations", async (req, res) => {
    try {
      let locations;
      
      if (req.query.type) {
        locations = await storage.getDonationLocationsByType(req.query.type as string);
      } else {
        locations = await storage.getAllDonationLocations();
      }
      
      res.json(locations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch donation locations" });
    }
  });

  // Stats API
  app.get("/api/stats", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const userId = req.user!.id;
      
      // Get user's total food items
      const foodItems = await storage.getFoodItemsByUser(userId);
      const totalItems = foodItems.length;
      
      // Get expiring items (within 7 days)
      const expiringItems = await storage.getExpiringFoodItems(userId, 7);
      
      // Get donations made
      const donations = await storage.getDonationsByDonor(userId);
      const completedDonations = donations.filter(d => d.status === "completed");
      
      // Calculate waste reduced (simple estimation)
      // In a real app, this would be more sophisticated
      const wasteReduced = completedDonations.length * 5; // Assume 5kg per donation
      
      res.json({
        totalItems,
        expiringSoon: expiringItems.length,
        donationsMade: completedDonations.length,
        wasteReduced
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
