import passport from 'passport';
import { Strategy as LocalStrategy } from 'passport-local';
import bcrypt from 'bcrypt';

// Import User model
import User from '../models/userModel.js';

export const setupAuth = (app) => {
  // Initialize passport
  app.use(passport.initialize());
  app.use(passport.session());

  // Serialize user for session
  passport.serializeUser((user, done) => {
    done(null, user.id);
  });

  // Deserialize user from session
  passport.deserializeUser(async (id, done) => {
    try {
      const user = await User.findById(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Local strategy setup
  passport.use(new LocalStrategy(
    { usernameField: 'email' },
    async (email, password, done) => {
      try {
        // Find user by email
        const user = await User.findOne({ email });
        
        // If user doesn't exist
        if (!user) {
          return done(null, false, { message: 'Invalid email or password' });
        }
        
        // Check password
        const isMatch = await bcrypt.compare(password, user.password);
        
        if (!isMatch) {
          return done(null, false, { message: 'Invalid email or password' });
        }
        
        // Success
        return done(null, user);
      } catch (error) {
        return done(error);
      }
    }
  ));
  
  // Helper methods for route protection
  app.use((req, res, next) => {
    // Check if user is authenticated
    res.locals.isAuthenticated = req.isAuthenticated();
    
    // Make user data available to templates
    res.locals.user = req.user || null;
    
    next();
  });
};