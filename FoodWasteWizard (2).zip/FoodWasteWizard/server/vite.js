const { createServer } = require('vite');
const { dirname, resolve, join } = require('path');
const express = require('express');
const fs = require('fs');

/**
 * Log a message with a specific source
 */
function log(message, source = "express") {
  console.log(`${new Date().toLocaleTimeString()} [${source}] ${message}`);
}

/**
 * Set up Vite in middleware mode for the Express app
 */
async function setupVite(app, server) {
  const root = process.cwd();
  const clientRoot = join(root, 'client');
  
  try {
    // Create Vite server in middleware mode with direct configuration
    const vite = await createServer({
      configFile: false,
      root: clientRoot,
      server: {
        middlewareMode: true,
        hmr: {
          server,
        },
        // Allow specific host mentioned in the error message
        host: '0.0.0.0',
        allowedHosts: [
          '6cc9dda6-0ecf-4d89-99cd-915e5d31b57a-00-2xheci1p7q2j.riker.replit.dev',
          'all'
        ]
      },
      appType: 'spa',
      resolve: {
        alias: {
          '@': join(root, 'client/src'),
          '@assets': join(root, 'attached_assets'),
          '@shared': join(root, 'shared'),
        },
      },
      plugins: [
        require('@vitejs/plugin-react')(),
      ],
      // Force Vite to behave in a Replit environment
      optimizeDeps: {
        force: true
      }
    });

    // Add vite middleware to the express app
    app.use(vite.middlewares);
    
    // Serve index.html for any route
    app.use('*', async (req, res, next) => {
      try {
        const url = req.originalUrl;
        
        // Get the template
        const templatePath = join(clientRoot, 'index.html');
        let template = fs.readFileSync(templatePath, 'utf-8');
        
        // Transform the template with Vite and send it
        const html = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(html);
      } catch (e) {
        next(e);
      }
    });
    
    log("Vite middleware added", "vite");
    
    return vite;
  } catch (error) {
    console.error("Error setting up Vite:", error);
    throw error;
  }
}

/**
 * Serve static files in production
 */
function serveStatic(app) {
  const root = process.cwd();
  const clientRoot = join(root, 'client');
  const distDir = resolve(clientRoot, 'dist');
  
  app.use(express.static(distDir));
  
  // Fallback for SPA
  app.get('*', (req, res) => {
    res.sendFile(resolve(distDir, 'index.html'));
  });
  
  log("Serving static files from: " + distDir);
}

module.exports = {
  log,
  setupVite,
  serveStatic
};