import express from 'express';
import passport from 'passport';
import bcrypt from 'bcrypt';
import User from '../models/userModel.js';

const router = express.Router();

// Middleware to check if user is authenticated
const isAuthenticated = (req, res, next) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: 'You must be logged in to access this resource' });
};

// Register new user
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, phone, address, role } = req.body;
    
    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'User with this email already exists' });
    }
    
    // Create new user
    const newUser = new User({
      name,
      email,
      password, // Will be hashed by pre-save hook
      phone,
      address,
      role: role || 'user'
    });
    
    // Save user to database
    await newUser.save();
    
    // Log in the user after registration
    req.login(newUser, (err) => {
      if (err) {
        return res.status(500).json({ message: 'Error during login after registration', error: err.message });
      }
      
      // Return user info (exclude password)
      const userResponse = { ...newUser.toObject() };
      delete userResponse.password;
      
      return res.status(201).json(userResponse);
    });
  } catch (error) {
    res.status(500).json({ message: 'Error creating user', error: error.message });
  }
});

// Login user
router.post('/login', (req, res, next) => {
  passport.authenticate('local', (err, user, info) => {
    if (err) {
      return res.status(500).json({ message: 'Error during authentication', error: err.message });
    }
    
    if (!user) {
      return res.status(401).json({ message: info.message || 'Authentication failed' });
    }
    
    req.login(user, (err) => {
      if (err) {
        return res.status(500).json({ message: 'Error during login', error: err.message });
      }
      
      // Return user info (exclude password)
      const userResponse = { ...user.toObject() };
      delete userResponse.password;
      
      return res.status(200).json(userResponse);
    });
  })(req, res, next);
});

// Logout user
router.post('/logout', (req, res) => {
  req.logout((err) => {
    if (err) {
      return res.status(500).json({ message: 'Error during logout', error: err.message });
    }
    res.status(200).json({ message: 'Logged out successfully' });
  });
});

// Get current user info
router.get('/user', isAuthenticated, (req, res) => {
  // Return user info (exclude password)
  const userResponse = { ...req.user.toObject() };
  delete userResponse.password;
  
  res.status(200).json(userResponse);
});

// Update user profile
router.put('/user/:id', isAuthenticated, async (req, res) => {
  try {
    // Check if user is updating their own profile or is an admin
    if (req.user.id !== req.params.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Unauthorized to update this profile' });
    }
    
    const { name, email, phone, address } = req.body;
    
    // Find and update user
    const updatedUser = await User.findByIdAndUpdate(
      req.params.id,
      { name, email, phone, address },
      { new: true, runValidators: true }
    );
    
    if (!updatedUser) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Return updated user info (exclude password)
    const userResponse = { ...updatedUser.toObject() };
    delete userResponse.password;
    
    res.status(200).json(userResponse);
  } catch (error) {
    res.status(500).json({ message: 'Error updating user', error: error.message });
  }
});

// Update user password
router.put('/user/:id/password', isAuthenticated, async (req, res) => {
  try {
    // Check if user is updating their own password or is an admin
    if (req.user.id !== req.params.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Unauthorized to update this password' });
    }
    
    const { currentPassword, newPassword } = req.body;
    
    // Find user
    const user = await User.findById(req.params.id);
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Verify current password
    const isMatch = await bcrypt.compare(currentPassword, user.password);
    
    if (!isMatch) {
      return res.status(401).json({ message: 'Current password is incorrect' });
    }
    
    // Update password
    user.password = newPassword; // Will be hashed by pre-save hook
    await user.save();
    
    res.status(200).json({ message: 'Password updated successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error updating password', error: error.message });
  }
});

export default router;