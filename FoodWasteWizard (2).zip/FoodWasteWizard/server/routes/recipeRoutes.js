import express from 'express';
import { Recipe, RecipeIngredient } from '../models/recipeModel.js';
import FoodItem from '../models/inventoryModel.js';

const router = express.Router();

// Middleware to check if user is authenticated
const isAuthenticated = (req, res, next) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: 'You must be logged in to access this resource' });
};

// Get all recipes
router.get('/', async (req, res) => {
  try {
    const recipes = await Recipe.find({ isPublic: true }).sort({ name: 1 });
    res.status(200).json(recipes);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching recipes', error: error.message });
  }
});

// Get a specific recipe
router.get('/:id', async (req, res) => {
  try {
    const recipe = await Recipe.findById(req.params.id);
    
    if (!recipe) {
      return res.status(404).json({ message: 'Recipe not found' });
    }
    
    // If recipe is not public, check if the user is the creator or an admin
    if (!recipe.isPublic) {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'You must be logged in to access this recipe' });
      }
      
      if (recipe.createdBy.toString() !== req.user.id && req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Unauthorized to access this recipe' });
      }
    }
    
    res.status(200).json(recipe);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching recipe', error: error.message });
  }
});

// Get recipe ingredients
router.get('/:id/ingredients', async (req, res) => {
  try {
    const recipe = await Recipe.findById(req.params.id);
    
    if (!recipe) {
      return res.status(404).json({ message: 'Recipe not found' });
    }
    
    // If recipe is not public, check if the user is the creator or an admin
    if (!recipe.isPublic) {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'You must be logged in to access these ingredients' });
      }
      
      if (recipe.createdBy.toString() !== req.user.id && req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Unauthorized to access these ingredients' });
      }
    }
    
    const recipeIngredients = await RecipeIngredient.find({ recipeId: req.params.id });
    res.status(200).json(recipeIngredients);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching recipe ingredients', error: error.message });
  }
});

// Search recipes by ingredients
router.post('/search', async (req, res) => {
  try {
    const { ingredients } = req.body;
    
    if (!ingredients || !Array.isArray(ingredients) || ingredients.length === 0) {
      return res.status(400).json({ message: 'No ingredients provided' });
    }
    
    // Create a regex pattern for each ingredient
    const ingredientPatterns = ingredients.map(ingredient => 
      new RegExp(ingredient.trim(), 'i')
    );
    
    // Find recipes that contain any of the provided ingredients
    const recipes = await Recipe.find({
      isPublic: true,
      $or: ingredientPatterns.map(pattern => ({ ingredients: pattern }))
    }).sort({ name: 1 });
    
    res.status(200).json(recipes);
  } catch (error) {
    res.status(500).json({ message: 'Error searching recipes', error: error.message });
  }
});

// Get recipe suggestions based on user's inventory
router.get('/suggestions/inventory', isAuthenticated, async (req, res) => {
  try {
    // Get user's inventory
    const userInventory = await FoodItem.find({ userId: req.user.id });
    
    if (userInventory.length === 0) {
      return res.status(200).json([]);
    }
    
    // Extract food item names
    const ingredientNames = userInventory.map(item => item.name.toLowerCase());
    
    // Create regex patterns for each ingredient
    const ingredientPatterns = ingredientNames.map(name => 
      new RegExp('\\b' + name + '\\b', 'i')
    );
    
    // Find recipes that contain any of the user's ingredients
    const recipes = await Recipe.find({
      isPublic: true,
      $or: ingredientPatterns.map(pattern => ({ ingredients: pattern }))
    }).sort({ name: 1 });
    
    res.status(200).json(recipes);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching recipe suggestions', error: error.message });
  }
});

// Create a new recipe
router.post('/', isAuthenticated, async (req, res) => {
  try {
    const {
      name,
      description,
      ingredients,
      instructions,
      prepTime,
      cookTime,
      servings,
      difficulty,
      cuisine,
      mealType,
      dietaryPreferences,
      imageUrl,
      isPublic
    } = req.body;
    
    const newRecipe = new Recipe({
      name,
      description,
      ingredients,
      instructions,
      prepTime,
      cookTime,
      servings,
      difficulty,
      cuisine,
      mealType,
      dietaryPreferences,
      imageUrl,
      isPublic: isPublic !== undefined ? isPublic : true,
      createdBy: req.user.id
    });
    
    const savedRecipe = await newRecipe.save();
    res.status(201).json(savedRecipe);
  } catch (error) {
    res.status(500).json({ message: 'Error creating recipe', error: error.message });
  }
});

// Add structured ingredients to a recipe
router.post('/:id/ingredients', isAuthenticated, async (req, res) => {
  try {
    const recipe = await Recipe.findById(req.params.id);
    
    if (!recipe) {
      return res.status(404).json({ message: 'Recipe not found' });
    }
    
    // Check if the user is the creator or an admin
    if (recipe.createdBy.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Unauthorized to add ingredients to this recipe' });
    }
    
    const { ingredients } = req.body;
    
    if (!ingredients || !Array.isArray(ingredients) || ingredients.length === 0) {
      return res.status(400).json({ message: 'No ingredients provided' });
    }
    
    // Save all recipe ingredients
    const recipeIngredients = await Promise.all(ingredients.map(async (ingredient) => {
      const newIngredient = new RecipeIngredient({
        recipeId: recipe.id,
        name: ingredient.name,
        quantity: ingredient.quantity,
        unit: ingredient.unit,
        notes: ingredient.notes,
        isOptional: ingredient.isOptional || false
      });
      
      return await newIngredient.save();
    }));
    
    res.status(201).json(recipeIngredients);
  } catch (error) {
    res.status(500).json({ message: 'Error adding ingredients to recipe', error: error.message });
  }
});

// Update a recipe
router.put('/:id', isAuthenticated, async (req, res) => {
  try {
    const recipe = await Recipe.findById(req.params.id);
    
    if (!recipe) {
      return res.status(404).json({ message: 'Recipe not found' });
    }
    
    // Check if the user is the creator or an admin
    if (recipe.createdBy.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Unauthorized to update this recipe' });
    }
    
    // Update the recipe
    const updatedRecipe = await Recipe.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    
    res.status(200).json(updatedRecipe);
  } catch (error) {
    res.status(500).json({ message: 'Error updating recipe', error: error.message });
  }
});

// Delete a recipe
router.delete('/:id', isAuthenticated, async (req, res) => {
  try {
    const recipe = await Recipe.findById(req.params.id);
    
    if (!recipe) {
      return res.status(404).json({ message: 'Recipe not found' });
    }
    
    // Check if the user is the creator or an admin
    if (recipe.createdBy.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Unauthorized to delete this recipe' });
    }
    
    // Delete the recipe
    await Recipe.findByIdAndDelete(req.params.id);
    
    // Delete related ingredients
    await RecipeIngredient.deleteMany({ recipeId: req.params.id });
    
    res.status(200).json({ message: 'Recipe deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error deleting recipe', error: error.message });
  }
});

export default router;