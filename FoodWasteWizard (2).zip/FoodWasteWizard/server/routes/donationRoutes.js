import express from 'express';
import { Donation, DonationItem, DonationLocation } from '../models/donationModel.js';
import FoodItem from '../models/inventoryModel.js';

const router = express.Router();

// Middleware to check if user is authenticated
const isAuthenticated = (req, res, next) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: 'You must be logged in to access this resource' });
};

// Get all donations for the current user (as donor)
router.get('/', isAuthenticated, async (req, res) => {
  try {
    const donations = await Donation.find({ donorId: req.user.id })
      .sort({ createdAt: -1 });
    
    res.status(200).json(donations);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching donations', error: error.message });
  }
});

// Get a specific donation
router.get('/:id', isAuthenticated, async (req, res) => {
  try {
    const donation = await Donation.findById(req.params.id);
    
    if (!donation) {
      return res.status(404).json({ message: 'Donation not found' });
    }
    
    // Check if the user is the donor, recipient, or an admin
    if (
      donation.donorId.toString() !== req.user.id &&
      (!donation.recipientId || donation.recipientId.toString() !== req.user.id) &&
      req.user.role !== 'admin'
    ) {
      return res.status(403).json({ message: 'Unauthorized to access this donation' });
    }
    
    res.status(200).json(donation);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching donation', error: error.message });
  }
});

// Get donation items for a specific donation
router.get('/:id/items', isAuthenticated, async (req, res) => {
  try {
    const donation = await Donation.findById(req.params.id);
    
    if (!donation) {
      return res.status(404).json({ message: 'Donation not found' });
    }
    
    // Check if the user is the donor, recipient, or an admin
    if (
      donation.donorId.toString() !== req.user.id &&
      (!donation.recipientId || donation.recipientId.toString() !== req.user.id) &&
      req.user.role !== 'admin'
    ) {
      return res.status(403).json({ message: 'Unauthorized to access these donation items' });
    }
    
    // Get donation items with food item details
    const donationItems = await DonationItem.find({ donationId: req.params.id })
      .populate('foodItemId');
    
    res.status(200).json(donationItems);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching donation items', error: error.message });
  }
});

// Create a new donation
router.post('/', isAuthenticated, async (req, res) => {
  try {
    const { pickupDate, pickupAddress, notes } = req.body;
    
    const newDonation = new Donation({
      donorId: req.user.id,
      pickupDate,
      pickupAddress,
      notes,
      status: 'pending'
    });
    
    const savedDonation = await newDonation.save();
    res.status(201).json(savedDonation);
  } catch (error) {
    res.status(500).json({ message: 'Error creating donation', error: error.message });
  }
});

// Add items to a donation
router.post('/:id/items', isAuthenticated, async (req, res) => {
  try {
    const donation = await Donation.findById(req.params.id);
    
    if (!donation) {
      return res.status(404).json({ message: 'Donation not found' });
    }
    
    // Check if the user is the donor or an admin
    if (donation.donorId.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Unauthorized to add items to this donation' });
    }
    
    const { items } = req.body;
    
    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ message: 'No items provided' });
    }
    
    // Save all donation items
    const donationItems = await Promise.all(items.map(async (item) => {
      const newDonationItem = new DonationItem({
        donationId: donation.id,
        foodItemId: item.foodItemId,
        quantity: item.quantity,
        notes: item.notes
      });
      
      // Mark the food item as available for donation
      await FoodItem.findByIdAndUpdate(item.foodItemId, { isAvailableForDonation: true });
      
      return await newDonationItem.save();
    }));
    
    res.status(201).json(donationItems);
  } catch (error) {
    res.status(500).json({ message: 'Error adding items to donation', error: error.message });
  }
});

// Update donation status
router.put('/:id', isAuthenticated, async (req, res) => {
  try {
    const donation = await Donation.findById(req.params.id);
    
    if (!donation) {
      return res.status(404).json({ message: 'Donation not found' });
    }
    
    // Check if the user is the donor, recipient, or an admin
    if (
      donation.donorId.toString() !== req.user.id &&
      (!donation.recipientId || donation.recipientId.toString() !== req.user.id) &&
      req.user.role !== 'admin'
    ) {
      return res.status(403).json({ message: 'Unauthorized to update this donation' });
    }
    
    // Update the donation
    const updatedDonation = await Donation.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    
    res.status(200).json(updatedDonation);
  } catch (error) {
    res.status(500).json({ message: 'Error updating donation', error: error.message });
  }
});

// Get all donation locations
router.get('/locations/all', async (req, res) => {
  try {
    const locations = await DonationLocation.find().sort({ name: 1 });
    res.status(200).json(locations);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching donation locations', error: error.message });
  }
});

// Get donation locations by type
router.get('/locations/type/:type', async (req, res) => {
  try {
    const locations = await DonationLocation.find({ type: req.params.type }).sort({ name: 1 });
    res.status(200).json(locations);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching donation locations by type', error: error.message });
  }
});

// Add a new donation location
router.post('/locations', isAuthenticated, async (req, res) => {
  try {
    const {
      name,
      type,
      address,
      latitude,
      longitude,
      contactPerson,
      phone,
      email,
      website,
      operatingHours,
      acceptsFoodTypes
    } = req.body;
    
    const newLocation = new DonationLocation({
      name,
      type,
      address,
      latitude,
      longitude,
      contactPerson,
      phone,
      email,
      website,
      operatingHours,
      acceptsFoodTypes,
      createdBy: req.user.id,
      isVerified: req.user.role === 'admin' // Automatically verify if added by admin
    });
    
    const savedLocation = await newLocation.save();
    res.status(201).json(savedLocation);
  } catch (error) {
    res.status(500).json({ message: 'Error creating donation location', error: error.message });
  }
});

export default router;