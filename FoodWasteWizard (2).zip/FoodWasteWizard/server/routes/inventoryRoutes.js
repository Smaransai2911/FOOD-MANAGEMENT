import express from 'express';
import FoodItem from '../models/inventoryModel.js';

const router = express.Router();

// Middleware to check if user is authenticated
const isAuthenticated = (req, res, next) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: 'You must be logged in to access this resource' });
};

// Get all food items for the current user
router.get('/', isAuthenticated, async (req, res) => {
  try {
    const foodItems = await FoodItem.find({ userId: req.user.id }).sort({ expiryDate: 1 });
    res.status(200).json(foodItems);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching food items', error: error.message });
  }
});

// Get expiring food items (within 7 days)
router.get('/expiring', isAuthenticated, async (req, res) => {
  try {
    const today = new Date();
    const sevenDaysFromNow = new Date(today);
    sevenDaysFromNow.setDate(today.getDate() + 7);
    
    const expiringItems = await FoodItem.find({
      userId: req.user.id,
      expiryDate: { $gte: today, $lte: sevenDaysFromNow }
    }).sort({ expiryDate: 1 });
    
    res.status(200).json(expiringItems);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching expiring food items', error: error.message });
  }
});

// Get a specific food item
router.get('/:id', isAuthenticated, async (req, res) => {
  try {
    const foodItem = await FoodItem.findById(req.params.id);
    
    if (!foodItem) {
      return res.status(404).json({ message: 'Food item not found' });
    }
    
    // Check if the food item belongs to the current user
    if (foodItem.userId.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Unauthorized to access this food item' });
    }
    
    res.status(200).json(foodItem);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching food item', error: error.message });
  }
});

// Create a new food item
router.post('/', isAuthenticated, async (req, res) => {
  try {
    const {
      name,
      category,
      quantity,
      unit,
      expiryDate,
      purchaseDate,
      description,
      imageUrl,
      isAvailableForDonation,
      barcodeData,
      storageLocation
    } = req.body;
    
    const newFoodItem = new FoodItem({
      name,
      category,
      quantity,
      unit,
      expiryDate,
      purchaseDate: purchaseDate || new Date(),
      description,
      imageUrl,
      isAvailableForDonation: isAvailableForDonation || false,
      barcodeData,
      storageLocation,
      userId: req.user.id
    });
    
    const savedFoodItem = await newFoodItem.save();
    res.status(201).json(savedFoodItem);
  } catch (error) {
    res.status(500).json({ message: 'Error creating food item', error: error.message });
  }
});

// Update a food item
router.put('/:id', isAuthenticated, async (req, res) => {
  try {
    // First check if the food item exists
    const foodItem = await FoodItem.findById(req.params.id);
    
    if (!foodItem) {
      return res.status(404).json({ message: 'Food item not found' });
    }
    
    // Check if the food item belongs to the current user
    if (foodItem.userId.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Unauthorized to update this food item' });
    }
    
    // Update the food item
    const updatedFoodItem = await FoodItem.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    
    res.status(200).json(updatedFoodItem);
  } catch (error) {
    res.status(500).json({ message: 'Error updating food item', error: error.message });
  }
});

// Delete a food item
router.delete('/:id', isAuthenticated, async (req, res) => {
  try {
    // First check if the food item exists
    const foodItem = await FoodItem.findById(req.params.id);
    
    if (!foodItem) {
      return res.status(404).json({ message: 'Food item not found' });
    }
    
    // Check if the food item belongs to the current user
    if (foodItem.userId.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Unauthorized to delete this food item' });
    }
    
    // Delete the food item
    await FoodItem.findByIdAndDelete(req.params.id);
    
    res.status(200).json({ message: 'Food item deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error deleting food item', error: error.message });
  }
});

// Get food waste statistics
router.get('/stats', isAuthenticated, async (req, res) => {
  try {
    // Get total number of food items
    const totalItems = await FoodItem.countDocuments({ userId: req.user.id });
    
    // Get number of expiring soon items
    const today = new Date();
    const sevenDaysFromNow = new Date(today);
    sevenDaysFromNow.setDate(today.getDate() + 7);
    
    const expiringSoon = await FoodItem.countDocuments({
      userId: req.user.id,
      expiryDate: { $gte: today, $lte: sevenDaysFromNow }
    });
    
    // Get number of items available for donation
    const availableForDonation = await FoodItem.countDocuments({
      userId: req.user.id,
      isAvailableForDonation: true
    });
    
    // Get quantity of food saved from waste
    const savedFromWaste = await FoodItem.aggregate([
      { $match: { userId: req.user.id } },
      { $group: { _id: null, total: { $sum: 1 } } }
    ]);
    
    const wasteReduced = savedFromWaste.length > 0 ? savedFromWaste[0].total : 0;
    
    res.status(200).json({
      totalItems,
      expiringSoon,
      availableForDonation,
      wasteReduced
    });
  } catch (error) {
    res.status(500).json({ message: 'Error fetching food waste statistics', error: error.message });
  }
});

export default router;